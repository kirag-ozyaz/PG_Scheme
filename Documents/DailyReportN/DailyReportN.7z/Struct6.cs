﻿using System;

internal struct Struct6
{
	internal Struct6(string string_2, string string_3)
	{
		//Class611.H9nE6ZDzTF9kb();
		this.string_0 = string_2;
		this.string_1 = string_3;
	}

	internal string string_0;

	internal string string_1;
}
