﻿using System;

internal class Class119
{
	internal Class119(string name, int id)
	{
		this.NameObjList = name;
		this.IdObjList = id;
	}

	internal string NameObjList;
	internal int IdObjList;
}
