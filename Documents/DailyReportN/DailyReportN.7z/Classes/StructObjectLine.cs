﻿using System;

internal class StructObjectLine
{
	internal StructObjectLine(string name, int id)
	{
		this.Name = name;
		this.Id = id;
	}

	internal string Name;
	internal int Id;
}
