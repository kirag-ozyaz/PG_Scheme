﻿using System;
using System.Collections.Generic;

internal class Class225
{
	internal Class225(DateTime dateTime_1, string string_1, Dictionary<string, List<string>> dictionary_1)
	{
		//Class611.H9nE6ZDzTF9kb();
		this.dateTime_0 = DateTime.Now;
		this.string_0 = "";
		this.dictionary_0 = new Dictionary<string, List<string>>();
		
		this.dateTime_0 = dateTime_1;
		this.string_0 = string_1;
		this.dictionary_0 = dictionary_1;
	}

	internal DateTime dateTime_0;

	internal string string_0;

	internal Dictionary<string, List<string>> dictionary_0;
}
