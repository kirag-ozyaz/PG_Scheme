﻿using System;

internal class Class611
{
	internal static void H9nE6ZDzTF9kb()
	{
	}

	private static bool bool_0;
}
