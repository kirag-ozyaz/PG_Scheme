﻿internal partial class Form86 : global::FormLbr.FormBase
{
	protected override void Dispose(bool bool_2)
	{
		if (bool_2 && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(bool_2);
	}

	private global::System.ComponentModel.IContainer icontainer_0;
}
