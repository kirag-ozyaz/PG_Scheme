﻿//using DailyReport.Reports;
using Microsoft.Reporting.WinForms;
using System;
using System.Drawing;
using System.Windows.Forms;

internal partial class FormReportDetectionCrash : FormLbr.FormBase
{
	protected override void Dispose(bool disposing)
	{
		if (disposing && this.components != null)
		{
			this.components.Dispose();
		}
		base.Dispose(disposing);
	}

	private System.ComponentModel.IContainer components=null;

    private void InitializeComponent()
    {
        this.panel1 = new Panel();
        this.grpAct = new GroupBox();
        this.rBtnCrashAct = new RadioButton();
        this.rBtnAllAct = new RadioButton();
        this.panel2 = new Panel();
        this.txtName = new TextBox();
        this.label1 = new Label();
        this.txtPost = new TextBox();
        this.label4 = new Label();
        this.grpDate = new GroupBox();
        this.cmbYear = new ComboBox();
        this.dtpDateEnd = new DateTimePicker();
        this.dtpDateBegin = new DateTimePicker();
        this.label3 = new Label();
        this.label2 = new Label();
        this.rBtnPeriod = new RadioButton();
        this.rBtnYear = new RadioButton();
        this.tsMain = new ToolStrip();
        this.tsBtnAddFilter = new ToolStripButton();
        this.tsBtnDelFilter = new ToolStripButton();
        this.rView = new ReportViewer();
        this.panel1.SuspendLayout();
        this.grpAct.SuspendLayout();
        this.panel2.SuspendLayout();
        this.grpDate.SuspendLayout();
        this.tsMain.SuspendLayout();
        base.SuspendLayout();
        this.panel1.Controls.Add(this.grpAct);
        this.panel1.Controls.Add(this.panel2);
        this.panel1.Controls.Add(this.grpDate);
        this.panel1.Controls.Add(this.tsMain);
        this.panel1.Dock = DockStyle.Left;
        this.panel1.Location = new Point(0, 0);
        this.panel1.Name = "panel1";
        this.panel1.Padding = new Padding(3);
        this.panel1.Size = new Size(200, 571);
        this.panel1.TabIndex = 0;
        this.grpAct.Controls.Add(this.rBtnCrashAct);
        this.grpAct.Controls.Add(this.rBtnAllAct);
        this.grpAct.Dock = DockStyle.Top;
        this.grpAct.Location = new Point(3, 266);
        this.grpAct.Name = "grpAct";
        this.grpAct.Size = new Size(194, 68);
        this.grpAct.TabIndex = 1;
        this.grpAct.TabStop = false;
        this.grpAct.Text = "Акты";
        this.rBtnCrashAct.AutoSize = true;
        this.rBtnCrashAct.Location = new Point(9, 42);
        this.rBtnCrashAct.Name = "rBtnCrashAct";
        this.rBtnCrashAct.Size = new Size(110, 17);
        this.rBtnCrashAct.TabIndex = 8;
        this.rBtnCrashAct.TabStop = true;
        this.rBtnCrashAct.Text = "Аварийные акты";
        this.rBtnCrashAct.UseVisualStyleBackColor = true;
        this.rBtnAllAct.AutoSize = true;
        this.rBtnAllAct.Checked = true;
        this.rBtnAllAct.Location = new Point(9, 19);
        this.rBtnAllAct.Name = "rBtnAllAct";
        this.rBtnAllAct.Size = new Size(72, 17);
        this.rBtnAllAct.TabIndex = 7;
        this.rBtnAllAct.TabStop = true;
        this.rBtnAllAct.Text = "Все акты";
        this.rBtnAllAct.UseVisualStyleBackColor = true;
        this.panel2.Controls.Add(this.txtName);
        this.panel2.Controls.Add(this.label1);
        this.panel2.Controls.Add(this.txtPost);
        this.panel2.Controls.Add(this.label4);
        this.panel2.Dock = DockStyle.Top;
        this.panel2.Location = new Point(3, 176);
        this.panel2.Name = "panel2";
        this.panel2.Padding = new Padding(0, 10, 0, 0);
        this.panel2.Size = new Size(194, 90);
        this.panel2.TabIndex = 4;
        this.txtName.BackColor = SystemColors.Window;
        this.txtName.Dock = DockStyle.Top;
        this.txtName.Location = new Point(0, 61);
        this.txtName.Name = "txtName";
        this.txtName.Size = new Size(194, 20);
        this.txtName.TabIndex = 6;
        this.label1.AutoSize = true;
        this.label1.Dock = DockStyle.Top;
        this.label1.Location = new Point(0, 43);
        this.label1.Name = "label1";
        this.label1.Padding = new Padding(0, 5, 0, 0);
        this.label1.Size = new Size(34, 18);
        this.label1.TabIndex = 2;
        this.label1.Text = "ФИО";
        this.txtPost.Dock = DockStyle.Top;
        this.txtPost.Location = new Point(0, 23);
        this.txtPost.Name = "txtPost";
        this.txtPost.Size = new Size(194, 20);
        this.txtPost.TabIndex = 5;
        this.label4.AutoSize = true;
        this.label4.Dock = DockStyle.Top;
        this.label4.Location = new Point(0, 10);
        this.label4.Name = "label4";
        this.label4.Size = new Size(65, 13);
        this.label4.TabIndex = 4;
        this.label4.Text = "Должность";
        this.grpDate.Controls.Add(this.cmbYear);
        this.grpDate.Controls.Add(this.dtpDateEnd);
        this.grpDate.Controls.Add(this.dtpDateBegin);
        this.grpDate.Controls.Add(this.label3);
        this.grpDate.Controls.Add(this.label2);
        this.grpDate.Controls.Add(this.rBtnPeriod);
        this.grpDate.Controls.Add(this.rBtnYear);
        this.grpDate.Dock = DockStyle.Top;
        this.grpDate.Location = new Point(3, 28);
        this.grpDate.Name = "grpDate";
        this.grpDate.Size = new Size(194, 148);
        this.grpDate.TabIndex = 0;
        this.grpDate.TabStop = false;
        this.grpDate.Text = "Дата";
        this.cmbYear.AutoCompleteMode = AutoCompleteMode.Append;
        this.cmbYear.AutoCompleteSource = AutoCompleteSource.ListItems;
        this.cmbYear.DropDownStyle = ComboBoxStyle.DropDownList;
        this.cmbYear.FormattingEnabled = true;
        this.cmbYear.Location = new Point(9, 41);
        this.cmbYear.Name = "cmbYear";
        this.cmbYear.Size = new Size(179, 21);
        this.cmbYear.TabIndex = 1;
        this.dtpDateEnd.Enabled = false;
        this.dtpDateEnd.Location = new Point(34, 117);
        this.dtpDateEnd.Name = "dtpDateEnd";
        this.dtpDateEnd.Size = new Size(154, 20);
        this.dtpDateEnd.TabIndex = 4;
        this.dtpDateEnd.ValueChanged +=new EventHandler (this.dtpDateEnd_ValueChanged);
        this.dtpDateBegin.Enabled = false;
        this.dtpDateBegin.Location = new Point(34, 91);
        this.dtpDateBegin.Name = "dtpDateBegin";
        this.dtpDateBegin.Size = new Size(154, 20);
        this.dtpDateBegin.TabIndex = 3;
        this.dtpDateBegin.ValueChanged +=new EventHandler (this.dtpDateBegin_ValueChanged);
        this.label3.AutoSize = true;
        this.label3.Location = new Point(6, 119);
        this.label3.Name = "label3";
        this.label3.Size = new Size(22, 13);
        this.label3.TabIndex = 4;
        this.label3.Text = "по:";
        this.label2.AutoSize = true;
        this.label2.Location = new Point(6, 91);
        this.label2.Name = "label2";
        this.label2.Size = new Size(16, 13);
        this.label2.TabIndex = 3;
        this.label2.Text = "с:";
        this.rBtnPeriod.AutoSize = true;
        this.rBtnPeriod.Location = new Point(9, 68);
        this.rBtnPeriod.Name = "rBtnPeriod";
        this.rBtnPeriod.Size = new Size(63, 17);
        this.rBtnPeriod.TabIndex = 2;
        this.rBtnPeriod.TabStop = true;
        this.rBtnPeriod.Text = "Период";
        this.rBtnPeriod.UseVisualStyleBackColor = true;
        this.rBtnYear.AutoSize = true;
        this.rBtnYear.Checked = true;
        this.rBtnYear.Location = new Point(9, 19);
        this.rBtnYear.Name = "rBtnYear";
        this.rBtnYear.Size = new Size(43, 17);
        this.rBtnYear.TabIndex = 0;
        this.rBtnYear.TabStop = true;
        this.rBtnYear.Text = "Год";
        this.rBtnYear.UseVisualStyleBackColor = true;
        this.rBtnYear.CheckedChanged +=new EventHandler( this.rBtnYear_CheckedChanged);
        this.tsMain.GripStyle = ToolStripGripStyle.Hidden;
        this.tsMain.Items.AddRange(new ToolStripItem[]
        {
            this.tsBtnAddFilter,
            this.tsBtnDelFilter
        });
        this.tsMain.Location = new Point(3, 3);
        this.tsMain.Name = "tsMain";
        this.tsMain.Size = new Size(194, 25);
        this.tsMain.TabIndex = 9;
        this.tsMain.Text = "toolStrip1";
        this.tsBtnAddFilter.DisplayStyle = ToolStripItemDisplayStyle.Image;
        this.tsBtnAddFilter.Image = global::DailyReportN.Properties.Resources.filter;
        this.tsBtnAddFilter.ImageTransparentColor = Color.Magenta;
        this.tsBtnAddFilter.Name = "tsBtnAddFilter";
        this.tsBtnAddFilter.Size = new Size(23, 22);
        this.tsBtnAddFilter.Text = "Применить фильтр";
        this.tsBtnAddFilter.Click +=new EventHandler (this.tsBtnAddFilter_Click);
        this.tsBtnDelFilter.DisplayStyle = ToolStripItemDisplayStyle.Image;
        this.tsBtnDelFilter.Image = global::DailyReportN.Properties.Resources.filter_delete;
        this.tsBtnDelFilter.ImageTransparentColor = Color.Magenta;
        this.tsBtnDelFilter.Name = "tsBtnDelFilter";
        this.tsBtnDelFilter.Size = new Size(23, 22);
        this.tsBtnDelFilter.Text = "Сбросить фильтр";
        this.tsBtnDelFilter.Click +=new EventHandler (this.tsBtnDelFilter_Click);
        this.rView.Dock = DockStyle.Fill;
        this.rView.Location = new Point(200, 0);
        this.rView.Name = "rView";
        this.rView.Size = new Size(625, 571);
        this.rView.TabIndex = 1;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(825, 571);
        base.Controls.Add(this.rView);
        base.Controls.Add(this.panel1);
        base.Name = "FormReportDetectionCrash";
        base.StartPosition = FormStartPosition.CenterScreen;
        this.Text = "Бюллетень аварийных отключений (N)";
        base.FormClosing +=new System.Windows.Forms.FormClosingEventHandler( this.FormReportDetectionCrash_FormClosing);
        base.Load +=new System.EventHandler( this.FormReportDetectionCrash_Load);
        this.panel1.ResumeLayout(false);
        this.panel1.PerformLayout();
        this.grpAct.ResumeLayout(false);
        this.grpAct.PerformLayout();
        this.panel2.ResumeLayout(false);
        this.panel2.PerformLayout();
        this.grpDate.ResumeLayout(false);
        this.grpDate.PerformLayout();
        this.tsMain.ResumeLayout(false);
        this.tsMain.PerformLayout();
        base.ResumeLayout(false);
    }



    private Panel panel1;

    private ReportViewer rView;

    private GroupBox grpAct;

    private RadioButton rBtnCrashAct;

    private RadioButton rBtnAllAct;

    private Panel panel2;

    private TextBox txtName;

    private Label label1;

    private GroupBox grpDate;

    private DateTimePicker dtpDateEnd;

    private DateTimePicker dtpDateBegin;

    private Label label3;

    private Label label2;

    private RadioButton rBtnPeriod;

    private RadioButton rBtnYear;

    private ToolStrip tsMain;

    private ToolStripButton tsBtnAddFilter;

    private ToolStripButton tsBtnDelFilter;

    private ComboBox cmbYear;

    private TextBox txtPost;

    private Label label4;
}
