﻿internal partial class Form82 : global::FormLbr.FormBase
{
	protected override void Dispose(bool bool_0)
	{
		if (bool_0 && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(bool_0);
	}

	private global::System.ComponentModel.IContainer icontainer_0;
}
