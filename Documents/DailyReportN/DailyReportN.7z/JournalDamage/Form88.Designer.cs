﻿internal partial class Form88 : global::FormLbr.FormBase
{
	protected override void Dispose(bool bool_0)
	{
		if (bool_0 && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		global::Form88.xOPK13rJFG6VHk1V37I6(this, bool_0);
	}

	private global::System.ComponentModel.IContainer icontainer_0;
}
