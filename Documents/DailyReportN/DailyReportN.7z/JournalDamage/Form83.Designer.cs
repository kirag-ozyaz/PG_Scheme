﻿internal partial class Form83 : global::FormLbr.FormBase
{
	protected override void Dispose(bool bool_2)
	{
		if (bool_2 && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		global::Form83.SkWKJ5r3Q9NKDpOgQChM(this, bool_2);
	}

	private global::System.ComponentModel.IContainer icontainer_0;
}
