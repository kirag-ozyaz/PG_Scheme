﻿namespace DailyReportN.DataSet
{
}

namespace DailyReportN.DataSet
{


    public partial class dsDamage
    {
    }
}
namespace DailyReportN.DataSet {
    
    
    public partial class dsDamage {
    }
}
