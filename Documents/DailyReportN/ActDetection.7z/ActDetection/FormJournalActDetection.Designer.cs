﻿
using ControlsLbr.DataGridViewExcelFilter;
using ControlsLbr.Scheme;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
namespace DailyReportN.JournalActDetection
{
    public partial class FormJournalActDetection : FormLbr.FormBase
    {
        protected override void Dispose(bool disposing)
        {
            if (disposing && this.components != null)
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager resources = new ComponentResourceManager(typeof(FormJournalActDetection));
            DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            this.toolStrip = new ToolStrip();
            this.toolBtnAdd = new ToolStripButton();
            this.toolBtnEdit = new ToolStripButton();
            this.toolBtnInfo = new ToolStripButton();
            this.toolBtnDel = new ToolStripButton();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.toolBtnRefresh = new ToolStripButton();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.toolBtnFind = new ToolStripButton();
            this.txtFind = new ToolStripTextBox();
            this.toolBtnFindPrev = new ToolStripButton();
            this.toolBtnFindNext = new ToolStripButton();
            this.toolStripSeparator3 = new ToolStripSeparator();
            this.toolBtnReport = new ToolStripDropDownButton();
            this.tsMenuAmergencyShutdown = new ToolStripMenuItem();
            this.toolBTnLoadOld = new ToolStripDropDownButton();
            this.toolBtnLoadOldDamageLV = new ToolStripMenuItem();
            this.toolBtnLoadOldDefect = new ToolStripMenuItem();
            this.toolBtnLoadAbnDefectLV = new ToolStripMenuItem();
            this.toolBtnLoadOldDamageНV = new ToolStripMenuItem();
            this.toolBtnDamageNoApply = new ToolStripButton();
            this.toolBtnExportExcel = new ToolStripButton();
            this.toolBtnPrint = new ToolStripButton();
            this.splitContainer = new SplitContainer();
            this.checkBoxWhereSub = new CheckBox();
            this.toolStripTreeSchmObj = new ToolStrip();
            this.toolBtnFindTreeSchmObj = new ToolStripButton();
            this.txtFindTreeSchmObj = new ToolStripTextBox();
            this.toolBtnFindPrevTreeSchmObj = new ToolStripButton();
            this.toolBtnFindNextTreeSchmObj = new ToolStripButton();
            this.treeViewSchmObjects = new TreeViewSchmObjects();
            this.dtpFilterEnd = new DateTimePicker();
            this.label2 = new Label();
            this.dtpFilterBeg = new DateTimePicker();
            this.label1 = new Label();
            this.toolStripFilter = new ToolStrip();
            this.toolBtnFilterApply = new ToolStripButton();
            this.toolBtnFilterDelete = new ToolStripButton();
            this.toolStripSeparator4 = new ToolStripSeparator();
            this.toolBtnPrevYear = new ToolStripButton();
            this.toolBtnNextYear = new ToolStripButton();
            this.dgvActDetection = new DataGridViewExcelFilter();
            this.numrequestDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.numDocDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.dateDocDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.typeDocNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.divisionDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.schmObjNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.netRegionSubDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.numcrashDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.defectLocationDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.reasonDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.divisionApplyDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.isLaboratoryDgvColumn = new DataGridViewFilterCheckBoxColumn();
            this.dateApplyDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.isApplyDgvColumn = new DataGridViewFilterCheckBoxColumn();
            this.workerApplyDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.completedWorkDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.compilerDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.InstructionDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.nameOwnerDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.dateOwnerDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.comletedWorkTextDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.KodPTSDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.kodPTSStrDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.idParentDgvColumn = new DataGridViewTextBoxColumn();
            this.typeDocDgvColumn = new DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.signCrashTypeDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.signCrashNameDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.typeEquipDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.typeEquipNameDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.reasonCrashEquipTypeDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.reasonCrashEquipNameDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.reasonCrashTypeDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.reasonCrashNameDgvActDetection = new DataGridViewFilterTextBoxColumn();
            this.bsDamage = new BindingSource(this.components);
            this.dsDamage = new DailyReportN.DataSet.dsDamage();
            this.toolItemAdd = new ToolStripMenuItem();
            this.toolItemEdit = new ToolStripMenuItem();
            this.toolItemInfo = new ToolStripMenuItem();
            this.toolItemDel = new ToolStripMenuItem();
            this.contextMenuDamage = new ContextMenuStrip(this.components);
            this.tsMenuReportAccidents = new ToolStripMenuItem();
            this.toolStrip.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.toolStripTreeSchmObj.SuspendLayout();
            this.toolStripFilter.SuspendLayout();
            ((ISupportInitialize)this.dgvActDetection).BeginInit();
            ((ISupportInitialize)this.bsDamage).BeginInit();
            ((ISupportInitialize)this.dsDamage).BeginInit();
            this.contextMenuDamage.SuspendLayout();
            base.SuspendLayout();
            this.toolStrip.Items.AddRange(new ToolStripItem[]
            {
                this.toolBtnAdd,
                this.toolBtnEdit,
                this.toolBtnInfo,
                this.toolBtnDel,
                this.toolStripSeparator1,
                this.toolBtnRefresh,
                this.toolStripSeparator2,
                this.toolBtnFind,
                this.txtFind,
                this.toolBtnFindPrev,
                this.toolBtnFindNext,
                this.toolStripSeparator3,
                this.toolBtnReport,
                this.toolBTnLoadOld,
                this.toolBtnDamageNoApply,
                this.toolBtnExportExcel,
                this.toolBtnPrint
            });
            this.toolStrip.Location = new Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new Size(1022, 25);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip1";
            this.toolBtnAdd.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnAdd.Image = (Image)global::DailyReportN.Properties.Resources.Add;
            this.toolBtnAdd.ImageTransparentColor = Color.Magenta;
            this.toolBtnAdd.Name = "toolBtnAdd";
            this.toolBtnAdd.Size = new Size(23, 22);
            this.toolBtnAdd.Text = "Добавить";
            this.toolBtnAdd.Click += new EventHandler(this.toolBtnAdd_Click);
            this.toolBtnEdit.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnEdit.Image = (Image)global::DailyReportN.Properties.Resources.Edit;
            this.toolBtnEdit.ImageTransparentColor = Color.Magenta;
            this.toolBtnEdit.Name = "toolBtnEdit";
            this.toolBtnEdit.Size = new Size(23, 22);
            this.toolBtnEdit.Text = "Редактировать";
            this.toolBtnEdit.Click += new EventHandler(this.toolBtnEdit_Click);
            this.toolBtnInfo.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnInfo.Image = (Image)global::DailyReportN.Properties.Resources.ElementInformation;
            this.toolBtnInfo.ImageTransparentColor = Color.Magenta;
            this.toolBtnInfo.Name = "toolBtnInfo";
            this.toolBtnInfo.Size = new Size(23, 22);
            this.toolBtnInfo.Text = "Информация";
            this.toolBtnInfo.Click += new EventHandler(this.toolBtnInfo_Click);

            this.toolBtnDel.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnDel.Image = (Image)global::DailyReportN.Properties.Resources.ElementDel;
            this.toolBtnDel.ImageTransparentColor = Color.Magenta;
            this.toolBtnDel.Name = "toolBtnDel";
            this.toolBtnDel.Size = new Size(23, 22);
            this.toolBtnDel.Text = "Удалить документ";
            this.toolBtnDel.Click += new EventHandler(this.toolBtnDel_Click);

            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(6, 25);
            this.toolBtnRefresh.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnRefresh.Image = (Image)global::DailyReportN.Properties.Resources.Refresh;
            this.toolBtnRefresh.ImageTransparentColor = Color.Magenta;
            this.toolBtnRefresh.Name = "toolBtnRefresh";
            this.toolBtnRefresh.Size = new Size(23, 22);
            this.toolBtnRefresh.Text = "Обновить";
            this.toolBtnRefresh.Click += new EventHandler(this.toolBtnRefresh_Click);

            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(6, 25);
            this.toolBtnFind.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFind.Image = (Image)global::DailyReportN.Properties.Resources.Find;
            this.toolBtnFind.ImageTransparentColor = Color.Magenta;
            this.toolBtnFind.Name = "toolBtnFind";
            this.toolBtnFind.Size = new Size(23, 22);
            this.toolBtnFind.Text = "Искать";
            this.toolBtnFind.Click += new EventHandler(this.toolBtnFind_Click);

            this.txtFind.Name = "txtFind";
            this.txtFind.Size = new Size(100, 25);
            this.txtFind.ToolTipText = "Текст для поиска";
            this.txtFind.KeyDown += new KeyEventHandler(this.txtFind_KeyDown);
            this.toolBtnFindPrev.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFindPrev.Image = (Image)global::DailyReportN.Properties.Resources.FindPrev;
            this.toolBtnFindPrev.ImageTransparentColor = Color.Magenta;
            this.toolBtnFindPrev.Name = "toolBtnFindPrev";
            this.toolBtnFindPrev.Size = new Size(23, 22);
            this.toolBtnFindPrev.Text = "Искать назад";
            this.toolBtnFindPrev.Click += new EventHandler(this.toolBtnFindPrev_Click);

            this.toolBtnFindNext.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFindNext.Image = (Image)global::DailyReportN.Properties.Resources.FindNext;
            this.toolBtnFindNext.ImageTransparentColor = Color.Magenta;
            this.toolBtnFindNext.Name = "toolBtnFindNext";
            this.toolBtnFindNext.Size = new Size(23, 22);
            this.toolBtnFindNext.Text = "Искать вперед";
            this.toolBtnFindNext.Click += new EventHandler(this.toolBtnFindNext_Click);

            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new Size(6, 25);
            this.toolBtnReport.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnReport.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.tsMenuAmergencyShutdown,
                this.tsMenuReportAccidents
            });
            this.toolBtnReport.Image = (Image)global::DailyReportN.Properties.Resources.Report;
            this.toolBtnReport.ImageTransparentColor = Color.Magenta;
            this.toolBtnReport.Name = "toolBtnReport";
            this.toolBtnReport.Size = new Size(29, 22);
            this.toolBtnReport.Text = "Отчеты";
            this.tsMenuAmergencyShutdown.Name = "tsMenuAmergencyShutdown";
            this.tsMenuAmergencyShutdown.Size = new Size(270, 22);
            this.tsMenuAmergencyShutdown.Text = "Бюллетень аварийных отключений";
            this.tsMenuAmergencyShutdown.Click += new EventHandler(this.tsMenuAmergencyShutdown_Click);
            this.toolBTnLoadOld.Alignment = ToolStripItemAlignment.Right;
            this.toolBTnLoadOld.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBTnLoadOld.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.toolBtnLoadOldDamageLV,
                this.toolBtnLoadOldDefect,
                this.toolBtnLoadAbnDefectLV,
                this.toolBtnLoadOldDamageНV
            });
            this.toolBTnLoadOld.Image = (Image)global::DailyReportN.Properties.Resources.Load;
            this.toolBTnLoadOld.ImageTransparentColor = Color.Magenta;
            this.toolBTnLoadOld.Name = "toolBTnLoadOld";
            this.toolBTnLoadOld.Size = new Size(29, 22);
            this.toolBTnLoadOld.Text = "Загрузка из старой базы";
            this.toolBtnLoadOldDamageLV.Name = "toolBtnLoadOldDamageLV";
            this.toolBtnLoadOldDamageLV.Size = new Size(210, 22);
            this.toolBtnLoadOldDamageLV.Text = "0.4кВ";
            this.toolBtnLoadOldDamageLV.Click += new EventHandler(this.toolBtnLoadOldDamageLV_Click);
            this.toolBtnLoadOldDefect.Name = "toolBtnLoadOldDefect";
            this.toolBtnLoadOldDefect.Size = new Size(210, 22);
            this.toolBtnLoadOldDefect.Text = "Дефект";
            this.toolBtnLoadOldDefect.Click += new EventHandler(this.toolBtnLoadOldDefect_Click);
            this.toolBtnLoadAbnDefectLV.Name = "toolBtnLoadAbnDefectLV";
            this.toolBtnLoadAbnDefectLV.Size = new Size(210, 22);
            this.toolBtnLoadAbnDefectLV.Text = "Загрузить абонентов НН";
            this.toolBtnLoadAbnDefectLV.Click += new EventHandler(this.toolBtnLoadAbnDefectLV_Click);

            this.toolBtnLoadOldDamageНV.Name = "toolBtnLoadOldDamageНV";
            this.toolBtnLoadOldDamageНV.Size = new Size(210, 22);
            this.toolBtnLoadOldDamageНV.Text = "ВН";
            this.toolBtnLoadOldDamageНV.Click += new EventHandler(this.toolBtnLoadOldDamageНV_Click);

            this.toolBtnDamageNoApply.Alignment = ToolStripItemAlignment.Right;
            this.toolBtnDamageNoApply.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnDamageNoApply.Image = (Image)global::DailyReportN.Properties.Resources.ElementAccept;
            this.toolBtnDamageNoApply.ImageTransparentColor = Color.Magenta;
            this.toolBtnDamageNoApply.Name = "toolBtnDamageNoApply";
            this.toolBtnDamageNoApply.Size = new Size(23, 22);
            this.toolBtnDamageNoApply.Text = "Разблокировать документ";
            this.toolBtnDamageNoApply.Visible = false;
            this.toolBtnDamageNoApply.Click += new EventHandler(this.toolBtnDamageNoApply_Click);

            this.toolBtnExportExcel.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnExportExcel.Image = (Image)global::DailyReportN.Properties.Resources.Excel;
            this.toolBtnExportExcel.ImageTransparentColor = Color.Magenta;
            this.toolBtnExportExcel.Name = "toolBtnExportExcel";
            this.toolBtnExportExcel.Size = new Size(23, 22);
            this.toolBtnExportExcel.Text = "Экспорт в Excel";
            this.toolBtnExportExcel.Click += new EventHandler(this.toolBtnExportExcel_Click);

            this.toolBtnPrint.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnPrint.Image = (Image)global::DailyReportN.Properties.Resources.Print;
            this.toolBtnPrint.ImageTransparentColor = Color.Magenta;
            this.toolBtnPrint.Name = "toolBtnPrint";
            this.toolBtnPrint.Size = new Size(23, 22);
            this.toolBtnPrint.Text = "Печать";
            this.toolBtnPrint.Click += new EventHandler(this.toolBtnPrint_Click);

            this.splitContainer.Dock = DockStyle.Fill;
            this.splitContainer.FixedPanel = FixedPanel.Panel1;
            this.splitContainer.Location = new Point(0, 25);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Panel1.Controls.Add(this.checkBoxWhereSub);
            this.splitContainer.Panel1.Controls.Add(this.toolStripTreeSchmObj);
            this.splitContainer.Panel1.Controls.Add(this.treeViewSchmObjects);
            this.splitContainer.Panel1.Controls.Add(this.dtpFilterEnd);
            this.splitContainer.Panel1.Controls.Add(this.label2);
            this.splitContainer.Panel1.Controls.Add(this.dtpFilterBeg);
            this.splitContainer.Panel1.Controls.Add(this.label1);
            this.splitContainer.Panel1.Controls.Add(this.toolStripFilter);
            this.splitContainer.Panel2.Controls.Add(this.dgvActDetection);
            this.splitContainer.Size = new Size(1022, 577);
            this.splitContainer.SplitterDistance = 258;
            this.splitContainer.TabIndex = 1;
            this.checkBoxWhereSub.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
            this.checkBoxWhereSub.AutoSize = true;
            this.checkBoxWhereSub.Checked = true;
            this.checkBoxWhereSub.CheckState = CheckState.Checked;
            this.checkBoxWhereSub.Location = new Point(15, 555);
            this.checkBoxWhereSub.Name = "checkBoxWhereSub";
            this.checkBoxWhereSub.Size = new Size(180, 17);
            this.checkBoxWhereSub.TabIndex = 12;
            this.checkBoxWhereSub.Text = "Фильтровать по подстанциям";
            this.checkBoxWhereSub.UseVisualStyleBackColor = true;

            this.toolStripTreeSchmObj.Dock = DockStyle.None;
            this.toolStripTreeSchmObj.GripStyle = ToolStripGripStyle.Hidden;
            this.toolStripTreeSchmObj.Items.AddRange(new ToolStripItem[]
            {
                this.toolBtnFindTreeSchmObj,
                this.txtFindTreeSchmObj,
                this.toolBtnFindPrevTreeSchmObj,
                this.toolBtnFindNextTreeSchmObj
            });
            this.toolStripTreeSchmObj.Location = new Point(15, 103);
            this.toolStripTreeSchmObj.Name = "toolStripTreeSchmObj";
            this.toolStripTreeSchmObj.Size = new Size(174, 25);
            this.toolStripTreeSchmObj.TabIndex = 11;
            this.toolStripTreeSchmObj.Text = "toolStrip1";

            this.toolBtnFindTreeSchmObj.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFindTreeSchmObj.Image = (Image)global::DailyReportN.Properties.Resources.Find;
            this.toolBtnFindTreeSchmObj.ImageTransparentColor = Color.Magenta;
            this.toolBtnFindTreeSchmObj.Name = "toolBtnFindTreeSchmObj";
            this.toolBtnFindTreeSchmObj.Size = new Size(23, 22);
            this.toolBtnFindTreeSchmObj.Text = "Искать";
            this.toolBtnFindTreeSchmObj.Click += new EventHandler(this.toolBtnFindTreeSchmObj_Click);

            this.txtFindTreeSchmObj.Name = "txtFindTreeSchmObj";
            this.txtFindTreeSchmObj.Size = new Size(100, 25);
            this.txtFindTreeSchmObj.ToolTipText = "Текст для поиска";
            this.txtFindTreeSchmObj.KeyDown += new KeyEventHandler(this.txtFindTreeSchmObj_KeyDown);

            this.toolBtnFindPrevTreeSchmObj.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFindPrevTreeSchmObj.Image = (Image)global::DailyReportN.Properties.Resources.FindPrev;
            this.toolBtnFindPrevTreeSchmObj.ImageTransparentColor = Color.Magenta;
            this.toolBtnFindPrevTreeSchmObj.Name = "toolBtnFindPrevTreeSchmObj";
            this.toolBtnFindPrevTreeSchmObj.Size = new Size(23, 22);
            this.toolBtnFindPrevTreeSchmObj.Text = "Искать назад";
            this.toolBtnFindPrevTreeSchmObj.Click += new EventHandler(this.toolBtnFindPrevTreeSchmObj_Click);

            this.toolBtnFindNextTreeSchmObj.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFindNextTreeSchmObj.Image = (Image)global::DailyReportN.Properties.Resources.FindNext;
            this.toolBtnFindNextTreeSchmObj.ImageTransparentColor = Color.Magenta;
            this.toolBtnFindNextTreeSchmObj.Name = "toolBtnFindNextTreeSchmObj";
            this.toolBtnFindNextTreeSchmObj.Size = new Size(23, 22);
            this.toolBtnFindNextTreeSchmObj.Text = "Искать вперед";
            this.toolBtnFindNextTreeSchmObj.Click += new EventHandler(this.toolBtnFindNextTreeSchmObj_Click);

            this.treeViewSchmObjects.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
            this.treeViewSchmObjects.CheckBoxes = true;
            this.treeViewSchmObjects.Location = new Point(12, 126);
            this.treeViewSchmObjects.Name = "treeViewSchmObjects";
            this.treeViewSchmObjects.Size = new Size(234, 423);
            this.treeViewSchmObjects.SqlSettings = null;
            this.treeViewSchmObjects.TabIndex = 10;

            this.dtpFilterEnd.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.dtpFilterEnd.CausesValidation = false;
            this.dtpFilterEnd.Location = new Point(12, 80);
            this.dtpFilterEnd.Name = "dtpFilterEnd";
            this.dtpFilterEnd.Size = new Size(234, 20);
            this.dtpFilterEnd.TabIndex = 4;
            this.dtpFilterEnd.ValueChanged += new EventHandler(this.dtpFilterEnd_ValueChanged);

            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new Size(22, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "До";
            this.dtpFilterBeg.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.dtpFilterBeg.CausesValidation = false;
            this.dtpFilterBeg.Location = new Point(12, 41);
            this.dtpFilterBeg.Name = "dtpFilterBeg";
            this.dtpFilterBeg.Size = new Size(234, 20);
            this.dtpFilterBeg.TabIndex = 2;
            this.dtpFilterBeg.ValueChanged += new EventHandler(this.dtpFilterBeg_ValueChanged);

            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new Size(20, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "От";
            this.toolStripFilter.Items.AddRange(new ToolStripItem[]
            {
                this.toolBtnFilterApply,
                this.toolBtnFilterDelete,
                this.toolStripSeparator4,
                this.toolBtnPrevYear,
                this.toolBtnNextYear
            });
            this.toolStripFilter.Location = new Point(0, 0);
            this.toolStripFilter.Name = "toolStripFilter";
            this.toolStripFilter.Size = new Size(258, 25);
            this.toolStripFilter.TabIndex = 0;
            this.toolStripFilter.Text = "toolStrip1";
            this.toolBtnFilterApply.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFilterApply.Image = (Image)global::DailyReportN.Properties.Resources.filter;
            this.toolBtnFilterApply.ImageTransparentColor = Color.Magenta;
            this.toolBtnFilterApply.Name = "toolBtnFilterApply";
            this.toolBtnFilterApply.Size = new Size(23, 22);
            this.toolBtnFilterApply.Text = "Применить фильтр";
            this.toolBtnFilterApply.Click += new EventHandler(this.toolBtnFilterApply_Click);

            this.toolBtnFilterDelete.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnFilterDelete.Image = (Image)global::DailyReportN.Properties.Resources.filter_delete;
            this.toolBtnFilterDelete.ImageTransparentColor = Color.Magenta;
            this.toolBtnFilterDelete.Name = "toolBtnFilterDelete";
            this.toolBtnFilterDelete.Size = new Size(23, 22);
            this.toolBtnFilterDelete.Text = "Убрать фильтр";
            this.toolBtnFilterDelete.Click += new EventHandler(this.toolBtnFilterDelete_Click);
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new Size(6, 25);
            this.toolBtnPrevYear.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnPrevYear.Image = (Image)global::DailyReportN.Properties.Resources.arrowPrev;
            this.toolBtnPrevYear.ImageTransparentColor = Color.Magenta;
            this.toolBtnPrevYear.Name = "toolBtnPrevYear";
            this.toolBtnPrevYear.Size = new Size(23, 22);
            this.toolBtnPrevYear.Text = "Предыдущий год";
            this.toolBtnPrevYear.Click += new EventHandler(this.toolBtnPrevYear_Click);

            this.toolBtnNextYear.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnNextYear.Image = (Image)global::DailyReportN.Properties.Resources.arrowNext;
            this.toolBtnNextYear.ImageTransparentColor = Color.Magenta;
            this.toolBtnNextYear.Name = "toolBtnNextYear";
            this.toolBtnNextYear.Size = new Size(23, 22);
            this.toolBtnNextYear.Text = "Следующий год";
            this.toolBtnNextYear.Click += new EventHandler(this.toolBtnNextYear_Click);

            this.dgvActDetection.AllowUserToAddRows = false;
            this.dgvActDetection.AllowUserToDeleteRows = false;
            this.dgvActDetection.AllowUserToOrderColumns = true;
            this.dgvActDetection.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
            this.dgvActDetection.AutoGenerateColumns = false;
            dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle.BackColor = SystemColors.Control;
            dataGridViewCellStyle.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
            this.dgvActDetection.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
            this.dgvActDetection.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvActDetection.Columns.AddRange(new DataGridViewColumn[]
            {
                this.numrequestDataGridViewTextBoxColumn,
                this.numDocDataGridViewTextBoxColumn,
                this.dateDocDgvColumn,
                this.typeDocNameDataGridViewTextBoxColumn,
                this.divisionDataGridViewTextBoxColumn,
                this.schmObjNameDataGridViewTextBoxColumn,
                this.netRegionSubDgvColumn,
                this.numcrashDgvColumn,
                this.defectLocationDataGridViewTextBoxColumn,
                this.reasonDataGridViewTextBoxColumn,
                this.divisionApplyDataGridViewTextBoxColumn,
                this.isLaboratoryDgvColumn,
                this.dateApplyDgvColumn,
                this.isApplyDgvColumn,
                this.workerApplyDataGridViewTextBoxColumn,
                this.completedWorkDataGridViewTextBoxColumn,
                this.compilerDataGridViewTextBoxColumn,
                this.InstructionDgvColumn,
                this.nameOwnerDgvColumn,
                this.dateOwnerDgvColumn,
                this.comletedWorkTextDataGridViewTextBoxColumn,
                this.KodPTSDgvColumn,
                this.kodPTSStrDgvColumn,
                this.idParentDgvColumn,
                this.typeDocDgvColumn,
                this.idDataGridViewTextBoxColumn,
                this.signCrashTypeDgvActDetection,
                this.signCrashNameDgvActDetection,
                this.typeEquipDgvActDetection,
                this.typeEquipNameDgvActDetection,
                this.reasonCrashEquipTypeDgvActDetection,
                this.reasonCrashEquipNameDgvActDetection,
                this.reasonCrashTypeDgvActDetection,
                this.reasonCrashNameDgvActDetection
            });
            this.dgvActDetection.DataSource = this.bsDamage;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            this.dgvActDetection.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvActDetection.Location = new Point(0, 0);
            this.dgvActDetection.Name = "dgvActDetection";
            this.dgvActDetection.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            this.dgvActDetection.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvActDetection.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvActDetection.Size = new Size(760, 577);
            this.dgvActDetection.TabIndex = 0;
            this.dgvActDetection.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvActDetection_CellDoubleClick);
            this.dgvActDetection.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvActDetection_CellFormatting);
            this.dgvActDetection.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvActDetection_CellMouseClick);
            this.dgvActDetection.RowPostPaint += new DataGridViewRowPostPaintEventHandler(this.dgvActDetection_RowPostPaint);

            this.numrequestDataGridViewTextBoxColumn.DataPropertyName = "numrequest";
            this.numrequestDataGridViewTextBoxColumn.HeaderText = "№ заявки";
            this.numrequestDataGridViewTextBoxColumn.Name = "numrequestDataGridViewTextBoxColumn";
            this.numrequestDataGridViewTextBoxColumn.ReadOnly = true;
            this.numrequestDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.numDocDataGridViewTextBoxColumn.DataPropertyName = "numDoc";
            this.numDocDataGridViewTextBoxColumn.HeaderText = "№ документа";
            this.numDocDataGridViewTextBoxColumn.Name = "numDocDataGridViewTextBoxColumn";
            this.numDocDataGridViewTextBoxColumn.ReadOnly = true;
            this.numDocDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.numDocDataGridViewTextBoxColumn.Visible = false;
            this.dateDocDgvColumn.DataPropertyName = "dateDoc";
            this.dateDocDgvColumn.HeaderText = "Дата заявки";
            this.dateDocDgvColumn.Name = "dateDocDgvColumn";
            this.dateDocDgvColumn.ReadOnly = true;
            this.dateDocDgvColumn.Resizable = DataGridViewTriState.True;
            this.typeDocNameDataGridViewTextBoxColumn.DataPropertyName = "TypeDocName";
            this.typeDocNameDataGridViewTextBoxColumn.HeaderText = "Тип";
            this.typeDocNameDataGridViewTextBoxColumn.Name = "typeDocNameDataGridViewTextBoxColumn";
            this.typeDocNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeDocNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.typeDocNameDataGridViewTextBoxColumn.Visible = false;
            this.divisionDataGridViewTextBoxColumn.DataPropertyName = "Division";
            this.divisionDataGridViewTextBoxColumn.HeaderText = "Подразделение";
            this.divisionDataGridViewTextBoxColumn.Name = "divisionDataGridViewTextBoxColumn";
            this.divisionDataGridViewTextBoxColumn.ReadOnly = true;
            this.divisionDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.divisionDataGridViewTextBoxColumn.Visible = false;
            this.schmObjNameDataGridViewTextBoxColumn.DataPropertyName = "schmObjName";
            this.schmObjNameDataGridViewTextBoxColumn.HeaderText = "Электроустановка";
            this.schmObjNameDataGridViewTextBoxColumn.Name = "schmObjNameDataGridViewTextBoxColumn";
            this.schmObjNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.schmObjNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.schmObjNameDataGridViewTextBoxColumn.Width = 200;
            this.netRegionSubDgvColumn.DataPropertyName = "NetRegionSub";
            this.netRegionSubDgvColumn.HeaderText = "Сетевой район";
            this.netRegionSubDgvColumn.Name = "netRegionSubDgvColumn";
            this.netRegionSubDgvColumn.ReadOnly = true;
            this.numcrashDgvColumn.DataPropertyName = "numcrash";
            this.numcrashDgvColumn.HeaderText = "Номер аварии";
            this.numcrashDgvColumn.Name = "numcrashDgvColumn";
            this.numcrashDgvColumn.ReadOnly = true;
            this.defectLocationDataGridViewTextBoxColumn.DataPropertyName = "defectLocation";
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            this.defectLocationDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.defectLocationDataGridViewTextBoxColumn.HeaderText = "Место повреждения";
            this.defectLocationDataGridViewTextBoxColumn.Name = "defectLocationDataGridViewTextBoxColumn";
            this.defectLocationDataGridViewTextBoxColumn.ReadOnly = true;
            this.defectLocationDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.defectLocationDataGridViewTextBoxColumn.Visible = false;
            this.reasonDataGridViewTextBoxColumn.DataPropertyName = "Reason";
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            this.reasonDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.reasonDataGridViewTextBoxColumn.HeaderText = "Причина";
            this.reasonDataGridViewTextBoxColumn.Name = "reasonDataGridViewTextBoxColumn";
            this.reasonDataGridViewTextBoxColumn.ReadOnly = true;
            this.reasonDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.reasonDataGridViewTextBoxColumn.Visible = false;
            this.divisionApplyDataGridViewTextBoxColumn.DataPropertyName = "DivisionApply";
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            this.divisionApplyDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.divisionApplyDataGridViewTextBoxColumn.HeaderText = "Подразделение исполнитель";
            this.divisionApplyDataGridViewTextBoxColumn.Name = "divisionApplyDataGridViewTextBoxColumn";
            this.divisionApplyDataGridViewTextBoxColumn.ReadOnly = true;
            this.divisionApplyDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.divisionApplyDataGridViewTextBoxColumn.Visible = false;
            this.isLaboratoryDgvColumn.DataPropertyName = "isLaboratory";
            this.isLaboratoryDgvColumn.HeaderText = "ПЛ";
            this.isLaboratoryDgvColumn.Name = "isLaboratoryDgvColumn";
            this.isLaboratoryDgvColumn.ReadOnly = true;
            this.isLaboratoryDgvColumn.Visible = false;
            this.isLaboratoryDgvColumn.Width = 40;
            this.dateApplyDgvColumn.DataPropertyName = "dateApply";
            this.dateApplyDgvColumn.HeaderText = "Дата устранения";
            this.dateApplyDgvColumn.Name = "dateApplyDgvColumn";
            this.dateApplyDgvColumn.ReadOnly = true;
            this.dateApplyDgvColumn.Resizable = DataGridViewTriState.True;
            this.dateApplyDgvColumn.Visible = false;
            this.isApplyDgvColumn.DataPropertyName = "isApply";
            this.isApplyDgvColumn.HeaderText = "Выполнено";
            this.isApplyDgvColumn.Name = "isApplyDgvColumn";
            this.isApplyDgvColumn.ReadOnly = true;
            this.isApplyDgvColumn.Resizable = DataGridViewTriState.True;
            this.isApplyDgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.isApplyDgvColumn.Visible = false;
            this.workerApplyDataGridViewTextBoxColumn.DataPropertyName = "workerApply";
            this.workerApplyDataGridViewTextBoxColumn.HeaderText = "Выполнил";
            this.workerApplyDataGridViewTextBoxColumn.Name = "workerApplyDataGridViewTextBoxColumn";
            this.workerApplyDataGridViewTextBoxColumn.ReadOnly = true;
            this.workerApplyDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.workerApplyDataGridViewTextBoxColumn.Visible = false;
            this.completedWorkDataGridViewTextBoxColumn.DataPropertyName = "completedWork";
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            this.completedWorkDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.completedWorkDataGridViewTextBoxColumn.HeaderText = "Выполненная работа";
            this.completedWorkDataGridViewTextBoxColumn.Name = "completedWorkDataGridViewTextBoxColumn";
            this.completedWorkDataGridViewTextBoxColumn.ReadOnly = true;
            this.completedWorkDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.completedWorkDataGridViewTextBoxColumn.Visible = false;
            this.compilerDataGridViewTextBoxColumn.DataPropertyName = "compiler";
            this.compilerDataGridViewTextBoxColumn.HeaderText = "Составитель";
            this.compilerDataGridViewTextBoxColumn.Name = "compilerDataGridViewTextBoxColumn";
            this.compilerDataGridViewTextBoxColumn.ReadOnly = true;
            this.compilerDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.compilerDataGridViewTextBoxColumn.Visible = false;
            this.InstructionDgvColumn.DataPropertyName = "Instruction";
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            this.InstructionDgvColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.InstructionDgvColumn.HeaderText = "Указания";
            this.InstructionDgvColumn.Name = "InstructionDgvColumn";
            this.InstructionDgvColumn.ReadOnly = true;
            this.InstructionDgvColumn.Visible = false;
            this.InstructionDgvColumn.Width = 120;
            this.nameOwnerDgvColumn.DataPropertyName = "ownerName";
            this.nameOwnerDgvColumn.HeaderText = "Автор";
            this.nameOwnerDgvColumn.Name = "nameOwnerDgvColumn";
            this.nameOwnerDgvColumn.ReadOnly = true;
            this.nameOwnerDgvColumn.Visible = false;
            this.dateOwnerDgvColumn.DataPropertyName = "dateOwner";
            this.dateOwnerDgvColumn.HeaderText = "Дата создания";
            this.dateOwnerDgvColumn.Name = "dateOwnerDgvColumn";
            this.dateOwnerDgvColumn.ReadOnly = true;
            this.dateOwnerDgvColumn.Visible = false;
            this.comletedWorkTextDataGridViewTextBoxColumn.DataPropertyName = "ComletedWorkText";
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.True;
            this.comletedWorkTextDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.comletedWorkTextDataGridViewTextBoxColumn.HeaderText = "Выполненная работа текст";
            this.comletedWorkTextDataGridViewTextBoxColumn.Name = "comletedWorkTextDataGridViewTextBoxColumn";
            this.comletedWorkTextDataGridViewTextBoxColumn.ReadOnly = true;
            this.comletedWorkTextDataGridViewTextBoxColumn.Visible = false;
            this.KodPTSDgvColumn.DataPropertyName = "KodPTS";
            dataGridViewCellStyle10.Format = "N0";
            dataGridViewCellStyle10.NullValue = null;
            this.KodPTSDgvColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.KodPTSDgvColumn.HeaderText = "Код повреждения";
            this.KodPTSDgvColumn.Name = "KodPTSDgvColumn";
            this.KodPTSDgvColumn.ReadOnly = true;
            this.KodPTSDgvColumn.Visible = false;
            this.kodPTSStrDgvColumn.DataPropertyName = "KodPTSStr";
            this.kodPTSStrDgvColumn.HeaderText = "Код повреждения (стр)";
            this.kodPTSStrDgvColumn.Name = "kodPTSStrDgvColumn";
            this.kodPTSStrDgvColumn.ReadOnly = true;
            this.kodPTSStrDgvColumn.Resizable = DataGridViewTriState.True;
            this.kodPTSStrDgvColumn.Visible = false;
            this.idParentDgvColumn.DataPropertyName = "idParent";
            this.idParentDgvColumn.HeaderText = "Родитель";
            this.idParentDgvColumn.Name = "idParentDgvColumn";
            this.idParentDgvColumn.ReadOnly = true;
            this.idParentDgvColumn.Visible = false;
            this.typeDocDgvColumn.DataPropertyName = "TypeDoc";
            this.typeDocDgvColumn.HeaderText = "TypeDoc";
            this.typeDocDgvColumn.Name = "typeDocDgvColumn";
            this.typeDocDgvColumn.ReadOnly = true;
            this.typeDocDgvColumn.Visible = false;
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            this.signCrashTypeDgvActDetection.DataPropertyName = "signCrashType";
            this.signCrashTypeDgvActDetection.HeaderText = "Код учетного признака аварии";
            this.signCrashTypeDgvActDetection.Name = "signCrashTypeDgvActDetection";
            this.signCrashTypeDgvActDetection.ReadOnly = true;
            this.signCrashTypeDgvActDetection.Resizable = DataGridViewTriState.True;
            this.signCrashNameDgvActDetection.DataPropertyName = "signCrashName";
            this.signCrashNameDgvActDetection.HeaderText = "Учетный признак аварии";
            this.signCrashNameDgvActDetection.Name = "signCrashNameDgvActDetection";
            this.signCrashNameDgvActDetection.ReadOnly = true;
            this.signCrashNameDgvActDetection.Resizable = DataGridViewTriState.True;
            this.typeEquipDgvActDetection.DataPropertyName = "typeEquip";
            this.typeEquipDgvActDetection.HeaderText = "Код оборудования";
            this.typeEquipDgvActDetection.Name = "typeEquipDgvActDetection";
            this.typeEquipDgvActDetection.ReadOnly = true;
            this.typeEquipDgvActDetection.Resizable = DataGridViewTriState.True;
            this.typeEquipNameDgvActDetection.DataPropertyName = "typeEquipName";
            this.typeEquipNameDgvActDetection.HeaderText = "Вид оборудования";
            this.typeEquipNameDgvActDetection.Name = "typeEquipNameDgvActDetection";
            this.typeEquipNameDgvActDetection.ReadOnly = true;
            this.typeEquipNameDgvActDetection.Resizable = DataGridViewTriState.True;
            this.reasonCrashEquipTypeDgvActDetection.DataPropertyName = "reasonCrashEquipType";
            this.reasonCrashEquipTypeDgvActDetection.HeaderText = "Код технической причины";
            this.reasonCrashEquipTypeDgvActDetection.Name = "reasonCrashEquipTypeDgvActDetection";
            this.reasonCrashEquipTypeDgvActDetection.ReadOnly = true;
            this.reasonCrashEquipTypeDgvActDetection.Resizable = DataGridViewTriState.True;
            this.reasonCrashEquipNameDgvActDetection.DataPropertyName = "reasonCrashEquipName";
            this.reasonCrashEquipNameDgvActDetection.HeaderText = "Техническая причина";
            this.reasonCrashEquipNameDgvActDetection.Name = "reasonCrashEquipNameDgvActDetection";
            this.reasonCrashEquipNameDgvActDetection.ReadOnly = true;
            this.reasonCrashEquipNameDgvActDetection.Resizable = DataGridViewTriState.True;
            this.reasonCrashTypeDgvActDetection.DataPropertyName = "reasonCrashType";
            this.reasonCrashTypeDgvActDetection.HeaderText = "Код организ. причины аварии";
            this.reasonCrashTypeDgvActDetection.Name = "reasonCrashTypeDgvActDetection";
            this.reasonCrashTypeDgvActDetection.ReadOnly = true;
            this.reasonCrashTypeDgvActDetection.Resizable = DataGridViewTriState.True;
            this.reasonCrashNameDgvActDetection.DataPropertyName = "reasonCrashName";
            this.reasonCrashNameDgvActDetection.HeaderText = "Организ. причина аварии";
            this.reasonCrashNameDgvActDetection.Name = "reasonCrashNameDgvActDetection";
            this.reasonCrashNameDgvActDetection.ReadOnly = true;
            this.reasonCrashNameDgvActDetection.Resizable = DataGridViewTriState.True;
            this.bsDamage.DataMember = "vJ_Damage";
            this.bsDamage.DataSource = this.dsDamage;
            this.dsDamage.DataSetName = "DataSetDamage";
            this.dsDamage.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
            this.toolItemAdd.Image = (Image)global::DailyReportN.Properties.Resources.Add;
            this.toolItemAdd.Name = "toolItemAdd";
            this.toolItemAdd.Size = new Size(135, 26);
            this.toolItemAdd.Text = "Добавить";
            this.toolItemAdd.Click += new EventHandler(this.toolBtnAdd_Click);
            this.toolItemEdit.Image = (Image)global::DailyReportN.Properties.Resources.Edit;
            this.toolItemEdit.Name = "toolItemEdit";
            this.toolItemEdit.Size = new Size(135, 26);
            this.toolItemEdit.Text = "Изменить";
            this.toolItemEdit.Click += new EventHandler(this.toolBtnEdit_Click);
            this.toolItemInfo.Image = (Image)global::DailyReportN.Properties.Resources.ElementInformation;
            this.toolItemInfo.Name = "toolItemInfo";
            this.toolItemInfo.Size = new Size(135, 26);
            this.toolItemInfo.Text = "Просмотр";
            this.toolItemInfo.Click += new EventHandler(this.toolBtnInfo_Click);
            this.toolItemDel.Image = (Image)global::DailyReportN.Properties.Resources.Delete;
            this.toolItemDel.Name = "toolItemDel";
            this.toolItemDel.Size = new Size(135, 26);
            this.toolItemDel.Text = "Удалить";
            this.toolItemDel.Click += new EventHandler(this.toolBtnDel_Click);
            this.contextMenuDamage.ImageScalingSize = new Size(20, 20);
            this.contextMenuDamage.Items.AddRange(new ToolStripItem[]
            {
                this.toolItemAdd,
                this.toolItemEdit,
                this.toolItemInfo,
                this.toolItemDel
            });
            this.contextMenuDamage.Name = "contextMenuDamage";
            this.contextMenuDamage.Size = new Size(136, 108);
            this.contextMenuDamage.Opening += new CancelEventHandler(this.contextMenuDamage_Opening);
            this.tsMenuReportAccidents.Name = "tsMenuReportAccidents";
            this.tsMenuReportAccidents.Size = new Size(270, 22);
            this.tsMenuReportAccidents.Text = "Перечень аварий";
            this.tsMenuReportAccidents.Click += new EventHandler(this.tsMenuReportAccidents_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(1022, 602);
            base.Controls.Add(this.splitContainer);
            base.Controls.Add(this.toolStrip);
            base.Name = "FormJournalActDetection";
            this.Text = "Журнал актов расследования (N2)";
            base.FormClosed += new FormClosedEventHandler(this.FormJournalActDetection_FormClosed);
            base.Load += new EventHandler(this.FormJournalActDetection_Load);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            this.toolStripTreeSchmObj.ResumeLayout(false);
            this.toolStripTreeSchmObj.PerformLayout();
            this.toolStripFilter.ResumeLayout(false);
            this.toolStripFilter.PerformLayout();
            ((ISupportInitialize)this.dgvActDetection).EndInit();
            ((ISupportInitialize)this.bsDamage).EndInit();
            ((ISupportInitialize)this.dsDamage).EndInit();
            this.contextMenuDamage.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }



        private ToolStrip toolStrip;

        private SplitContainer splitContainer;

        private DateTimePicker dtpFilterEnd;

        private Label label2;

        private DateTimePicker dtpFilterBeg;

        private Label label1;

        private ToolStrip toolStripFilter;

        private ToolStripButton toolBtnFilterApply;

        private ToolStripButton toolBtnFilterDelete;

        private ToolStripButton toolBtnPrevYear;

        private ToolStripButton toolBtnNextYear;

        private ToolStripButton toolBtnEdit;

        private DataGridViewExcelFilter dgvActDetection;

        private BindingSource bsDamage;

        private DailyReportN.DataSet.dsDamage dsDamage;

        private ToolStripButton toolBtnInfo;

        private TreeViewSchmObjects treeViewSchmObjects;

        private ToolStrip toolStripTreeSchmObj;

        private ToolStripButton toolBtnFindTreeSchmObj;

        private ToolStripTextBox txtFindTreeSchmObj;

        private ToolStripButton toolBtnFindPrevTreeSchmObj;

        private ToolStripButton toolBtnFindNextTreeSchmObj;

        private CheckBox checkBoxWhereSub;

        private ToolStripButton toolBtnDel;

        private ToolStripSeparator toolStripSeparator1;

        private ToolStripButton toolBtnRefresh;

        private ToolStripSeparator toolStripSeparator2;

        private ToolStripButton toolBtnFind;

        private ToolStripTextBox txtFind;

        private ToolStripButton toolBtnFindPrev;

        private ToolStripButton toolBtnFindNext;

        private ToolStripSeparator toolStripSeparator3;

        private ToolStripDropDownButton toolBtnReport;

        private ToolStripSeparator toolStripSeparator4;

        private ToolStripDropDownButton toolBTnLoadOld;

        private ToolStripMenuItem toolBtnLoadOldDamageLV;

        private ToolStripMenuItem toolBtnLoadOldDefect;

        private ToolStripButton toolBtnDamageNoApply;

        private ToolStripButton toolBtnExportExcel;

        private ToolStripButton toolBtnPrint;

        private ToolStripMenuItem toolBtnLoadAbnDefectLV;

        private ToolStripMenuItem toolBtnLoadOldDamageНV;

        private ToolStripButton toolBtnAdd;

        private ToolStripMenuItem toolItemAdd;

        private ToolStripMenuItem toolItemEdit;

        private ToolStripMenuItem toolItemInfo;

        private ToolStripMenuItem toolItemDel;

        private ContextMenuStrip contextMenuDamage;

        private DataGridViewFilterTextBoxColumn numrequestDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn numDocDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn dateDocDgvColumn;

        private DataGridViewFilterTextBoxColumn typeDocNameDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn divisionDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn schmObjNameDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn netRegionSubDgvColumn;

        private DataGridViewFilterTextBoxColumn numcrashDgvColumn;

        private DataGridViewFilterTextBoxColumn defectLocationDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn reasonDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn divisionApplyDataGridViewTextBoxColumn;

        private DataGridViewFilterCheckBoxColumn isLaboratoryDgvColumn;

        private DataGridViewFilterTextBoxColumn dateApplyDgvColumn;

        private DataGridViewFilterCheckBoxColumn isApplyDgvColumn;

        private DataGridViewFilterTextBoxColumn workerApplyDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn completedWorkDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn compilerDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn InstructionDgvColumn;

        private DataGridViewFilterTextBoxColumn nameOwnerDgvColumn;

        private DataGridViewFilterTextBoxColumn dateOwnerDgvColumn;

        private DataGridViewTextBoxColumn comletedWorkTextDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn KodPTSDgvColumn;

        private DataGridViewFilterTextBoxColumn kodPTSStrDgvColumn;

        private DataGridViewTextBoxColumn idParentDgvColumn;

        private DataGridViewTextBoxColumn typeDocDgvColumn;

        private DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;

        private DataGridViewFilterTextBoxColumn signCrashTypeDgvActDetection;

        private DataGridViewFilterTextBoxColumn signCrashNameDgvActDetection;

        private DataGridViewFilterTextBoxColumn typeEquipDgvActDetection;

        private DataGridViewFilterTextBoxColumn typeEquipNameDgvActDetection;

        private DataGridViewFilterTextBoxColumn reasonCrashEquipTypeDgvActDetection;

        private DataGridViewFilterTextBoxColumn reasonCrashEquipNameDgvActDetection;

        private DataGridViewFilterTextBoxColumn reasonCrashTypeDgvActDetection;

        private DataGridViewFilterTextBoxColumn reasonCrashNameDgvActDetection;

        private ToolStripMenuItem tsMenuAmergencyShutdown;

        private ToolStripMenuItem tsMenuReportAccidents;
    }

}