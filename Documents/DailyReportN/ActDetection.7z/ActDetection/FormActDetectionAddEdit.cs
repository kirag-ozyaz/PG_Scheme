﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using ControlsLbr;
using ControlsLbr.DataGridViewExcelFilter;
using ControlsLbr.ReportViewerRus;
using DataSql;
//using Documents.Properties;
using FormLbr;
using Microsoft.Reporting.WinForms;

/// <summary>
/// Акт расследования
/// </summary>
namespace DailyReportN.JournalActDetection
{
    internal partial class FormActDetectionAddEdit : FormBase
    {
        private int? IdDocument;
        private int? IdParentDocument;
        private List<int> ListDamage;
        private bool isChangedData;
        private bool flagViewDoc;
        /// <summary>
        /// тип аварийного документа
        /// null - значит документа основания нет
        /// </summary>
        private int? TypeDocDamage = null;


        /// <summary>
        ///  вернуть режим просмотра документа
        /// </summary>
        /// <returns></returns>
        internal bool GetFormViewMode()
        {
            return this.flagViewDoc;
        }
        /// <summary>
        /// установить режим просмотра документа, при открытии из других документов и журналов 
        /// </summary>
        internal void SetFormViewMode(bool flag)
        {
            this.flagViewDoc = flag;
            this.ControlBlockingOtherDocuments();
        }
        /// <summary>
        /// блокировка контролов из других документов
        /// </summary>
        internal int? GetIdDocument()
        {
            return this.IdDocument;
        }

        internal FormActDetectionAddEdit()
        {
            this.InitializeComponent();
            this.FillDateInitValues();
        }

        internal FormActDetectionAddEdit(int? id = null)
        {
            this.InitializeComponent();
            this.IdDocument = id;
            this.FillDateInitValues();
        }

        internal FormActDetectionAddEdit(int? idParent = null, List<int> listDamage = null)
        {
            this.InitializeComponent();
            this.FillDateInitValues();
            this.IdParentDocument = idParent;
            this.ListDamage = listDamage;
        }

        /// <summary>
        /// заполнение дат начальными значениями
        /// </summary>
        private void FillDateInitValues()
        {
            this.dtpDateDoc.Value = DateTime.Now;
            this.dtpApply.Value = DateTime.Now;
            this.dtpLastDateTest.Value = DateTime.Now;
            this.dtpTimeRecovery.Value = DateTime.Now;
            this.dtpLastDateTest.MaxDate = (DateTime)this.dtpTimeRecovery.Value;
        }

        private void FormActDetectionAddEdit_Load(object sender, EventArgs e)
        {
            this.InitTextBoxs();
            this.GetLinksCharacteristicsActDetection();
            this.FillComboBoxMemberComission();
            this.FillComboBoxDivision();
            this.FillComboBoxKontragents();
            this.FillComboBoxSignCrash();
            this.FillComboBoxTypeEquipment();
            this.FillComboBoxReasonCrashEquipment();
            this.FillComboBoxReasonCrash();
            this.FillComboBoxStatusBeforeCrash();
            this.FillComboBoxStatusCurrentCrash();
            this.FillComboBoxIdNoCrashMeasure();
            this.FillComboBoxIdDefection();
            this.FillComboBoxIdNPA();
            this.FillComboBoxReasonBeginCrash();
            this.FillComboBoxClassifierDamage();
            this.FillComboBoxFault();
            this.InitComboBoxs();
            if (this.IdDocument == null)
            {
                DataRow dataRow = this.dataSetDamage.tJ_Damage.NewRow();
                dataRow["TypeDoc"] = (int)eTypeDocuments.ActDetection;
                if (this.IdParentDocument != null)
                {
                    dataRow["idParent"] = this.IdParentDocument.Value;
                    this.GetDataFromDocumentParent(this.IdParentDocument.Value, dataRow);
                }
                this.dataSetDamage.tJ_Damage.Rows.Add(dataRow);
                this.InitNewDocumentActDetection();
                this.FillWithTableDamageCharacter(this.ListDamage);
                this.InitTableNoCrashMeasure();
                this.InitTableDefection();
            }
            else
            {
                base.SelectSqlData(this.dataSetDamage.tJ_Damage, true, " where id = " + this.IdDocument.Value.ToString(), null, false, 0);
                if (this.dataSetDamage.tJ_Damage.Rows.Count > 0)
                {
                    if (this.dataSetDamage.tJ_Damage.Rows[0]["idParent"] != DBNull.Value)
                    {
                        this.IdParentDocument = new int?(Convert.ToInt32(this.dataSetDamage.tJ_Damage.Rows[0]["idParent"]));
                    }
                    if (this.dataSetDamage.tJ_Damage.Rows[0]["isApply"] != DBNull.Value && Convert.ToBoolean(this.dataSetDamage.tJ_Damage.Rows[0]["isApply"]))
                    {
                        this.cmbWorkerApply.ReadOnly = true;
                        this.dtpApply.Enabled = false;
                    }

                }
                base.SelectSqlData(this.dataSetDamage.tJ_DamageActDetection, true, " where idDamage = " + this.IdDocument.Value.ToString(), null, false, 0);
                if (this.dataSetDamage.tJ_DamageActDetection.Rows.Count == 0)
                {
                    this.InitNewDocumentActDetection();
                }
                else
                {
                    if (this.dataSetDamage.tJ_DamageActDetection.Rows[0]["NoCrashMeasure"] != DBNull.Value)
                    {
                        string NoCrashMeasure = this.dataSetDamage.tJ_DamageActDetection.Rows[0]["NoCrashMeasure"].ToString();
                        if (!string.IsNullOrEmpty(NoCrashMeasure))
                        {
                            this.dataTableNoCrashMeasure.ReadXml(new StringReader(NoCrashMeasure));
                        }
                    }
                    if (this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Defection"] != DBNull.Value)
                    {
                        string Defection = this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Defection"].ToString();
                        if (!string.IsNullOrEmpty(Defection))
                        {
                            this.dataTableDefection.ReadXml(new StringReader(Defection));
                        }
                    }
                }
                this.LoadTableDamageCharacter();
            }
            this.FillComboBoxsMemberComission();
            if (this.dataSetDamage.tJ_Damage.Rows.Count > 0)
            {
                if (this.dataSetDamage.tJ_Damage.Rows[0]["idParent"] != DBNull.Value)
                {
                    this.FillDateEndCrashLocal(Convert.ToInt32(this.dataSetDamage.tJ_Damage.Rows[0]["idParent"]));
                }
                if (this.dataSetDamage.tJ_Damage.Rows[0]["idSchmObj"] != DBNull.Value)
                {
                    this.txtSchmObj.Text = base.CallSQLScalarFunction("dbo.fn_Schm_GetFullNameObjById", new string[]
                    {
                        this.dataSetDamage.tJ_Damage.Rows[0]["idSchmObj"].ToString()
                    }).ToString();
                }
                //
                //TypeDocDamage = (int)this.dataSetDamage.tJ_Damage.Rows[0]["TypeDoc"];
            }
            if (string.IsNullOrEmpty(this.txtLengthOverload.Text))
            {
                this.txtLengthOverload.Text = "0";
            }
            this.FillOwnerDocument();
            this.ControlSelectionLengthComboBox(base.Controls);
            this.isChangedData = false;
            // делаем заголовок документа
            if (this.IdDocument == null || this.IdDocument == -1)
                this.Text = "Новый:" + this.Text;
            else
                this.Text = this.Text + " №" + this.txtNumRequest.Text + " (авария №" + this.txtNumCrash.Text + ")" + " от " + this.dtpDateOwner.Value.ToShortDateString();
        }

        private void FormActDetectionAddEdit_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (base.DialogResult != DialogResult.OK)
            {
                if (!this.isChangedData || this.GetFormViewMode() || MessageBox.Show("Сохранить внесенные изменения", "Сохранение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    base.DialogResult = DialogResult.Cancel;
                    return;
                }
            }
            if (!this.CheckRequiredField())
            {
                MessageBox.Show("Введите обязательные поля для заполнения");
                base.DialogResult = DialogResult.None;
                e.Cancel = true;
                return;
            }
            if (this.SaveDocument())
            {
                base.DialogResult = DialogResult.OK;
                return;
            }
            base.DialogResult = DialogResult.None;
            e.Cancel = true;
        }

        private void InitTextBoxs()
        {
            this.txtNumCrash.DataBindings.Clear();
            this.txtNumCrash.DataBindings.Add(new Binding("Text", this.dataSetDamage, "tJ_DamageActDetection.numCrash", true, DataSourceUpdateMode.OnPropertyChanged, ""));

            this.txtTotalComission.DataBindings.Clear();
            this.txtTotalComission.DataBindings.Add(new Binding("Text", this.dataSetDamage, "tJ_DamageActDetection.TotalComission", true, DataSourceUpdateMode.OnValidation, ""));
            this.dtpEndCrashLocal.Value = DateTime.Now;
            this.txtCountDefectEquipment.Enabled = true;

            this.txtPostChairman.Enabled = true;
            txtPostMemeber3.Enabled = true;

            this.txtPostMemeber2.Enabled = true;

            this.txtPostMemeber1.Enabled = true;

            this.txtOrder.Enabled = true;

            this.txtLengthOverload.DataBindings[0].NullValue = "0";
            foreach (object obj in this.tabControl1.TabPages)
            {
                ((TabPage)obj).Show();
            }
        }
        /// <summary>
        /// создание нового документа с начальными значениями
        /// </summary>
        private void InitNewDocumentActDetection()
        {
            DataRow dataRow = this.dataSetDamage.tJ_DamageActDetection.NewRow();
            dataRow["idDamage"] = -1;
            DataTable dataTable = this.CreateTableAbnType();
            base.SelectSqlData(dataTable, true, string.Format("where typeKontragent = {0} and deleted = 0 order by name", 1115), null, false, 0);
            if (dataTable.Rows.Count > 0)
            {
                dataRow["idOrg"] = dataTable.Rows[0]["idAbn"];
            }
            if (this.cmbSignCrash.DataSource != null && this.cmbSignCrash.DataSource is BindingSource && ((BindingSource)this.cmbSignCrash.DataSource).DataSource is DataTable)
            {
                DataRow[] array = ((DataTable)((BindingSource)this.cmbSignCrash.DataSource).DataSource).Select("Value = 2.3");
                if (array.Length != 0)
                {
                    dataRow["idSignCrash"] = array[0]["id"];
                }
            }
            if (this.cmbTypeEquipment.DataSource != null && this.cmbTypeEquipment.DataSource is BindingSource && ((BindingSource)this.cmbTypeEquipment.DataSource).DataSource is DataTable)
            {
                DataRow[] array2 = ((DataTable)((BindingSource)this.cmbTypeEquipment.DataSource).DataSource).Select("Value = 3.311");
                if (array2.Length != 0)
                {
                    dataRow["idTypeEquipment"] = array2[0]["id"];
                }
            }
            if (this.cmbReasonCrashEquipment.DataSource != null && this.cmbReasonCrashEquipment.DataSource is BindingSource && ((BindingSource)this.cmbReasonCrashEquipment.DataSource).DataSource is DataTable)
            {
                DataRow[] array3 = ((DataTable)((BindingSource)this.cmbReasonCrashEquipment.DataSource).DataSource).Select("Value = 4.12 and ParentKey = ';ReportDaily;ActDetection;ReasonCrashEquipment;'");
                if (array3.Length != 0)
                {
                    dataRow["idReasonCrashEquipment"] = array3[0]["id"];
                }
            }
            if (this.cmbReasonBeginCrash.DataSource != null && this.cmbReasonBeginCrash.DataSource is BindingSource && ((BindingSource)this.cmbReasonBeginCrash.DataSource).DataSource is DataTable)
            {
                DataRow[] array4 = ((DataTable)((BindingSource)this.cmbReasonBeginCrash.DataSource).DataSource).Select("Value = 4.12 and ParentKey = ';ReportDaily;ActDetection;ReasonBeginCrash;'");
                if (array4.Length != 0)
                {
                    dataRow["idReasonBeginCrash"] = array4[0]["id"];
                }
            }
            if (this.cmbStatusBeforeCrash.DataSource != null && this.cmbStatusBeforeCrash.DataSource is BindingSource && ((BindingSource)this.cmbStatusBeforeCrash.DataSource).DataSource is DataTable)
            {
                DataRow[] array5 = ((DataTable)((BindingSource)this.cmbStatusBeforeCrash.DataSource).DataSource).Select("Value = 2.01");
                if (array5.Length != 0)
                {
                    dataRow["idStatusBeforeCrash"] = array5[0]["id"];
                }
            }
            if (this.cmbStatusCurrentCrash.DataSource != null && this.cmbStatusCurrentCrash.DataSource is BindingSource && ((BindingSource)this.cmbStatusCurrentCrash.DataSource).DataSource is DataTable)
            {
                DataRow[] array6 = ((DataTable)((BindingSource)this.cmbStatusCurrentCrash.DataSource).DataSource).Select("Value = 2.201");
                if (array6.Length != 0)
                {
                    dataRow["idStatusCurrentCrash"] = array6[0]["id"];
                }
            }
            dataRow["idClassifierDamage"] = 2010;
            dataRow["idFault"] = 2020;
            this.dataSetDamage.tJ_DamageActDetection.Rows.Add(dataRow);
        }
        /// <summary>
        /// таблица противоаварийных мероприятий
        /// </summary>
        private void InitTableNoCrashMeasure()
        {
            DataRow dataRow = this.dataTableNoCrashMeasure.NewRow();
            dataRow["idNoCrashMeasure"] = 1963;
            DataTable dataTable = new SqlDataCommand(this.SqlSettings).SelectSqlData(string.Format("select idabn from vAbnType where typeKontragent = {0}", 1115));
            if (dataTable.Rows.Count > 0)
            {
                dataRow["idOrg"] = dataTable.Rows[0]["idabn"];
            }
            this.dataTableNoCrashMeasure.Rows.Add(dataRow);
        }
        /// <summary>
        /// таблица выявленных в ходе расследования нарушений требований
        /// </summary>
        private void InitTableDefection()
        {
            DataRow dataRow = this.dataTableDefection.NewRow();
            dataRow["idDefection"] = 1976;
            this.dataTableDefection.Rows.Add(dataRow);
        }
        /// <summary>
        /// Заполнить дату окончания (ликвидации) аварии, найти тип документа
        /// </summary>
        private void FillDateEndCrashLocal(int idParentDoc)
        {
            DataTable dataTable = new DataTable("vJ_Damage");
            dataTable.Columns.Add("numDoc", typeof(int));
            dataTable.Columns.Add("dateDoc", typeof(DateTime));
            dataTable.Columns.Add("typeDocName", typeof(string));
            dataTable.Columns.Add("nameDoc", typeof(string), "typedocname + isnull(' №' + convert(numDoc, System.String), ' №б/н') + isnull(' от ' + convert(dateDoc, System.String), '')");
            dataTable.Columns.Add("TypeDoc", typeof(int));
            dataTable.Columns.Add("dateApply", typeof(DateTime));
            base.SelectSqlData(dataTable, true, "where id = " + idParentDoc.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0)
            {
                this.txtParentDamage.Text = dataTable.Rows[0]["nameDoc"].ToString();
                this.TypeDocDamage = Convert.ToInt32(dataTable.Rows[0]["TypeDoc"]);
            }
            if (this.dataSetDamage.tJ_DamageActDetection.Rows.Count > 0)
            {
                if (this.TypeDocDamage == (int)eTypeDocuments.DamageHV)
                {
                    DataTable dataTable2 = new DataTable("tj_DamageOn");
                    dataTable2.Columns.Add("DateOn", typeof(DateTime));
                    base.SelectSqlData(dataTable2, true, "where idDamage = " + idParentDoc.ToString() + " order by DateOn desc", null, false, 0);
                    if (dataTable2.Rows.Count > 0)
                    {
                        this.dataSetDamage.tJ_DamageActDetection.Rows[0]["dateEndCrashLocal"] = dataTable2.Rows[0]["dateOn"];
                        return;
                    }
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["dateEndCrashLocal"] = DBNull.Value;
                }
                else if (this.TypeDocDamage == (int)eTypeDocuments.DamageLV)
                {
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["dateEndCrashLocal"] =  dataTable.Rows[0]["dateApply"];
                }
            }
        }
        /// <summary>
        /// заполнить автора документа
        /// </summary>
        private void FillOwnerDocument()
        {
            if (this.IdDocument == null)
            {
                DataTable dataTable = new DataTable("tUser");
                dataTable.Columns.Add("name", typeof(string));
                dataTable.Columns.Add("idWorker", typeof(string));
                base.SelectSqlData(dataTable, true, "where [login] = SYSTEM_USER", null, false, 0);
                if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["name"] != DBNull.Value)
                {
                    this.txtOwner.Text = dataTable.Rows[0]["name"].ToString();
                    return;
                }
            }
            else if (this.dataSetDamage.tJ_Damage.Rows.Count > 0 && this.dataSetDamage.tJ_Damage.Rows[0]["idOwner"] != DBNull.Value)
            {
                DataTable dataTable2 = new DataTable("tUser");
                dataTable2.Columns.Add("name", typeof(string));
                base.SelectSqlData(dataTable2, true, "where [idUser] = " + this.dataSetDamage.tJ_Damage.Rows[0]["idOwner"].ToString(), null, false, 0);
                if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["name"] != DBNull.Value)
                {
                    this.txtOwner.Text = dataTable2.Rows[0]["name"].ToString();
                }
            }
        }
        /// <summary>
        /// получить данные с документа родителя
        /// (подразделение, точку схемы, дату документа)
        /// </summary>
        private void GetDataFromDocumentParent(int IdParentDoc, DataRow row)
        {
            DataTable dataTable = new SqlDataCommand(this.SqlSettings).SelectSqlData("select pSub.idNetRegion, d.dateDoc, d.idSchmObj  from vj_damage d\r\n                                        left join vP_SubstationByNetRegion pSub on pSub.id = d.idSub\r\n                                        where d.id = " + IdParentDoc.ToString());
            if (dataTable.Rows.Count > 0)
            {
                row["idDivision"] = dataTable.Rows[0]["idNetRegion"];
                row["dateDoc"] = dataTable.Rows[0]["dateDoc"];
                row["idSchmObj"] = dataTable.Rows[0]["idSChmObj"];
            }
        }

        private DataTable CreateTableWorkerGroup()
        {
            Type type = Type.GetType("System.Int32");
            DataTable dataTable = new DataTable("vWorkerGroup");
            DataColumn dataColumn = new DataColumn("id", type);
            dataTable.Columns.Add(dataColumn);
            DataColumn column = new DataColumn("fio", Type.GetType("System.String"));
            dataTable.Columns.Add(column);
            DataColumn column2 = new DataColumn("GroupElectrical", type);
            dataTable.Columns.Add(column2);
            dataTable.PrimaryKey = new DataColumn[]
            {
            dataColumn
            };
            DataColumn dataColumn2 = new DataColumn("GroupRoman", Type.GetType("System.String"));
            dataColumn2.Expression = "IIF(groupElectrical = 1, 'I', IIF(groupElectrical = 2, 'II', IIF(groupelectrical=3, 'III', IIF(groupelectrical = 4, 'IV', iif(groupelectrical = 5, 'V', '')))))";
            dataTable.Columns.Add(dataColumn2);
            DataColumn dataColumn3 = new DataColumn("fioGroup", Type.GetType("System.String"));
            dataColumn3.Expression = "fio + ' (' + GroupRoman + ')'";
            dataTable.Columns.Add(dataColumn3);
            return dataTable;
        }

        private DataTable CreateTableClassifier()
        {
            DataTable dataTable = new DataTable("tR_Classifier");
            dataTable.Columns.Add("id", typeof(int));
            dataTable.Columns.Add("name", typeof(string));
            dataTable.Columns.Add("comment", typeof(string));
            dataTable.Columns.Add("ParentKey", typeof(string));
            dataTable.Columns.Add("value", typeof(decimal));
            DataColumn dataColumn = new DataColumn("nameComment", Type.GetType("System.String"));
            dataColumn.Expression = "name + ' ' + comment";
            dataTable.Columns.Add(dataColumn);
            return dataTable;
        }

        private DataTable CreateTableAbnType()
        {
            return new DataTable("vAbnType")
            {
                Columns =
            {
                {
                    "idAbn",
                    typeof(int)
                },
                {
                    "Name",
                    typeof(string)
                }
            }
            };
        }

        private void GetLinksCharacteristicsActDetection()
        {
            this.tblClassifier = this.CreateTableClassifier();
            base.SelectSqlData(this.tblClassifier, true, string.Format(" where (ParentKey in ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}',  \r\n                                        '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{15}', \r\n                                         '{16}', '{17}', '{18}', '{19}', '{20}') or ParentKey like '{14}%')\r\n                and isgroup = 0 and deleted = 0", new object[]
            {
            ";NetworkAreas;",
            ";ReportDaily;ActDetection;SignCrash;",
            ";ReportDaily;ActDetection;TypeEquipment;",
            ";ReportDaily;ActDetection;ReasonCrashEquipment;",
            ";ReportDaily;ActDetection;ReasonCrash;",
            ";ReportDaily;ActDetection;StatusBeforeCrash;",
            ";ReportDaily;ActDetection;StatusCurrentCrash;",
            ";ReportDaily;ActDetection;Defection;",
            ";ReportDaily;ActDetection;NPA;",
            ";ReportDaily;ActDetection;ReasonBeginCrash;",
            ";ReportDaily;ActDetection;Damage;",
            ";ReportDaily;ActDetection;Fault;",
            ";ReportDaily;ActDetection;NoCrashMeasure;",
            ";ReportDaily;ActDetection;Equipment;Params;",
            ";VoltageLevels;",
            ";ReportDaily;ActDetection;Equipment;NodeDetail;",
            ";ReportDaily;ActDetection;Equipment;NeutralState;",
            ";ReportDaily;ActDetection;Equipment;Material;",
            ";ReportDaily;ActDetection;Equipment;ClauseWork;",
            ";ReportDaily;ActDetection;Equipment;ChrDamage;",
            ";ReportDaily;ActDetection;Equipment;ReasonDamage;"
            }), null, false, 0);
        }

        private void FillComboBoxMemberComission()
        {
            DataTable dataTable = this.CreateTableWorkerGroup();
            base.SelectSqlData(dataTable, true, "where ParentKey like ';GroupWorker;DailyReport;MemberActDetection;' and dateEnd is null order by fio ", null, false, 0);
            this.cmbCompiler.DisplayMember = "FIO";
            this.cmbCompiler.ValueMember = "id";
            this.cmbCompiler.DataSource = dataTable;
            this.cmbCompiler.SelectedIndex = -1;

            this.cmbWorkerApply.DisplayMember = "FIO";
            this.cmbWorkerApply.ValueMember = "id";
            this.cmbWorkerApply.DataSource = dataTable.Copy();
            this.cmbWorkerApply.SelectedIndex = -1;

            this.cmbChairman.DisplayMember = "FIO";
            this.cmbChairman.ValueMember = "id";
            this.cmbChairman.DataSource = dataTable.Copy();
            this.cmbChairman.SelectedIndex = -1;

            this.cmbMemberComission1.DisplayMember = (this.cmbMemberComission2.DisplayMember = (this.cmbMemberComission3.DisplayMember = (this.cmbMemberComission4.DisplayMember = (this.cmbMemberComission5.DisplayMember = "FIO"))));
            this.cmbMemberComission1.ValueMember = (this.cmbMemberComission2.ValueMember = (this.cmbMemberComission3.ValueMember = (this.cmbMemberComission4.ValueMember = (this.cmbMemberComission5.ValueMember = "id"))));

            DataTable dataTable2 = dataTable.Copy();
            dataTable2.Columns["id"].AutoIncrement = true;
            dataTable2.Columns["id"].AutoIncrementSeed = -1L;
            dataTable2.Columns["id"].AutoIncrementStep = -1L;
            DataRow dataRow = dataTable2.NewRow();
            dataRow["FIO"] = "";
            dataRow.EndEdit();
            dataTable2.Rows.Add(dataRow);
            DataView defaultView = dataTable2.DefaultView;
            defaultView.Sort = "FIO asc";

            DataTable dataTable3 = defaultView.ToTable();

            this.cmbMemberComission1.DataSource = dataTable3.Copy();
            this.cmbMemberComission2.DataSource = dataTable3.Copy();
            this.cmbMemberComission3.DataSource = dataTable3.Copy();
            this.cmbMemberComission4.DataSource = dataTable3.Copy();
            this.cmbMemberComission5.DataSource = dataTable3.Copy();

            ListControl listControl = this.cmbMemberComission1;
            ListControl listControl2 = this.cmbMemberComission2;
            ListControl listControl3 = this.cmbMemberComission3;
            ListControl listControl4 = this.cmbMemberComission4;

            this.cmbMemberComission5.SelectedIndex = -1;
            listControl4.SelectedIndex = -1;
            listControl3.SelectedIndex = -1;
            listControl2.SelectedIndex = -1;
            listControl.SelectedIndex = -1;
        }

        private void FillComboBoxDivision()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';NetworkAreas;'";
            bindingSource.Sort = "name";
            this.cmbDivision.DisplayMember = "name";
            this.cmbDivision.ValueMember = "id";
            this.cmbDivision.DataSource = bindingSource;
            this.cmbDivision.SelectedIndex = -1;
        }

        private void FillComboBoxSignCrash()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;SignCrash;'";
            bindingSource.Sort = "value";
            this.cmbSignCrash.DisplayMember = "nameComment";
            this.cmbSignCrash.ValueMember = "id";
            this.cmbSignCrash.DataSource = bindingSource;
            this.cmbSignCrash.SelectedIndex = -1;
        }

        private void FillComboBoxTypeEquipment()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;TypeEquipment;'";
            bindingSource.Sort = "value";
            this.cmbTypeEquipment.DisplayMember = "nameComment";
            this.cmbTypeEquipment.ValueMember = "id";
            this.cmbTypeEquipment.DataSource = bindingSource;
            this.cmbTypeEquipment.SelectedIndex = -1;
        }

        private void FillComboBoxReasonCrashEquipment()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;ReasonCrashEquipment;'";
            bindingSource.Sort = "value";
            this.cmbReasonCrashEquipment.DisplayMember = "nameComment";
            this.cmbReasonCrashEquipment.ValueMember = "id";
            this.cmbReasonCrashEquipment.DataSource = bindingSource;
            this.cmbReasonCrashEquipment.SelectedIndex = -1;
        }

        private void FillComboBoxReasonCrash()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;ReasonCrash;'";
            bindingSource.Sort = "value";
            this.cmbReasonCrash.DisplayMember = "nameComment";
            this.cmbReasonCrash.ValueMember = "id";
            this.cmbReasonCrash.DataSource = bindingSource;
            this.cmbReasonCrash.SelectedIndex = -1;
        }

        private void FillComboBoxStatusBeforeCrash()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;StatusBeforeCrash;'";
            bindingSource.Sort = "value";
            this.cmbStatusBeforeCrash.DisplayMember = "nameComment";
            this.cmbStatusBeforeCrash.ValueMember = "id";
            this.cmbStatusBeforeCrash.DataSource = bindingSource;
            this.cmbStatusBeforeCrash.SelectedIndex = -1;
        }

        private void FillComboBoxStatusCurrentCrash()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;StatusCurrentCrash;'";
            bindingSource.Sort = "value";
            this.cmbStatusCurrentCrash.DisplayMember = "nameComment";
            this.cmbStatusCurrentCrash.ValueMember = "id";
            this.cmbStatusCurrentCrash.DataSource = bindingSource;
            this.cmbStatusCurrentCrash.SelectedIndex = -1;
        }

        private void FillComboBoxIdNoCrashMeasure()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;NoCrashMeasure;'";
            bindingSource.Sort = "value";
            this.idNoCrashMeasureColumn.DisplayMember = "name";
            this.idNoCrashMeasureColumn.ValueMember = "id";
            this.idNoCrashMeasureColumn.DataSource = bindingSource;
        }

        private void FillComboBoxIdDefection()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Defection;'";
            bindingSource.Sort = "value";
            this.idDefectionDataGridViewTextBoxColumn.DisplayMember = "comment";
            this.idDefectionDataGridViewTextBoxColumn.ValueMember = "id";
            this.idDefectionDataGridViewTextBoxColumn.DataSource = bindingSource;
        }

        private void FillComboBoxIdNPA()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;NPA;'";
            bindingSource.Sort = "value";
            this.idNPADgvColumn.DisplayMember = "name";
            this.idNPADgvColumn.ValueMember = "id";
            this.idNPADgvColumn.DataSource = bindingSource;
        }

        private void FillComboBoxReasonBeginCrash()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;ReasonBeginCrash;'";
            bindingSource.Sort = "value";
            this.cmbReasonBeginCrash.DisplayMember = "comment";
            this.cmbReasonBeginCrash.ValueMember = "id";
            this.cmbReasonBeginCrash.DataSource = bindingSource;
        }

        private void FillComboBoxClassifierDamage()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Damage;'";
            bindingSource.Sort = "value";
            this.cmbClassifierDamage.DisplayMember = "name";
            this.cmbClassifierDamage.ValueMember = "id";
            this.cmbClassifierDamage.DataSource = bindingSource;
        }

        private void FillComboBoxFault()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Fault;'";
            bindingSource.Sort = "value";
            this.cmbFault.DisplayMember = "name";
            this.cmbFault.ValueMember = "id";
            this.cmbFault.DataSource = bindingSource;
        }

        private void FillComboBoxKontragents()
        {
            DataTable dataTable = this.CreateTableAbnType();
            base.SelectSqlData(dataTable, true, string.Format("where typeKontragent = {0} and deleted = 0 order by name", 1877), null, false, 0);
            this.cmbOrg.DisplayMember = "name";
            this.cmbOrg.ValueMember = "idAbn";
            this.cmbOrg.DataSource = dataTable;
            this.cmbOrg.SelectedIndex = -1;

            this.idOrgColumn.DisplayMember = "name";
            this.idOrgColumn.ValueMember = "idAbn";
            this.idOrgColumn.DataSource = dataTable.Copy();

            this.idOrgDefectionDgvColumn.DisplayMember = "name";
            this.idOrgDefectionDgvColumn.ValueMember = "idAbn";
            this.idOrgDefectionDgvColumn.DataSource = dataTable.Copy();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        /// <summary>
        /// проверка заполнения обязательных полей
        /// </summary>
        private bool CheckRequiredField()
        {
            bool result = true;
            if (this.chkCrash.Checked)
            {
                if (string.IsNullOrEmpty(this.txtNumCrash.Text))
                {
                    result = false;
                    this.labelNumCrash.ForeColor = Color.Red;
                }
                if (new SqlDataCommand(this.SqlSettings).SelectSqlData(string.Format("select a.numCrash from tJ_DamageActDetection a\r\n                                            left join tj_damage d on d.id = a.idDamage\r\n                                            where a.numCrash = '{0}' and year(d.DateDoc) = {1} and d.id <> {2}", this.txtNumCrash.Text, this.dtpDateOwner.Value.Year, (this.GetIdDocument() == null) ? -1 : this.GetIdDocument().Value)).Rows.Count > 0)
                {
                    result = false;
                    this.labelNumCrash.ForeColor = Color.Red;
                }
            }
            return result;
        }

        private bool SaveDocument()
        {
            this.dataSetDamage.tJ_Damage.Rows[0].EndEdit();
            if (this.IdDocument == null)
            {
                this.IdDocument = new int?(base.InsertSqlDataOneRow(this.dataSetDamage, this.dataSetDamage.tJ_Damage));
                if (this.IdDocument == -1)
                {
                    this.IdDocument = null;
                    return false;
                }
            }
            else if (!base.UpdateSqlData(this.dataSetDamage.tJ_Damage))
            {
                return false;
            }
            return this.SaveTableDamageAddCharacter() && this.SaveTableDamageCharacter();
        }
        /// <summary>
        /// сохранение дополнительных характеристик
        /// </summary>
        /// <returns></returns>
        private bool SaveTableDamageAddCharacter()
        {
            if (this.dataSetDamage.tJ_DamageActDetection.Rows.Count > 0)
            {
                this.dataSetDamage.tJ_DamageActDetection.Rows[0]["idDamage"] = this.IdDocument.Value;
                if (this.dataTableNoCrashMeasure.Rows.Count == 0)
                {
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["NoCrashMeasure"] = DBNull.Value;
                }
                else
                {
                    StringWriter stringWriter = new StringWriter();
                    this.dataTableNoCrashMeasure.WriteXml(stringWriter, XmlWriteMode.WriteSchema, false);
                    string value = stringWriter.ToString();
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["NoCrashMeasure"] = value;
                }
                if (this.dataTableDefection.Rows.Count == 0)
                {
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Defection"] = DBNull.Value;
                }
                else
                {
                    StringWriter stringWriter2 = new StringWriter();
                    this.dataTableDefection.WriteXml(stringWriter2, XmlWriteMode.WriteSchema, false);
                    string value2 = stringWriter2.ToString();
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Defection"] = value2;
                }
                if (this.dataTableComission.Rows.Count == 0)
                {
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Comission"] = DBNull.Value;
                }
                else
                {
                    StringWriter stringWriter3 = new StringWriter();
                    this.dataTableComission.WriteXml(stringWriter3, XmlWriteMode.WriteSchema, false);
                    string value3 = stringWriter3.ToString();
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Comission"] = value3;
                }
                this.dataSetDamage.tJ_DamageActDetection.Rows[0].EndEdit();
                if (!base.InsertSqlData(this.dataSetDamage.tJ_DamageActDetection))
                {
                    return false;
                }
                if (!base.UpdateSqlData(this.dataSetDamage.tJ_DamageActDetection))
                {
                    return false;
                }
                base.SelectSqlData(this.dataSetDamage.tJ_DamageActDetection, true, "where idDamage = " + this.IdDocument.Value.ToString(), null, false, 0);
            }
            return true;
        }
        /// <summary>
        ///  сохранение характеристик повреждений
        /// </summary>
        /// <returns></returns>
        private bool SaveTableDamageCharacter()
        {
            foreach (DataRow dataRow in this.dataSetDamage.tJ_DamageCharacter.Rows)
            {
                if (dataRow.RowState != DataRowState.Deleted)
                {
                    dataRow["idDamage"] = this.IdDocument.Value;
                    dataRow.EndEdit();
                }
            }
            return base.InsertSqlData(this.dataSetDamage.tJ_DamageCharacter) && base.UpdateSqlData(this.dataSetDamage.tJ_DamageCharacter) && base.DeleteSqlData(this.dataSetDamage.tJ_DamageCharacter);
        }

        private void btnChooseParentDamage_Click(object sender, EventArgs e)
        {
            FormSelectDamage form = new FormSelectDamage();
            form.SqlSettings = this.SqlSettings;
            if (form.ShowDialog() == DialogResult.OK)
            {
                int idParentDocument = form.GetIdDocument().Value;
                //TypeDocDamage = form.TypeDamage;
                List<int> listCharacterParent = new List<int>();
                FormChooseDamageCharacter form2 = new FormChooseDamageCharacter(new int?(idParentDocument), listCharacterParent, this.IdDocument);
                form2.SqlSettings = this.SqlSettings;
                if (form2.ShowDialog() == DialogResult.OK)
                {
                    while (this.dgvEquipment.Rows.Count > 0)
                    {
                        this.dgvEquipment.Rows.RemoveAt(0);
                    }
                    this.FillWithTableDamageCharacter(form2.getListDamage());
                    this.dataSetDamage.tJ_Damage.Rows[0]["idParent"] = (this.IdParentDocument = new int?(idParentDocument));
                    // this.FillDateEndCrashLocal(_idParentDocument);
                }
                this.FillDateEndCrashLocal(idParentDocument);
            }
        }

        private void btnOpenParentDamage_Click(object sender, EventArgs e)
        {
            if (this.IdParentDocument == null)
            {
                return;
            }
            DataTable dataTable = base.SelectSqlData("tJ_Damage", true, "where id = " + this.IdParentDocument.ToString());
            if (dataTable.Rows.Count == 0)
            {
                return;
            }
            this.OpenDokument(Convert.ToInt32(dataTable.Rows[0]["typeDoc"]), Convert.ToInt32(this.IdParentDocument));
        }

        private void OpenDokument(int TypeDoc, int idDoc = -1)
        {
            switch (TypeDoc)
            {
                case (int)eTypeDocuments.DamageLV:
                    {
                        DailyReportN.JournalDamage.FormDamageLVAddEdit form = new DailyReportN.JournalDamage.FormDamageLVAddEdit(idDoc, eTypeDocuments.DamageLV);
                        form.SqlSettings = this.SqlSettings;
                        form.MdiParent = base.MdiParent;
                        form.SetFormViewMode(true);
                        form.Show();
                        return;
                    }
                case (int)eTypeDocuments.DamageHV:
                    {
                        DailyReportN.JournalDamage.FormDamageHVAddEdit form2 = new DailyReportN.JournalDamage.FormDamageHVAddEdit(idDoc);
                        form2.SqlSettings = this.SqlSettings;
                        form2.MdiParent = base.MdiParent;
                        form2.SetFormViewMode(true);
                        form2.Show();
                        return;
                    }
                case (int)eTypeDocuments.DefectLV:

                    break;
                default:
                    if (TypeDoc != (int)eTypeDocuments.DefectHV)
                    {
                        if (TypeDoc != (int)eTypeDocuments.ActDetection)
                        {
                            return;
                        }
                        FormActDetectionAddEdit form3 = new FormActDetectionAddEdit(new int?(idDoc));
                        form3.SqlSettings = this.SqlSettings;
                        form3.MdiParent = base.MdiParent;
                        form3.SetFormViewMode(true);
                        form3.Show();
                        return;
                    }
                    break;
            }
            DailyReportN.JournalDamage.FormDefectAddEdit form4 = new DailyReportN.JournalDamage.FormDefectAddEdit(idDoc, TypeDoc);
            form4.SqlSettings = this.SqlSettings;
            form4.MdiParent = base.MdiParent;
            form4.SetFormViewMode(true);
            form4.Show();
        }

        private void chkCrash_CheckedChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            if (this.chkCrash.Checked)
            {
                this.txtNumCrash.Enabled = true;
                if (string.IsNullOrEmpty(this.txtNumCrash.Text))
                {
                    DataTable dataTable = new SqlDataCommand(this.SqlSettings).SelectSqlData(string.Format("select a.numCrash from tJ_DamageActDetection a\r\n                                            left join tj_damage d on d.id = a.idDamage\r\n                                            where isnumeric(a.numCrash) = 1 and year(d.DateDoc) = {0}\r\n                                            order by cast(a.numCrash as int) desc", this.dtpDateOwner.Value.Year));
                    if (dataTable.Rows.Count > 0)
                    {
                        this.txtNumCrash.Text = (Convert.ToInt32(dataTable.Rows[0]["numCrash"]) + 1).ToString();
                        return;
                    }
                    this.txtNumCrash.Text = "1";
                    return;
                }
            }
            else
            {
                this.txtNumCrash.Enabled = false;
                this.txtNumCrash.Text = "";
            }
        }

        private void txtNumCrash_TextChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            if (!string.IsNullOrEmpty(this.txtNumCrash.Text))
            {
                this.labelNumCrash.ForeColor = Color.Black;
            }
        }

        private void dtpEndCrashLocal_ValueChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            if (this.dtpEndCrashLocal.Value != null)
            {
                if (this.dtpEndCrashLocal.Value != DBNull.Value)
                {
                    this.dtpEndCrashMoscow.Value = Convert.ToDateTime(this.dtpEndCrashLocal.Value).AddHours(3.0).AddHours(-TimeZoneInfo.Local.BaseUtcOffset.TotalHours);
                    return;
                }
            }
            this.dtpEndCrashMoscow.Value = DBNull.Value;
        }

        private void dgvNoCrashMeasure_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is DataGridViewComboBoxEditingControl)
            {
                ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
                ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
                ((ComboBox)e.Control).AutoCompleteMode = AutoCompleteMode.Suggest;
                ((ComboBox)e.Control).DropDown -= new EventHandler(this.cmb_DropDown);
                ((ComboBox)e.Control).DropDown += new EventHandler(this.cmb_DropDown);
            }
            if (((DataGridView)sender).CurrentCell != null && ((DataGridView)sender).Columns[((DataGridView)sender).CurrentCell.ColumnIndex] == this.dateCompleteDataGridViewTextBoxColumn && e.Control is DateTimePicker)
            {
                ((DateTimePicker)e.Control).Format = DateTimePickerFormat.Custom;
                ((DateTimePicker)e.Control).CustomFormat = "MMMM.yyyy";
                if (((DataGridView)sender).CurrentCell.Value == DBNull.Value)
                {
                    ((DataGridView)sender).CurrentCell.Value = ((DateTimePicker)e.Control).Value;
                }
            }
        }

        private void cmb_DropDown(object sender, EventArgs e)
        {
            ((ComboBox)sender).DropDownWidth = 500;
        }

        private void dgvNoCrashMeasure_MouseClick(object sender, MouseEventArgs e)
        {
            if (((DataGridView)sender).HitTest(e.X, e.Y).Type == DataGridViewHitTestType.RowHeader)
            {
                ((DataGridView)sender).EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
                ((DataGridView)sender).EndEdit();
                return;
            }
            ((DataGridView)sender).EditMode = DataGridViewEditMode.EditOnEnter;
        }

        /// <summary>
        /// загрузка таблицы повреждений
        /// </summary>
        private void LoadTableDamageCharacter()
        {
            if (this.IdDocument != null)
            {
                base.SelectSqlData(this.dataSetDamage.tJ_DamageCharacter, true, "where idDamage = " + this.IdDocument.ToString(), null, false, 0);
            }
        }
        /// <summary>
        /// начальное заполнение выпадающих списков
        /// </summary>
        private void InitComboBoxs()
        {
            this.FillComboBoxDgvTypeEquipment();
            this.FillComboBoxParameters();
            this.FillComboBoxVoltageSeti();
            this.FillComboBoxNodeDetail();
            this.FillComboBoxNeutraState();
            this.FillComboBoxMaterial();
            this.FillComboBoxClauseWork();
            this.FillComboBoxCharacterDamage();
            this.FillComboBoxReasonDamage();
        }

        private void FillComboBoxDgvTypeEquipment()
        {
            DataTable dataTable = this.CreateTableClassifier();
            base.SelectSqlData(dataTable, true, "where ParentId in (select id from  tr_classifier where ParentKey = ';ReportDaily;NatureDamage;HV;' or ParentKey = ';ReportDaily;NatureDamage;LV;')  and isGroup = 1 and deleted = 0 order by ParentKey", null, false, 0);
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;
            bindingSource.Position = -1;
            this.typeEquipmentDgvColumn.DisplayMember = "name";
            this.typeEquipmentDgvColumn.ValueMember = "id";
            this.typeEquipmentDgvColumn.DataSource = bindingSource;
        }

        private void toolBtnAddEquipment_Click(object sender, EventArgs e)
        {
            List<int> list = new List<int>();
            foreach (DataRow dataRow in this.dataSetDamage.tJ_DamageCharacter)
            {
                if (dataRow.RowState != DataRowState.Deleted && dataRow["idCharacterParent"] != DBNull.Value)
                {
                    list.Add(Convert.ToInt32(dataRow["idCharacterParent"]));
                }
            }
            FormChooseDamageCharacter form = new FormChooseDamageCharacter(this.IdParentDocument, list, this.IdDocument);
            form.SqlSettings = this.SqlSettings;
            if (form.ShowDialog() == DialogResult.OK)
            {
                this.FillWithTableDamageCharacter(form.getListDamage());
            }
        }
        /// <summary>
        /// дозаполнение таблицы поврежденого оборудования
        /// </summary>
        private void FillWithTableDamageCharacter(IEnumerable<int> listDamage)
        {
            if (listDamage != null && listDamage.Count<int>() > 0)
            {
                this.txtYearManufature.TextChanged -= new EventHandler(this.txtYearManufature_TextChanged);
                string text = "";
                foreach (int num in listDamage)
                {
                    if (string.IsNullOrEmpty(text))
                    {
                        text = num.ToString();
                    }
                    else
                    {
                        text = text + "," + num.ToString();
                    }
                }
                DailyReportN.DataSet.dsDamage.tJ_DamageCharacterDataTable table = new DailyReportN.DataSet.dsDamage.tJ_DamageCharacterDataTable();
                base.SelectSqlData(table, true, "where id in (" + text + ")", null, false, 0);
                foreach (DataRow dataRow in table.Rows)
                {
                    DataRow dataRow2 = this.dataSetDamage.tJ_DamageCharacter.NewRow();
                    dataRow2["idDamage"] = ((this.IdDocument == null) ? -1 : this.IdDocument.Value);
                    dataRow2["col1"] = dataRow["col1"];
                    dataRow2["idSchmObj"] = dataRow["idSchmObj"];
                    dataRow2["idLineSection"] = dataRow["idLineSection"];
                    dataRow2["idParameters"] = 2026;
                    dataRow2["idCharacterParent"] = dataRow["id"];
                    dataRow2["lengthOverLoad"] = 0;
                    dataRow2["idNeutralState"] = 2037;
                    dataRow2["nodeDetail"] = 2032;
                    if (dataRow2["idSchmObj"] != DBNull.Value)
                    {
                        // длина трассы
                        object LengthLine = this.GetLengthLine(Convert.ToInt32(dataRow2["idSChmObj"]));
                        if (!string.IsNullOrEmpty(LengthLine.ToString()))
                        {
                            dataRow2["LengthLine"] = LengthLine;
                        }
                        //
                        dataRow2["idMark"] = this.GetIdMark(Convert.ToInt32(dataRow2["idSChmObj"]));
                        // напряжение сети
                        object idVoltage = this.GetIdVoltage(Convert.ToInt32(dataRow2["idSChmObj"]));
                        if (idVoltage != DBNull.Value && idVoltage.ToString() != string.Empty && this.cmbVoltage.DataSource != null && this.cmbVoltage.DataSource is BindingSource && ((BindingSource)this.cmbVoltage.DataSource).DataSource is DataTable)
                        {
                            DataRow[] array = ((DataTable)((BindingSource)this.cmbVoltage.DataSource).DataSource).Select("Value = '" + idVoltage.ToString() + "' and ParentKey like ';VoltageLevels;%'");
                            if (array.Length != 0)
                            {
                                dataRow2["idVoltage"] = array[0]["id"];
                            }
                        }
                        // рабочее напряжение сети
                        object idVoltageSeti = this.GetIdVoltageSeti(Convert.ToInt32(dataRow2["idSChmObj"]));
                        if (idVoltageSeti != DBNull.Value && this.cmbVoltageSeti.DataSource != null && this.cmbVoltageSeti.DataSource is BindingSource && ((BindingSource)this.cmbVoltageSeti.DataSource).DataSource is DataTable)
                        {
                            DataRow[] array2 = ((DataTable)((BindingSource)this.cmbVoltageSeti.DataSource).DataSource).Select("Value = " + idVoltageSeti.ToString().Replace(',', '.') + " and ParentKey like ';VoltageLevels;%'");
                            if (array2.Length != 0)
                            {
                                dataRow2["idVoltageSeti"] = array2[0]["id"];
                            }
                        }
                        //
                        dataRow2["YearManufacture"] = this.GetYearManufacture(Convert.ToInt32(dataRow2["idSChmObj"]));
                        //
                        object YearBegEquipment = this.GetYearBegEquipment(Convert.ToInt32(dataRow2["idSChmObj"]));
                        DateTime dateTime;
                        if (DateTime.TryParse(YearBegEquipment.ToString(), out dateTime))
                        {
                            dataRow2["YearBegEquipment"] = dateTime.ToString("yyyy");
                        }
                        else
                        {
                            dataRow2["YearBegEquipment"] = ((YearBegEquipment.ToString() == string.Empty) ? DBNull.Value : YearBegEquipment);
                        }

                        dataRow2["LastDateTest"] = this.GetLastDateTest(Convert.ToInt32(dataRow2["idSChmObj"]));

                        dataRow2["timeRecovery"] = this.GetTimeRecovery(Convert.ToInt32(dataRow2["idSChmObj"]));
                    }
                    this.dataSetDamage.tJ_DamageCharacter.Rows.Add(dataRow2);
                }
            }
        }

        private object GetLengthLine(int idSChmObj)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idSChmObj.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value)
            {
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
                {
                    DataTable dataTable2 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Длина трассы'", idSChmObj));
                    if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable2.Rows[0]["CharValue"];
                    }
                }
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 547 || Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 983)
                {
                    DataTable dataTable3 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Протяженность линии'", idSChmObj));
                    if (dataTable3.Rows.Count > 0 && dataTable3.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable3.Rows[0]["CharValue"];
                    }
                }
            }
            return DBNull.Value;
        }

        private object GetIdVoltage(int idSChmObj)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idSChmObj.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value)
            {
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
                {
                    DataTable dataTable2 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Напряжение'", idSChmObj));
                    if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable2.Rows[0]["CharValue"];
                    }
                }
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 547 || Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 983)
                {
                    DataTable dataTable3 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Напряжение'", idSChmObj));
                    if (dataTable3.Rows.Count > 0 && dataTable3.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable3.Rows[0]["CharValue"];
                    }
                }
            }
            return DBNull.Value;
        }

        private object GetIdVoltageSeti(int idSChmObj)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idSChmObj.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value && Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
            {
                DataTable dataTable2 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Рабочее напряжение'", idSChmObj));
                if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["CharValue"] != DBNull.Value)
                {
                    return dataTable2.Rows[0]["CharValue"];
                }
            }
            return DBNull.Value;
        }

        private object GetYearBegEquipment(int idSChmObj)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idSChmObj.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value)
            {
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
                {
                    DataTable dataTable2 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Год ввода в эксплуатацию'", idSChmObj));
                    if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable2.Rows[0]["CharValue"];
                    }
                }
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 547 || Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 983)
                {
                    string where = string.Format("where idObj = {0} and ([CharName] like 'Год ввода в эксплуатацию'\r\nor [CharName] like 'Дата ввода в эксплуатацию') and [CharValue] is not null and [CharValue] <> ''", idSChmObj);
                    DataTable dataTable3 = base.SelectSqlData("vP_PassportDataReports", true, where);
                    if (dataTable3.Rows.Count > 0 && dataTable3.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable3.Rows[0]["CharValue"];
                    }
                }
            }
            return DBNull.Value;
        }

        private object GetYearManufacture(int idSChmObj)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idSChmObj.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value)
            {
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
                {
                    DataTable dataTable2 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Год прокладки'", idSChmObj));
                    if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable2.Rows[0]["CharValue"];
                    }
                }
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 547 || Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 983)
                {
                    DataTable dataTable3 = base.SelectSqlData("vP_PassportDataReports", true, string.Format("where idObj = {0} and [CharName] like 'Год постройки'", idSChmObj));
                    if (dataTable3.Rows.Count > 0 && dataTable3.Rows[0]["CharValue"] != DBNull.Value)
                    {
                        return dataTable3.Rows[0]["CharValue"];
                    }
                }
            }
            return DBNull.Value;
        }

        private object GetIdMark(int idObjList)
        {
            DataTable dataTable = new DataTable("tSchm_ObjList");
            dataTable.Columns.Add("typeCodeId", typeof(int));
            base.SelectSqlData(dataTable, true, " where id = " + idObjList.ToString(), null, false, 0);
            if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["TypeCodeId"] != DBNull.Value)
            {
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 546)
                {
                    DataTable dataTable2 = base.SelectSqlData("tP_Passport", true, string.Format("where idObjList = {0} and [isActive] = '1' and deleted = '0'", idObjList));
                    if (dataTable2.Rows.Count > 0 && dataTable2.Rows[0]["idEquipment"] != DBNull.Value)
                    {
                        return dataTable2.Rows[0]["idEquipment"];
                    }
                }
                if (Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 547 || Convert.ToInt32(dataTable.Rows[0]["TypeCodeId"]) == 983)
                {
                    DataTable dataTable3 = base.SelectSqlData("tP_Passport", true, string.Format("where idObjList = {0} and [isActive] = '1' and deleted = '0'", idObjList));
                    if (dataTable3.Rows.Count > 0 && dataTable3.Rows[0]["idEquipment"] != DBNull.Value)
                    {
                        return dataTable3.Rows[0]["idEquipment"];
                    }
                }
            }
            return DBNull.Value;
        }

        private object GetLastDateTest(int idObjList)
        {
            DataTable dataTable = new DataTable("tP_CabTesting");
            dataTable.Columns.Add("date", typeof(DateTime));
            string str = "";
            if (this.dataSetDamage.tJ_Damage.Rows.Count > 0 && this.dataSetDamage.tJ_Damage.Rows[0]["datedoc"] != DBNull.Value)
            {
                str = " and [date] < '" + Convert.ToDateTime(this.dataSetDamage.tJ_Damage.Rows[0]["datedoc"]).ToString("yyyyMMdd") + "'";
            }
            base.SelectSqlData(dataTable, true, " where idObjList = " + idObjList.ToString() + str + " and deleted = 0 order by [date] desc", null, false, 0);
            if (dataTable.Rows.Count > 0)
            {
                return dataTable.Rows[0]["Date"];
            }
            return DBNull.Value;
        }

        private object GetTimeRecovery(int idObjList)
        {
            DataTable dataTable = new DataTable("tP_CabOperation");
            dataTable.Columns.Add("datecommissioning", typeof(DateTime));
            string str = "";
            if (this.dataSetDamage.tJ_Damage.Rows.Count > 0 && this.dataSetDamage.tJ_Damage.Rows[0]["datedoc"] != DBNull.Value)
            {
                str = " and [datecommissioning] > '" + Convert.ToDateTime(this.dataSetDamage.tJ_Damage.Rows[0]["datedoc"]).ToString("yyyyMMdd") + "'";
            }
            base.SelectSqlData(dataTable, true, " where idObjList = " + idObjList.ToString() + str + " and deleted = 0 order by [datecommissioning]", null, false, 0);
            if (dataTable.Rows.Count > 0)
            {
                return dataTable.Rows[0]["datecommissioning"];
            }
            return DBNull.Value;
        }

        private void toolBtnDelEquipment_Click(object sender, EventArgs e)
        {
            if (this.dgvEquipment.CurrentRow != null)
            {
                if (this.dgvEquipment.Rows.Count == 1)
                {
                    DataTable dataTable = new DataTable("tJ_Damage");
                    dataTable.Columns.Add("id", typeof(int));
                    string arg = "";
                    if (this.IdDocument != null)
                    {
                        arg = "id <> " + this.IdDocument.Value.ToString() + " and ";
                    }
                    base.SelectSqlData(dataTable, true, string.Format("where {0} idParent = {1} and typeDoc = {2} \r\n                        and not  exists(select id from tJ_DamageCharacter where idDAmage = tj_damage.id)", arg, this.IdParentDocument, (int)eTypeDocuments.ActDetection), null, false, 0);
                    if (dataTable.Rows.Count > 0)
                    {
                        MessageBox.Show("Нельзя удалить последнюю строку.\r\nУже существуют документ без оборудования.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                if (MessageBox.Show("Вы  действительно хотите удалить выбранную строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    this.dgvEquipment.Rows.Remove(this.dgvEquipment.CurrentRow);
                }
            }
        }

        private void dgvEquipment_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int i = e.RowIndex; i < e.RowIndex + e.RowCount; i++)
            {
                object value = this.dgvEquipment[this.idSchmObjDgvColumn.Name, i].Value;
                if (value != DBNull.Value && value != null)
                {
                    object obj = base.CallSQLScalarFunction("dbo.fn_Schm_GetFullNameObjById", new string[]
                    {
                    value.ToString()
                    });
                    if (obj != null && obj != DBNull.Value)
                    {
                        this.dgvEquipment[this.schmObjDgvColumn.Index, i].Value = obj.ToString();
                    }
                }
            }
        }

        private void bsDamageCharacter_CurrentChanged(object sender, EventArgs e)
        {
            if (this.bsDamageCharacter.Current != null)
            {
                DataRow row = ((DataRowView)this.bsDamageCharacter.Current).Row;
                object idMark = row["idMark"];
                this.FillComboBoxMarkEquipment();
                row["idMark"] = idMark;
                this.cmbMarkEquipment.SelectedValue = idMark;
                if (!this.GetFormViewMode() && !this.chkApply.Checked)
                {
                    this.ControlBlockingTabPageSchm(false);
                    return;
                }
            }
            else
            {
                this.ControlBlockingTabPageSchm(true);
            }
        }

        private void FillComboBoxMarkEquipment()
        {
            if (this.bsDamageCharacter.Current == null || ((DataRowView)this.bsDamageCharacter.Current).Row["col1"] == DBNull.Value)
            {
                this.cmbMarkEquipment.DataSource = null;
                return;
            }
            DataTable dataTable = this.CreateTableClassifier();
            base.SelectSqlData(dataTable, true, " where id = " + ((DataRowView)this.bsDamageCharacter.Current).Row["col1"].ToString(), null, false, 0);
            if (dataTable.Rows.Count == 0)
            {
                this.cmbMarkEquipment.DataSource = null;
                return;
            }
            string ParentKey = dataTable.Rows[0]["ParentKey"].ToString();
            if (!(ParentKey == ";ReportDaily;NatureDamage;HV;AirLine;") && !(ParentKey == ";ReportDaily;NatureDamage;HV;CableLine;"))
            {
                if (!(ParentKey == ";ReportDaily;NatureDamage;HV;Subs;"))
                {
                    if (ParentKey == ";ReportDaily;NatureDamage;HV;Transformer;")
                    {
                        DataTable dataSource = new SqlDataCommand(this.SqlSettings).SelectSqlData("select id, name + \r\n                                                                isnull('/' + convert(varchar(20), convert(float, highVoltage)), '') as name\r\n                                                                from tR_Transformer \r\n                                                                where deleted = 0\r\n                                                                order by name, highvoltage");
                        this.cmbMarkEquipment.DisplayMember = "name";
                        this.cmbMarkEquipment.ValueMember = "id";
                        this.cmbMarkEquipment.DataSource = dataSource;
                    }
                }
                else
                {
                    DataTable dataSource2 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select id, Name\r\n                                                                from tP_ValueLists\r\n                                                                where ParentKey = ';SubstationType;' and isGRoup = 0 and deleted = 0\r\n                                                                order by name");
                    this.cmbMarkEquipment.DisplayMember = "name";
                    this.cmbMarkEquipment.ValueMember = "id";
                    this.cmbMarkEquipment.DataSource = dataSource2;
                }
            }
            else
            {
                DataTable dataSource3 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select cName.id,\r\n                                                                     cName.CableMakeup + '-' + cast(cName.wires as varchar(8)) + 'x' + \r\n                                                                     convert(varchar(20), convert(float, CName.CrossSection))  \r\n                                                                \t + isnull('+' + cast(cName.wiresAddl as varchar(8))+'x'+convert(varchar(20), convert(float, CName.CrossSectionAddl))+'(N)'  , '') \r\n                                                                \t + isnull('-' + convert(varchar(20),convert(float, cV.Value)), '')\r\n                                                                \t as name\r\n                                                                from tr_Cable cName\r\n                                                                \tleft join tr_classifier cV on cV.id = cName.idVoltage\r\n                                                                where cName.CableMakeup is not null and cName.wires is not null and cName.CrossSection is not null\r\n                                                                     and cname.CableMakeup not like '[0-9]%'\r\n                                                                order by cName.CableMakeup, cName.wires, cName.CrossSection");
                this.cmbMarkEquipment.DisplayMember = "name";
                this.cmbMarkEquipment.ValueMember = "id";
                this.cmbMarkEquipment.DataSource = dataSource3;
            }
            this.cmbMarkEquipment.SelectedIndex = -1;
        }

        private void FillComboBoxParameters()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;Params;'";
            bindingSource.Sort = "name";
            this.cmbParameters.DisplayMember = "name";
            this.cmbParameters.ValueMember = "id";
            this.cmbParameters.DataSource = bindingSource;
        }

        private void FillComboBoxVoltageSeti()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey like ';VoltageLevels;MV;%'";
            bindingSource.Sort = "value";
            this.cmbVoltage.DisplayMember = "name";
            this.cmbVoltage.ValueMember = "id";
            this.cmbVoltage.DataSource = bindingSource;
            BindingSource bindingSource2 = new BindingSource();
            bindingSource2.DataSource = this.tblClassifier.Copy();
            bindingSource2.Filter = "ParentKey like ';VoltageLevels;MV;%'";
            bindingSource2.Sort = "value";
            this.cmbVoltageSeti.DisplayMember = "name";
            this.cmbVoltageSeti.ValueMember = "id";
            this.cmbVoltageSeti.DataSource = bindingSource2;
        }

        private void FillComboBoxNodeDetail()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;NodeDetail;'";
            bindingSource.Sort = "name";
            this.cmbNodeDetail.DisplayMember = "name";
            this.cmbNodeDetail.ValueMember = "id";
            this.cmbNodeDetail.DataSource = bindingSource;
        }

        private void FillComboBoxNeutraState()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;NeutralState;'";
            bindingSource.Sort = "name";
            this.cmbNeutralState.DisplayMember = "name";
            this.cmbNeutralState.ValueMember = "id";
            this.cmbNeutralState.DataSource = bindingSource;
            this.cmbNeutralState.DataBindings[0].DataSourceNullValue = ((DataRowView)this.cmbNeutralState.Items[0]).Row["id"];
        }

        private void FillComboBoxMaterial()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;Material;'";
            bindingSource.Sort = "name";
            this.cmbMaterial.DisplayMember = "name";
            this.cmbMaterial.ValueMember = "id";
            this.cmbMaterial.DataSource = bindingSource;
            this.cmbMaterial.DataBindings[0].DataSourceNullValue = ((DataRowView)this.cmbMaterial.Items[0]).Row["id"];
        }

        private void FillComboBoxClauseWork()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;ClauseWork;'";
            bindingSource.Sort = "name";
            this.cmbClauseWork.DisplayMember = "name";
            this.cmbClauseWork.ValueMember = "id";
            this.cmbClauseWork.DataSource = bindingSource;
            this.cmbClauseWork.DataBindings[0].DataSourceNullValue = ((DataRowView)this.cmbClauseWork.Items[0]).Row["id"];
        }

        private void FillComboBoxCharacterDamage()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;ChrDamage;'";
            bindingSource.Sort = "name";
            this.cmbCharacterDamage.DisplayMember = "name";
            this.cmbCharacterDamage.ValueMember = "id";
            this.cmbCharacterDamage.DataSource = bindingSource;
        }

        private void FillComboBoxReasonDamage()
        {
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = this.tblClassifier.Copy();
            bindingSource.Filter = "ParentKey = ';ReportDaily;ActDetection;Equipment;ReasonDamage;'";
            bindingSource.Sort = "name";
            this.cmbReasonDamage.DisplayMember = "name";
            this.cmbReasonDamage.ValueMember = "id";
            this.cmbReasonDamage.DataSource = bindingSource;
        }

        /// <summary>
        /// Заполним списки членов комиссии 
        /// </summary>
        private void FillComboBoxsMemberComission()
        {
            this.cmbChairman.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission1.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission2.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission3.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission4.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission5.SelectedValueChanged -= new EventHandler(this.cmb_SelectedValueChanged);
            if (this.GetIdDocument() != null)
            {
                if (this.dataSetDamage.tJ_DamageActDetection.Rows.Count > 0 && this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Comission"] != DBNull.Value)
                {
                    string Comission = this.dataSetDamage.tJ_DamageActDetection.Rows[0]["Comission"].ToString();
                    if (!string.IsNullOrEmpty(Comission))
                    {
                        this.dataTableComission.ReadXml(new StringReader(Comission));
                    }
                }
            }
            else
            {
                DailyReportN.DataSet.dsDamage ds = new DailyReportN.DataSet.dsDamage();
                base.SelectSqlData(ds.tJ_DamageActDetection, true, " where Comission is not null order by idDamage desc", null, false, 1);
                if (ds.tJ_DamageActDetection.Rows.Count > 0 && ds.tJ_DamageActDetection.Rows[0]["Comission"] != DBNull.Value)
                {
                    string Comission = ds.tJ_DamageActDetection.Rows[0]["Comission"].ToString();
                    if (!string.IsNullOrEmpty(Comission))
                    {
                        this.dataTableComission.ReadXml(new StringReader(Comission));
                    }
                }
            }
            if (this.dataTableComission.Rows.Count == 0)
            {
                this.dataTableComission.Rows.Add(new object[0]);
            }
            this.cmbChairman.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission1.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission2.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission3.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission4.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
            this.cmbMemberComission5.SelectedValueChanged += new EventHandler(this.cmb_SelectedValueChanged);
        }

        private void cmb_SelectedValueChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            ComboBox comboBox = (ComboBox)sender;
            if (comboBox.SelectedIndex < 0)
            {
                if (comboBox == this.cmbChairman)
                {
                    this.txtPostChairman.Text = "";
                }
                if (comboBox == this.cmbMemberComission1)
                {
                    this.txtPostMemeber1.Text = "";
                }
                if (comboBox == this.cmbMemberComission2)
                {
                    this.txtPostMemeber2.Text = "";
                }
                if (comboBox == this.cmbMemberComission3)
                {
                    this.txtPostMemeber3.Text = "";
                }
                if (comboBox == this.cmbMemberComission4)
                {
                    this.txtPostMemeber4.Text = "";
                }
                if (comboBox == this.cmbMemberComission5)
                {
                    this.txtPostMemeber5.Text = "";
                    return;
                }
            }
            else
            {
                DataTable dataTable = new SqlDataCommand(this.SqlSettings).SelectSqlData("select t.description from tR_JobTitle t \r\n\t                inner join tR_Worker w on t.id = w.jobtitle\r\n                    where w.id = " + comboBox.SelectedValue.ToString());
                if (dataTable.Rows.Count > 0 && dataTable.Rows[0]["Description"] != DBNull.Value)
                {
                    if (comboBox == this.cmbChairman)
                    {
                        this.txtPostChairman.Text = dataTable.Rows[0]["Description"].ToString();
                    }
                    if (comboBox == this.cmbMemberComission1)
                    {
                        this.txtPostMemeber1.Text = dataTable.Rows[0]["Description"].ToString();
                    }
                    if (comboBox == this.cmbMemberComission2)
                    {
                        this.txtPostMemeber2.Text = dataTable.Rows[0]["Description"].ToString();
                    }
                    if (comboBox == this.cmbMemberComission3)
                    {
                        this.txtPostMemeber3.Text = dataTable.Rows[0]["Description"].ToString();
                    }
                    if (comboBox == this.cmbMemberComission4)
                    {
                        this.txtPostMemeber4.Text = dataTable.Rows[0]["Description"].ToString();
                    }
                    if (comboBox == this.cmbMemberComission5)
                    {
                        this.txtPostMemeber5.Text = dataTable.Rows[0]["Description"].ToString();
                        return;
                    }
                }
                else
                {
                    if (comboBox == this.cmbMemberComission1)
                    {
                        this.txtPostMemeber1.Text = "";
                    }
                    if (comboBox == this.cmbMemberComission2)
                    {
                        this.txtPostMemeber2.Text = "";
                    }
                    if (comboBox == this.cmbMemberComission3)
                    {
                        this.txtPostMemeber3.Text = "";
                    }
                    if (comboBox == this.cmbMemberComission4)
                    {
                        this.txtPostMemeber4.Text = "";
                    }
                    if (comboBox == this.cmbMemberComission5)
                    {
                        this.txtPostMemeber5.Text = "";
                    }
                }
            }
        }
        /// <summary>
        /// уберем выделени текста в комбобоксах
        /// </summary>
        private void ControlSelectionLengthComboBox(Control.ControlCollection controlCollection)
        {
            foreach (Control cb in controlCollection)
            {
                if (cb is ComboBox)
                {
                    cb.Resize += delegate (object sender, EventArgs e)
                    {
                        if (cb is ComboBox && !cb.Focused)
                        {
                            ((ComboBox)cb).SelectionLength = 0;
                        }
                    };
                }
                this.ControlSelectionLengthComboBox(cb.Controls);


            }
            //using (IEnumerator enumerator = controlCollection_0.GetEnumerator())
            //{
            //	while (enumerator.MoveNext())
            //	{
            //		Control cb = (Control)enumerator.Current;
            //		if (cb is ComboBox)
            //		{
            //			cb.Resize += delegate(object sender, EventArgs e)
            //			{
            //				if (cb is ComboBox && !cb.Focused)
            //				{
            //					((ComboBox)cb).SelectionLength = 0;
            //				}
            //			};
            //		}
            //		this.method_58(cb.Controls);
            //	}
            //}
        }

        private void ControlBlockingOtherDocuments()
        {
            if (!this.GetFormViewMode() && !this.chkApply.Checked)
            {
                this.cmbCompiler.ReadOnly = false;
                this.cmbDivision.ReadOnly = false;
                this.chkCrash.Enabled = true;
                this.buttonChooseParentDamage.Enabled = true;

                this.btnRefreshDateDoc.Enabled = true;
                this.chkNoOff.Enabled = true;
                this.dtpDateDoc.Enabled = true;
                this.btnRefrshDateEndCrash.Enabled = true;

                this.cmbTypeEquipment.ReadOnly = false;
                this.cmbSignCrash.ReadOnly = false;
                this.cmbOrg.ReadOnly = false;

                this.cmbReasonCrash.ReadOnly = false;
                this.cmbReasonCrashEquipment.ReadOnly = false;
                this.dgvNoCrashMeasure.ReadOnly = false;

                this.txtStatusCurrentCrash.ReadOnly = false;
                this.cmbStatusCurrentCrash.ReadOnly = false;
                this.cmbStatusBeforeCrash.ReadOnly = false;
                this.dgvDefection.ReadOnly = false;

                this.cmbFault.ReadOnly = false;
                this.cmbClassifierDamage.ReadOnly = false;
                this.txtReasonBeginCrash.ReadOnly = false;
                this.cmbReasonBeginCrash.ReadOnly = false;
                this.toolStripEquipment.Enabled = true;
                this.dgvEquipment.ReadOnly = false;

                this.ControlBlockingTabPageSchm(false);

                this.txtOrder.ReadOnly = false;

                this.txtPostChairman.ReadOnly = false;
                this.cmbChairman.ReadOnly = false;

                this.cmbMemberComission5.ReadOnly = false;
                this.cmbMemberComission4.ReadOnly = false;
                this.cmbMemberComission3.ReadOnly = false;
                this.cmbMemberComission2.ReadOnly = false;
                this.cmbMemberComission1.ReadOnly = false;

                this.txtPostMemeber5.ReadOnly = false;
                this.txtPostMemeber4.ReadOnly = false;
                this.txtPostMemeber3.ReadOnly = false;
                this.txtPostMemeber2.ReadOnly = false;
                this.txtPostMemeber1.ReadOnly = false;

                this.txtTotalComission.ReadOnly = false;
            }
            else
            {
                this.cmbCompiler.ReadOnly = true;
                this.cmbDivision.ReadOnly = true;
                this.chkCrash.Enabled = false;
                this.buttonChooseParentDamage.Enabled = false;

                this.btnRefreshDateDoc.Enabled = false;
                this.chkNoOff.Enabled = false;
                this.dtpDateDoc.Enabled = false;
                this.btnRefrshDateEndCrash.Enabled = false;

                this.cmbTypeEquipment.ReadOnly = true;
                this.cmbSignCrash.ReadOnly = true;
                this.cmbOrg.ReadOnly = true;

                this.cmbReasonCrash.ReadOnly = true;
                this.cmbReasonCrashEquipment.ReadOnly = true;
                this.dgvNoCrashMeasure.ReadOnly = true;

                this.txtStatusCurrentCrash.ReadOnly = true;
                this.cmbStatusCurrentCrash.ReadOnly = true;
                this.cmbStatusBeforeCrash.ReadOnly = true;
                this.dgvDefection.ReadOnly = true;

                this.cmbFault.ReadOnly = true;
                this.cmbClassifierDamage.ReadOnly = true;
                this.txtReasonBeginCrash.ReadOnly = true;
                this.cmbReasonBeginCrash.ReadOnly = true;
                this.toolStripEquipment.Enabled = false;
                this.dgvEquipment.ReadOnly = true;
                this.ControlBlockingTabPageSchm(true);
                this.txtOrder.ReadOnly = true;

                this.txtPostChairman.ReadOnly = true;
                this.cmbChairman.ReadOnly = true;

                this.cmbMemberComission5.ReadOnly = true;
                this.cmbMemberComission4.ReadOnly = true;
                this.cmbMemberComission3.ReadOnly = true;
                this.cmbMemberComission2.ReadOnly = true;
                this.cmbMemberComission1.ReadOnly = true;

                this.txtPostMemeber5.ReadOnly = true;
                this.txtPostMemeber4.ReadOnly = true;
                this.txtPostMemeber3.ReadOnly = true;
                this.txtPostMemeber2.ReadOnly = true;
                this.txtPostMemeber1.ReadOnly = true;
                this.txtTotalComission.ReadOnly = true;
            }
            if (this.GetFormViewMode())
            {
                this.chkApply.Enabled = false;
                this.cmbWorkerApply.ReadOnly = true;
                this.dtpApply.Enabled = false;
                this.buttonSave.Enabled = false;
                return;
            }
            this.buttonSave.Enabled = true;
        }
        /// <summary>
        ///  контроль блокировки контролов на странице оборудования
        /// </summary>
        private void ControlBlockingTabPageSchm(bool flag)
        {
            this.chkAutoProtect.Enabled = !flag;

            this.cmbVoltage.ReadOnly = flag;
            this.cmbParameters.ReadOnly = flag;
            this.cmbMarkEquipment.ReadOnly = flag;
            this.cmbVoltageSeti.ReadOnly = flag;
            this.txtCountDefectEquipment.ReadOnly = flag;
            this.cmbNodeDetail.ReadOnly = flag;
            this.txtNodeDetail.ReadOnly = flag;
            this.schmObjDgvColumn.ReadOnly = flag;
            this.txtYearManufature.ReadOnly = flag;
            this.txtFactoryNumber.ReadOnly = flag;
            this.txtManufacturer.ReadOnly = flag;
            this.txtClauseFail.ReadOnly = flag;
            this.cmbNeutralState.ReadOnly = flag;
            this.txtLenghtLine.ReadOnly = flag;
            this.txtLengthOverload.ReadOnly = flag;
            this.cmbClauseWork.ReadOnly = flag;
            this.cmbMaterial.ReadOnly = flag;
            this.cmbReasonDamage.ReadOnly = flag;
            this.cmbCharacterDamage.ReadOnly = flag;
            this.txtLengthWorkEquipment.ReadOnly = flag;
            this.txtYearBegEquipment.ReadOnly = flag;
            this.txtAssociatedFact.ReadOnly = flag;

            this.dtpLastDateTest.Enabled = (this.dtpTimeRecovery.Enabled = !flag);
        }

        private void chkApply_CheckedChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            this.ControlBlockingOtherDocuments();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab == this.tabPagePrint)
            {
                ReportViewerRus reportViewerRus = new ReportViewerRus();
                reportViewerRus.LocalReport.ReportEmbeddedResource = "DailyReportN.ActDetection.ReportActDetection.rdlc";
                //reportViewerRus.LocalReport.ReportEmbeddedResource = "DailyReportN.ActDetection.ReportActDetectionN.rdlc";
                reportViewerRus.Dock = DockStyle.Fill;
                this.tabPagePrint.Controls.Clear();
                this.tabPagePrint.Controls.Add(reportViewerRus);
                ReportDataSource reportDataSource = new ReportDataSource();
                reportDataSource.Name = "dsDamage";
                reportDataSource.Value = this.bsDamage;
                reportViewerRus.LocalReport.DataSources.Add(reportDataSource);
                reportDataSource = new ReportDataSource();
                reportDataSource.Name = "dsActDetection";
                reportDataSource.Value = new BindingSource
                {
                    DataSource = this.dataSetDamage.tJ_DamageActDetection
                };
                reportViewerRus.LocalReport.DataSources.Add(reportDataSource);
                List<ReportParameter> list = new List<ReportParameter>();
                if (this.cmbOrg.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("Org", ((DataRowView)this.cmbOrg.SelectedItem).Row["name"].ToString()));
                }
                if (this.cmbSignCrash.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("signCrashCode", ((DataRowView)this.cmbSignCrash.SelectedItem).Row["name"].ToString()));
                    list.Add(new ReportParameter("signCrash", ((DataRowView)this.cmbSignCrash.SelectedItem).Row["comment"].ToString()));
                }
                if (this.cmbTypeEquipment.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("typeEquipmentCode", ((DataRowView)this.cmbTypeEquipment.SelectedItem).Row["name"].ToString()));
                    list.Add(new ReportParameter("typeEquipment", ((DataRowView)this.cmbTypeEquipment.SelectedItem).Row["comment"].ToString()));
                }
                if (this.cmbReasonCrashEquipment.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("reasonCrashEqCode", ((DataRowView)this.cmbReasonCrashEquipment.SelectedItem).Row["name"].ToString()));
                    list.Add(new ReportParameter("reasonCrashEq", ((DataRowView)this.cmbReasonCrashEquipment.SelectedItem).Row["comment"].ToString()));
                }
                if (this.cmbReasonCrash.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("reasonCrashCode", ((DataRowView)this.cmbReasonCrash.SelectedItem).Row["name"].ToString()));
                    list.Add(new ReportParameter("reasonCrash", ((DataRowView)this.cmbReasonCrash.SelectedItem).Row["comment"].ToString()));
                }
                list.Add(new ReportParameter("schmObj", this.txtSchmObj.Text));
                if (this.cmbStatusBeforeCrash.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("statusBeforeCrash", ((DataRowView)this.cmbStatusBeforeCrash.SelectedItem).Row["comment"].ToString()));
                }
                if (!string.IsNullOrEmpty(this.txtStatusCurrentCrash.Text))
                {
                    list.Add(new ReportParameter("statusCurrentCrash", this.txtStatusCurrentCrash.Text));
                }
                else if (this.cmbStatusCurrentCrash.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("statusCurrentCrash", ((DataRowView)this.cmbStatusCurrentCrash.SelectedItem).Row["comment"].ToString()));
                }
                reportDataSource = new ReportDataSource();
                reportDataSource.Name = "ds23";
                BindingSource bindingSource = new BindingSource();
                bindingSource.DataSource = this.dataSetDamage.table23;
                this.dataSetDamage.table23.Clear();
                foreach (DataGridViewRow dataGridViewRow in ((IEnumerable)this.dgvDefection.Rows))
                {
                    DataRow dataRow = this.dataSetDamage.table23.NewRow();
                    dataRow["Description"] = dataGridViewRow.Cells[this.idDefectionDataGridViewTextBoxColumn.Name].FormattedValue.ToString();
                    dataRow["NPA"] = dataGridViewRow.Cells[this.idNPADgvColumn.Name].FormattedValue.ToString();
                    if (dataGridViewRow.Cells[this.punctNPADataGridViewTextBoxColumn.Name].Value != null)
                    {
                        dataRow["punktNPA"] = dataGridViewRow.Cells[this.punctNPADataGridViewTextBoxColumn.Name].Value.ToString();
                    }
                    dataRow["Org"] = dataGridViewRow.Cells[this.idOrgDefectionDgvColumn.Name].FormattedValue.ToString();
                    this.dataSetDamage.table23.Rows.Add(dataRow);
                }
                if (this.dataSetDamage.table23.Rows.Count > 0)
                {
                    this.dataSetDamage.table23.Rows.RemoveAt(this.dataSetDamage.table23.Rows.Count - 1);
                }
                reportDataSource.Value = bindingSource;
                reportViewerRus.LocalReport.DataSources.Add(reportDataSource);
                if (!string.IsNullOrEmpty(this.txtReasonBeginCrash.Text))
                {
                    list.Add(new ReportParameter("reasonBeginCrash", this.txtReasonBeginCrash.Text));
                }
                else if (this.cmbReasonBeginCrash.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("reasonBeginCrashCode", ((DataRowView)this.cmbReasonBeginCrash.SelectedItem).Row["name"].ToString()));
                    list.Add(new ReportParameter("reasonBeginCrash", ((DataRowView)this.cmbReasonBeginCrash.SelectedItem).Row["comment"].ToString()));
                }
                if (this.cmbClassifierDamage.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("classifierDamage", ((DataRowView)this.cmbClassifierDamage.SelectedItem).Row["name"].ToString()));
                }
                if (this.cmbFault.SelectedIndex >= 0)
                {
                    list.Add(new ReportParameter("fault", ((DataRowView)this.cmbFault.SelectedItem).Row["name"].ToString()));
                }
                reportDataSource = new ReportDataSource();
                reportDataSource.Name = "ds31";
                BindingSource bindingSource2 = new BindingSource();
                bindingSource2.DataSource = this.dataSetDamage.table31;
                this.dataSetDamage.table31.Clear();
                foreach (DataGridViewRow dataGridViewRow2 in ((IEnumerable)this.dgvNoCrashMeasure.Rows))
                {
                    DataRow dataRow2 = this.dataSetDamage.table31.NewRow();
                    dataRow2["Measure"] = dataGridViewRow2.Cells[this.idNoCrashMeasureColumn.Name].FormattedValue.ToString();
                    if (dataGridViewRow2.Cells[this.dateCompleteDataGridViewTextBoxColumn.Name].Value != null && dataGridViewRow2.Cells[this.dateCompleteDataGridViewTextBoxColumn.Name].Value != DBNull.Value)
                    {
                        dataRow2["date"] = Convert.ToDateTime(dataGridViewRow2.Cells[this.dateCompleteDataGridViewTextBoxColumn.Name].Value).ToString("MMMM yyyy");
                    }
                    dataRow2["Org"] = dataGridViewRow2.Cells[this.idOrgColumn.Name].FormattedValue.ToString();
                    this.dataSetDamage.table31.Rows.Add(dataRow2);
                }
                if (this.dataSetDamage.table31.Rows.Count > 0)
                {
                    this.dataSetDamage.table31.Rows.RemoveAt(this.dataSetDamage.table31.Rows.Count - 1);
                }
                reportDataSource.Value = bindingSource2;
                reportViewerRus.LocalReport.DataSources.Add(reportDataSource);
                reportDataSource = new ReportDataSource();
                reportDataSource.Name = "ds4";
                BindingSource bindingSource3 = new BindingSource();
                bindingSource3.DataSource = this.dataSetDamage.table4;
                this.dataSetDamage.table4.Clear();
                int num = 1;
                for (int i = 0; i < this.dataSetDamage.tJ_DamageCharacter.Rows.Count; i++)
                {
                    DataRow dataRow3 = this.dataSetDamage.tJ_DamageCharacter.Rows[i];
                    if (dataRow3.RowState != DataRowState.Deleted)
                    {
                        DataRow dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Отказавшее оборудование: ";
                        dataRow4["Description"] = dataRow4["Description"].ToString() + this.dgvEquipment[this.typeEquipmentDgvColumn.Name, i].FormattedValue.ToString();
                        if (this.dgvEquipment[this.schmObjDgvColumn.Name, i].Value != null)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + "   " + this.dgvEquipment[this.schmObjDgvColumn.Name, i].Value.ToString();
                        }
                        if (this.dgvEquipment[this.schmObjNameDgvColumn.Name, i].Value != null)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + "   " + this.dgvEquipment[this.schmObjNameDgvColumn.Name, i].Value.ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Марка: ";
                        if (dataRow3["idMark"] != DBNull.Value && dataRow3["col1"] != DBNull.Value)
                        {
                            DataTable dataTable = this.CreateTableClassifier();
                            base.SelectSqlData(dataTable, true, " where id = " + dataRow3["col1"].ToString(), null, false, 0);
                            if (dataTable.Rows.Count > 0)
                            {
                                string a = dataTable.Rows[0]["ParentKey"].ToString();
                                if (!(a == ";ReportDaily;NatureDamage;HV;AirLine;") && !(a == ";ReportDaily;NatureDamage;HV;CableLine;"))
                                {
                                    if (!(a == ";ReportDaily;NatureDamage;HV;Subs;"))
                                    {
                                        if (a == ";ReportDaily;NatureDamage;HV;Transformer;")
                                        {
                                            DataTable dataTable2 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select id, name + \r\n                                                                isnull('/' + convert(varchar(20), convert(float, highVoltage)), '') as name\r\n                                                                from tR_Transformer \r\n                                                                where id = " + dataRow3["idMark"].ToString() + " order by name, highvoltage");
                                            if (dataTable2.Rows.Count > 0)
                                            {
                                                dataRow4["Description"] = dataRow4["Description"].ToString() + dataTable2.Rows[0]["Name"].ToString();
                                            }
                                        }
                                    }
                                    else
                                    {
                                        DataTable dataTable3 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select id, Name\r\n                                                                from tP_ValueLists\r\n                                                                where ParentKey = ';SubstationType;' and isGRoup = 0 and deleted = 0\r\n                                                                    and id = " + dataRow3["idMark"].ToString() + " order by name");
                                        if (dataTable3.Rows.Count > 0)
                                        {
                                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataTable3.Rows[0]["Name"].ToString();
                                        }
                                    }
                                }
                                else
                                {
                                    DataTable dataTable4 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select id, CableMakeup + ' ' + cast(wires as varchar(8)) + 'x' + \r\n                                            convert(varchar(20), convert(float, CrossSection)) as name from tr_Cable \r\n                                            where id = " + dataRow3["idMark"].ToString() + " order by CableMakeup, wires, CrossSection");
                                    if (dataTable4.Rows.Count > 0)
                                    {
                                        dataRow4["Description"] = dataRow4["Description"].ToString() + dataTable4.Rows[0]["Name"].ToString();
                                    }
                                }
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Параметры: ";
                        if (dataRow3["idParameters"] != DBNull.Value)
                        {
                            DataRow[] array = this.tblClassifier.Select("id = " + dataRow3["idParameters"].ToString());
                            if (array.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Конструктивное напряжение: ";
                        if (dataRow3["idVoltage"] != DBNull.Value)
                        {
                            DataRow[] array2 = this.tblClassifier.Select("id = " + dataRow3["idVoltage"].ToString());
                            if (array2.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array2[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Узел, деталь: ";
                        if (dataRow3["NodeDetail"] != DBNull.Value)
                        {
                            DataRow[] array3 = this.tblClassifier.Select("id = " + dataRow3["NodeDetail"].ToString());
                            if (array3.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array3[0]["Name"].ToString();
                            }
                        }
                        if (dataRow3["NodeDetailTxt"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + " " + dataRow3["NodeDetailTxt"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Количество отказавшего оборудования, узлов: ";
                        if (dataRow3["CountDefectEquipment"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["CountDefectEquipment"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Напряжение сети: ";
                        if (dataRow3["idVoltageSeti"] != DBNull.Value)
                        {
                            DataRow[] array4 = this.tblClassifier.Select("id = " + dataRow3["idVoltageSEti"].ToString());
                            if (array4.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array4[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Изготовитель оборудования или повредившегося узла: ";
                        if (dataRow3["Manufacturer"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["Manufacturer"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Заводской номер: ";
                        if (dataRow3["FactoryNumber"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["FactoryNumber"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Год изготовления оборудования: ";
                        if (dataRow3["YearManufacture"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["YearManufacture"].ToString() + "г.";
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Состояние нейтрали: ";
                        if (dataRow3["idNeutralState"] != DBNull.Value)
                        {
                            DataRow[] array5 = this.tblClassifier.Select("id = " + dataRow3["idNeutralState"].ToString());
                            if (array5.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array5[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Условия отказа оборудования, % относительная нагрузка кабеля, число цепей ВЛ: ";
                        if (dataRow3["ClauseFail"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["ClauseFail"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Продолжительность работы оборудования с перегрузкой: ";
                        if (dataRow3["LengthOverload"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["LengthOverload"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Длина КЛ, ВЛ, м: ";
                        if (dataRow3["LengthLine"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["LengthLine"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Материал: ";
                        if (dataRow3["idMaterial"] != DBNull.Value)
                        {
                            DataRow[] array6 = this.tblClassifier.Select("id = " + dataRow3["idMaterial"].ToString());
                            if (array6.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array6[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Условия работы: ";
                        if (dataRow3["ClauseWork"] != DBNull.Value)
                        {
                            DataRow[] array7 = this.tblClassifier.Select("id = " + dataRow3["ClauseWork"].ToString());
                            if (array7.Length != 0)
                            {
                                dataRow4["Description"] = dataRow4["Description"].ToString() + array7[0]["Name"].ToString();
                            }
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Характер повреждения: ";
                        if (this.cmbClassifierDamage.SelectedIndex >= 0)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + ((DataRowView)this.cmbClassifierDamage.SelectedItem).Row["name"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Причина повреждения: ";
                        if (this.cmbReasonBeginCrash.SelectedIndex >= 0)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + ((DataRowView)this.cmbReasonBeginCrash.SelectedItem).Row["comment"].ToString().ToLower();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Сопутствующие обстоятельства: ";
                        if (dataRow3["AssociatedFact"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["AssociatedFact"].ToString();
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Срок службы оборудования от последнего капительного ремонта:\r\n \t\t 1) Начало эксплуатации: ";
                        if (dataRow3["yearBegEquipment"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["yearBegEquipment"].ToString() + "г.";
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Срок службы поврежденного узла: ";
                        if (dataRow3["lenghtWorkEquipment"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + dataRow3["lenghtWorkEquipment"].ToString() + " " + this.GetDeclineYears(Convert.ToInt32(dataRow3["lenghtWorkEquipment"]));
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Последние эксплуатационные испытания: ";
                        if (dataRow3["LastDateTest"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + Convert.ToDateTime(dataRow3["LastDateTest"]).ToString("yyyy") + "г.";
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                        dataRow4 = this.dataSetDamage.table4.NewRow();
                        dataRow4["num"] = "4." + num.ToString() + ".";
                        dataRow4["Description"] = "Дата восстановления: ";
                        if (dataRow3["timeRecovery"] != DBNull.Value)
                        {
                            dataRow4["Description"] = dataRow4["Description"].ToString() + Convert.ToDateTime(dataRow3["timeRecovery"]).ToString("dd.MM.yyyy") + "г.";
                        }
                        this.dataSetDamage.table4.Rows.Add(dataRow4);
                        num++;
                    }
                }
                reportDataSource.Value = bindingSource3;
                reportViewerRus.LocalReport.DataSources.Add(reportDataSource);
                list.Add(new ReportParameter("Order", this.txtOrder.Text));
                if (this.cmbChairman.SelectedIndex >= 0)
                {
                    string text = ((DataRowView)this.cmbChairman.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostChairman.Text))
                    {
                        text = text + ", " + this.txtPostChairman.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Chairman", text));
                }
                if (this.cmbMemberComission1.SelectedIndex >= 0)
                {
                    string text2 = ((DataRowView)this.cmbMemberComission1.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostMemeber1.Text))
                    {
                        text2 = text2 + ", " + this.txtPostMemeber1.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Comission1", text2));
                }
                if (this.cmbMemberComission2.SelectedIndex >= 0)
                {
                    string text3 = ((DataRowView)this.cmbMemberComission2.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostMemeber2.Text))
                    {
                        text3 = text3 + ", " + this.txtPostMemeber2.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Comission2", text3));
                }
                if (this.cmbMemberComission3.SelectedIndex >= 0)
                {
                    string text4 = ((DataRowView)this.cmbMemberComission3.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostMemeber3.Text))
                    {
                        text4 = text4 + ", " + this.txtPostMemeber3.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Comission3", text4));
                }
                if (this.cmbMemberComission4.SelectedIndex >= 0)
                {
                    string text5 = ((DataRowView)this.cmbMemberComission4.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostMemeber4.Text))
                    {
                        text5 = text5 + ", " + this.txtPostMemeber4.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Comission4", text5));
                }
                if (this.cmbMemberComission5.SelectedIndex >= 0)
                {
                    string text6 = ((DataRowView)this.cmbMemberComission5.SelectedItem).Row["fio"].ToString();
                    if (!string.IsNullOrEmpty(this.txtPostMemeber5.Text))
                    {
                        text6 = text6 + ", " + this.txtPostMemeber5.Text.ToLower();
                    }
                    list.Add(new ReportParameter("Comission5", text6));
                }
                if (this.cmbCompiler.SelectedIndex >= 0)
                {
                    string text7 = ((DataRowView)this.cmbCompiler.SelectedItem).Row["fio"].ToString();
                    if (this.cmbCompiler.SelectedIndex >= 0)
                    {
                        DataTable dataTable5 = new SqlDataCommand(this.SqlSettings).SelectSqlData("select t.description from tR_JobTitle t \r\n\t                                                    inner join tR_Worker w on t.id = w.jobtitle\r\n                                                        where w.id = " + this.cmbCompiler.SelectedValue.ToString());
                        if (dataTable5.Rows.Count > 0 && dataTable5.Rows[0]["Description"] != DBNull.Value)
                        {
                            text7 = text7 + ", " + dataTable5.Rows[0]["Description"].ToString().ToLower();
                        }
                    }
                    list.Add(new ReportParameter("Compiler", text7));
                }
                reportViewerRus.LocalReport.SetParameters(list);
                reportViewerRus.RefreshReport();
            }
        }

        private string GetDeclineYears(int year)
        {
            switch (year % 10)
            {
                case 1:
                    return "год";
                case 2:
                case 3:
                case 4:
                    return "года";
                default:
                    return "лет";
            }
        }

        private void cmbWorkerApply_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            if (this.cmbWorkerApply.SelectedIndex >= 0 && (this.dtpApply.Value == null || this.dtpApply.Value == DBNull.Value))
            {
                this.dtpApply.Value = DateTime.Now;
            }
        }

        private void txtYearManufature_TextChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            this.txtYearBegEquipment.Text = this.txtYearManufature.Text;
        }

        private void txtYearManufature_Enter(object sender, EventArgs e)
        {
            this.txtYearManufature.TextChanged += new EventHandler(this.txtYearManufature_TextChanged);
        }

        private void txtYearManufature_Leave(object sender, EventArgs e)
        {
            this.txtYearManufature.TextChanged -= new EventHandler(this.txtYearManufature_TextChanged);
        }

        private void dtpDateOwner_ValueChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            this.CalcLengthWorkEquipment();
        }

        private void txtYearBegEquipment_TextChanged(object sender, EventArgs e)
        {
            this.isChangedData = true;
            this.CalcLengthWorkEquipment();
        }
        /// <summary>
        /// расчет (вывод на  форму) срока службы поврежденного узла
        /// </summary>
        private void CalcLengthWorkEquipment()
        {
            int num = 0;
            if (int.TryParse(this.txtYearBegEquipment.Text, out num))
            {
                this.txtLengthWorkEquipment.Text = (this.dtpDateOwner.Value.Year - num).ToString();
            }
        }

        private void dgv_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (((DataGridView)sender).Columns[e.ColumnIndex] is DataGridViewComboBoxColumn)
            {
                e.Cancel = true;
            }
        }

        private void dtpTimeRecovery_ValueChanged(object sender, EventArgs e)
        {
            if (this.dtpTimeRecovery.Value != null)
            {
                this.dtpLastDateTest.MaxDate = Convert.ToDateTime(this.dtpTimeRecovery.Value);
            }
        }

        private void btnRefreshDateDoc_Click(object sender, EventArgs e)
        {
            if (this.dataSetDamage.tJ_Damage.Rows.Count > 0)
            {
                if (this.dataSetDamage.tJ_Damage.Rows[0]["idParent"] == DBNull.Value)
                {
                    MessageBox.Show("Не выбран документ аварийного события", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                DataTable dataTable = new DataTable("tJ_Damage");
                dataTable.Columns.Add("dateDoc", typeof(DateTime));
                base.SelectSqlData(dataTable, true, "where id = " + this.dataSetDamage.tJ_Damage.Rows[0]["idParent"].ToString(), null, false, 0);
                if (dataTable.Rows.Count > 0)
                {
                    this.dataSetDamage.tJ_Damage.Rows[0]["DateDoc"] = dataTable.Rows[0]["DateDoc"];
                }
            }
        }

        private void btnRefreshDateEndCrash_Click(object sender, EventArgs e)
        {
            if (this.dataSetDamage.tJ_Damage.Rows.Count > 0)
            {
                if (this.dataSetDamage.tJ_Damage.Rows[0]["idParent"] == DBNull.Value)
                {
                    MessageBox.Show("Не выбран документ аварийного события", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (this.dataSetDamage.tJ_DamageActDetection.Rows.Count > 0)
                {
                    DataTable dataTable = new DataTable("tj_DamageOn");
                    dataTable.Columns.Add("DateOn", typeof(DateTime));
                    base.SelectSqlData(dataTable, true, "where idDamage = " + this.dataSetDamage.tJ_Damage.Rows[0]["idParent"].ToString() + " order by DateOn desc", null, false, 0);
                    if (dataTable.Rows.Count > 0)
                    {
                        this.dataSetDamage.tJ_DamageActDetection.Rows[0]["dateEndCrashLocal"] = dataTable.Rows[0]["dateOn"];
                        return;
                    }
                    this.dataSetDamage.tJ_DamageActDetection.Rows[0]["dateEndCrashLocal"] = DBNull.Value;
                }
            }
        }
    }
}