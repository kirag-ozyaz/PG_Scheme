﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Constants;
using System.IO;


namespace Legal.Forms.Document
{
    public partial class FormActBalance : FormLbr.FormBase
    {
        public static FormActBalance instance;
        public int idPar = -1;
        private int IDLIST = -1;
        private bool FLAG = false;

        public FormActBalance()
        {
            InitializeComponent();
            instance = this;
        }

        // конструктор для вызова из меню
        public FormActBalance(int idList)
        {
            InitializeComponent();
            IDLIST = idList;
            instance = this;
        }

        // конструктор для вызова из карточки абонента
        public FormActBalance(bool flag)
        {
            InitializeComponent();
            FLAG = flag;
            instance = this;
        }
        
        // загрузка источника данных для грида
        private void FormActBalance_Load(object sender, EventArgs e)
        {
            cmbPath.SelectedIndex = 0;
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.vActBalance, true, " order by CodeAbonent, ObjName");
            for (int i = 0; i < dsAbnObjAkt1.vActBalance.Count; i++)
            {

                string[] data = dsAbnObjAkt1.vActBalance.Rows[i]["Data"].ToString().Split('$');
                if (data[0].ToString() != "")
                {
                    foreach (string s in data)
                    {
                        if (s.IndexOf('=') > 0)
                        {
                            string s_name = s.Substring(0, s.IndexOf('='));
                            string s_content = s.Substring(s.IndexOf('=') + 1);
                            switch (s_name)
                            {
                                case "AktData":
                                    dsAbnObjAkt1.vActBalance.Rows[i]["ActDate"] = DateTime.Parse(s_content);
                                    break;
                                case "Region":
                                    dsAbnObjAkt1.vActBalance.Rows[i]["ActRegion"] = s_content;
                                    break;
                                case "DataNumber":
                                    dsAbnObjAkt1.vActBalance.Rows[i]["ActNumber"] = s_content; ;
                                    break;
                            }
                        }
                    }
                }
            }
            if (IDLIST > -1)
            {
                dgvFind();
  //              CreateAktRbp();
            }

        }

        private void dgvFind()
        {
            for (int i=0; i < dgvListAct.RowCount; i++)
                if (dgvListAct[5, i].FormattedValue.ToString().Contains(IDLIST.ToString()))  
                {
                    dgvListAct.CurrentCell = dgvListAct[1, i];  
                    return;  
                }  
        }

        // просмотр акта
        private void tsbView_Click(object sender, EventArgs e)
        {
            FormAbnAkt frmAktRBP = new FormAbnAkt(this.SqlSettings, 1, Convert.ToInt32(dgvListAct.CurrentRow.Cells["idListdgv"].Value));

            if (frmAktRBP.ShowDialog() == DialogResult.OK)
            {
            }
            frmAktRBP.Dispose();
        }

        // кнопка экспорта в Word
        private void tsbToWord_Click(object sender, EventArgs e)
        {
            CreateAktRbp();
        }

        // создание акта в Word
        public void CreateAktRbp()
        {

            String PhoneNumber = "";
            String Dogovor = "";
            String FaceOrg = "";
            String AbnName = "";
            string FileSavePath = "";

            if (FLAG == true)
                FileSavePath = "\\\\tsclient\\c\\dbOrg\\Акты\\";
            else
            {
                if (cmbPath.SelectedIndex == 0)
                    FileSavePath = "\\\\tsclient\\c\\dbOrg\\Акты\\";
                else
                    FileSavePath = "c:\\dbOrg\\Акты\\";
            }

            if (!Directory.Exists(FileSavePath))
            {
                MessageBox.Show("Нет такой папки " + FileSavePath, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string AbnName1 = AbnName.Replace("\"", string.Empty);
            string FileSaveName = FileSavePath + " " + AbnName1 + ".doc";
            
            /// Объект находящийся в эксплуатации владельца сетей
            String OrgSignature = "";

            int idAbn = Convert.ToInt32(dgvListAct.CurrentRow.Cells["idAbn"].Value);
            int idAbnObj = Convert.ToInt32(dgvListAct.CurrentRow.Cells["idAbnObj"].Value);
            int idList = Convert.ToInt32(dgvListAct.CurrentRow.Cells["idListdgv"].Value);

            DocType docType = DocType.Dogovor;

            // привязка к договору
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.tAbnDoc_List, true, String.Format(" where idAbn = {0} and idDocType = {1}", idAbn, (int)docType), true);
            if (dsAbnObjAkt1.tAbnDoc_List.Rows.Count > 0)
                Dogovor = String.Format("Приложение №3 к договору № {0} от {1} г.", dsAbnObjAkt1.tAbnDoc_List.Rows[0]["DocNumber"].ToString().Trim(), DateTime.Parse(dsAbnObjAkt1.tAbnDoc_List.Rows[0]["DocDate"].ToString().Trim()).ToShortDateString());

            // телефон
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.tInfo, true, " order by LeaveDate desc");
            if (dsAbnObjAkt1.tInfo.Rows.Count > 0)
                PhoneNumber = dsAbnObjAkt1.tInfo.Rows[0]["Info_Phone"].ToString().Trim();

            //  
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.vAbnAktFaceOrg, true, String.Format("where idclassifier = {0}", (int)docType), true);
            if (dsAbnObjAkt1.vAbnAktFaceOrg.Rows.Count > 0)
            {
                FaceOrg = dsAbnObjAkt1.vAbnAktFaceOrg.Rows[0]["Post_RP"].ToString().Trim() + " " + dsAbnObjAkt1.vAbnAktFaceOrg.Rows[0]["fio_reversshort"].ToString().Trim();
                OrgSignature = dsAbnObjAkt1.vAbnAktFaceOrg.Rows[0]["fio_reversshort"].ToString().Trim();
            }

            // наименование абонента
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.vAbn, true, String.Format(" where id = {0}", idAbn), true);
            if (dsAbnObjAkt1.vAbn.Rows.Count > 0)
                AbnName = dsAbnObjAkt1.vAbn.Rows[0]["Name"].ToString().Trim();

            // все данные акта
            SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.tAbnObjDoc_AktRBP, true, String.Format(" where idList = {0}", idList), true);
            string[] data = dsAbnObjAkt1.tAbnObjDoc_AktRBP.Rows[0]["Data"].ToString().Split('$');
                        
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Выберите шаблон для акта";
            dlg.InitialDirectory = "c:\\dborg\\dots";
            dlg.Filter = "Шаблоны Word(*.dot)|*.dot";
            dlg.Multiselect = false;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                EIS.WordLB.Application word = null;
                EIS.WordLB.Selection selection = null;
                try
                {
                    /// Инициализируем экземпляр класса Application и запускаем приложение Word
                    word = new EIS.WordLB.Application();
                }
                catch (Exception)
                {
                    MessageBox.Show("Отсутствует предустановленный MS Office Word", "Ошибка MS Office", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (word != null)
                {
                    string FileName = dlg.FileName;

                    try
                    {
                        word.Documents.Add(FileName);
                        selection = word.Selection;
                        if (Dogovor.Length > 0)
                            selection.FindAndReplace("[Привязка_кдоговору]", Dogovor, true);
                        else
                        {
                            selection.FindAndReplace("[Привязка_кдоговору]", "", true);
                        }
                        selection.FindAndReplace("[Абонент_наименование]", AbnName, true);
                        selection.FindAndReplace("[Телефон]", "32-32-34", true);

                        // заполняем поля в шаблоне
                        #region                                                                                                                                                                                                                                                                                #region                                                                                                                                                                                                                                                                                #region
                        foreach (string s in data)
                        {
                            string s_name = s.Substring(0, s.IndexOf('='));
                            string s_content = s.Substring(s.IndexOf('=') + 1);
                            switch (s_name)
                            {
                                // двухсторонний акт   
                                case "Region":
                                    selection.FindAndReplace("[Номер_района]", s_content, true);
                                    /// Имя начальника района на подпись
                                    String RegionSign = "";
                                    SelectSqlData(dsAbnObjAkt1, dsAbnObjAkt1.vRegionSchief, true, String.Format(" where Description like 'Сетевой район №{0}'", s_content), true);
                                    if (dsAbnObjAkt1.vRegionSchief.Rows.Count > 0)
                                        RegionSign = dsAbnObjAkt1.vRegionSchief.Rows[0]["FIO"].ToString().Trim();
                                    selection.FindAndReplace("[Начальник_района]", RegionSign, true);
                                    break;
                                case "AktData":
                                    selection.FindAndReplace("[Дата_Акта]", DateTime.Parse(s_content).ToShortDateString(), true);
                                    break;
                                case "DataNumber":
                                    selection.FindAndReplace("[Номер_Акта]", s_content, true);
                                    break;
                                case "OrgFace":
                                    selection.FindAndReplace("[Потребитель_влице]", s_content, true);
                                    break;
                                case "OrgBase":
                                    selection.FindAndReplace("[Потребитель_Основание]", s_content, true);
                                    break;
                                case "OrgBalance":
                                    selection.FindAndReplace("[Сетевая_оборудование]", s_content, false);
                                    break;
                                case "PotrBalance":
                                    selection.FindAndReplace("[Потребитель_оборудование]", s_content, false);
                                    break;
                                case "BorderBalance":
                                    selection.FindAndReplace("[Граница]", s_content, false);
                                    break;
                                case "OrgExpl":
                                    selection.FindAndReplace("[Сетевая_эксплуатация]", s_content, false);
                                    break;
                                case "PotrExpl":
                                    selection.FindAndReplace("[Потребитель_эксплуатация]", s_content, false);
                                    break;
                                case "Responsibility":
                                    selection.FindAndReplace("[Ответственность]", s_content, false);
                                    break;
                                case "Admission":
                                    selection.FindAndReplace("[Потребитель_допуск]", s_content, false);
                                    break;
                                case "PotrSignature":
                                    selection.FindAndReplace("[Потребитель_подпись]", s_content, false);
                                    break;

                                // трехсторонний акт
                                case "OwnerName":
                                    selection.FindAndReplace("[Владелец_имя]", s_content, true);
                                    break;
                                case "OwnerChief":
                                    selection.FindAndReplace("[Владелец_влице]", s_content, true);
                                    break;
                                case "OwnerBase":
                                    selection.FindAndReplace("[Владелец_основание]", s_content, true);
                                    break;
                                case "OrganizExpl":
                                    selection.FindAndReplace("[Владелец_оборудование]", s_content, false);
                                    break;
                                case "PotrebExpl":
                                    selection.FindAndReplace("[Владелец_эксплуатация]", s_content, false);
                                    break;
                                case "BorderExpl":
                                    selection.FindAndReplace("[Граница2]", s_content, false);
                                    break;
                                case "OwnerChief2":
                                    selection.FindAndReplace("[Владелец_подпись]", s_content, false);
                                    break;

                                // Дополнительные поля для акта c ТО
                                case "tbDogByOTONum":
                                    selection.FindAndReplace("[Номер_ОТО]", s_content, true);
                                    break;
                                case "tbTO2":
                                    selection.FindAndReplace("[Договор_ОТО2]", s_content, false);
                                    break;
                                case "tbTO1":
                                    selection.FindAndReplace("[Договор_OTO1]", s_content, false);
                                    break;

                                // Четырехсторонний акт
                                case "OwnerName_Four":
                                    selection.FindAndReplace("[Владелец2_имя]", s_content, true);
                                    break;
                                case "OwnerChief_Four":
                                    selection.FindAndReplace("[Владелец2_влице]", s_content, true);
                                    break;
                                case "OwnerBase_Four":
                                    selection.FindAndReplace("[Владелец2_основание]", s_content, true);
                                    break;
                                case "OrganizExpl_Four":
                                    selection.FindAndReplace("[Владелец2_оборудование]", s_content, false);
                                    break;
                                case "PotrebExpl_Four":
                                    selection.FindAndReplace("[Владелец2_эксплуатация]", s_content, false);
                                    break;
                                case "BorderExpl_Four":
                                    selection.FindAndReplace("[Граница3]", s_content, false);
                                    break;
                                case "OwnerChief2_Four":
                                    selection.FindAndReplace("[Владелец2_подпись]", s_content, false);
                                    break;
                            }
                        }
                        #endregion
                        selection = null;
                        word.ActiveDocument.SaveAs(FileSaveName);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Не удалось создать документ", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    word.Visible = true;
                    word = null;
                }
            }
        }

        // передача idList выбранного акта вызывающей форме
        private void dgvListAct_DoubleClick(object sender, EventArgs e)
        {
            if (FLAG == true)
            {
                idPar = Convert.ToInt32(dgvListAct.CurrentRow.Cells["idListdgv"].Value);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}
