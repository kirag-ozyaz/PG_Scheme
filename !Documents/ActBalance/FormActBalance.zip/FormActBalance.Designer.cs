﻿namespace Legal.Forms.Document
{
    partial class FormActBalance
    {
        /// <summary>
        ///Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormActBalance));
            this.dgvListAct = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codeAbonentDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.objNameDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.dataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idListdgv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idAbn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idAbnObj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.actNumberDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.actDateDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.actRegionDataGridViewTextBoxColumn = new ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dsAbnObjAkt1 = new Legal.DataSet.dsAbnObjAct();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbView = new System.Windows.Forms.ToolStripButton();
            this.tsbToWord = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.cmbPath = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dsAbnDocum1 = new Legal.DataSet.dsAbnDocum();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListAct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAbnObjAkt1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsAbnDocum1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvListAct
            // 
            this.dgvListAct.AllowUserToAddRows = false;
            this.dgvListAct.AllowUserToDeleteRows = false;
            this.dgvListAct.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListAct.AutoGenerateColumns = false;
            this.dgvListAct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListAct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.codeAbonentDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.objNameDataGridViewTextBoxColumn,
            this.dataDataGridViewTextBoxColumn,
            this.idListdgv,
            this.idAbn,
            this.idAbnObj,
            this.actNumberDataGridViewTextBoxColumn,
            this.actDateDataGridViewTextBoxColumn,
            this.actRegionDataGridViewTextBoxColumn});
            this.dgvListAct.DataSource = this.bindingSource1;
            this.dgvListAct.Location = new System.Drawing.Point(0, 25);
            this.dgvListAct.MultiSelect = false;
            this.dgvListAct.Name = "dgvListAct";
            this.dgvListAct.ReadOnly = true;
            this.dgvListAct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListAct.Size = new System.Drawing.Size(953, 518);
            this.dgvListAct.TabIndex = 1;
            this.dgvListAct.DoubleClick += new System.EventHandler(this.dgvListAct_DoubleClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // codeAbonentDataGridViewTextBoxColumn
            // 
            this.codeAbonentDataGridViewTextBoxColumn.DataPropertyName = "CodeAbonent";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.codeAbonentDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.codeAbonentDataGridViewTextBoxColumn.HeaderText = "Код";
            this.codeAbonentDataGridViewTextBoxColumn.Name = "codeAbonentDataGridViewTextBoxColumn";
            this.codeAbonentDataGridViewTextBoxColumn.ReadOnly = true;
            this.codeAbonentDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.codeAbonentDataGridViewTextBoxColumn.Width = 80;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Потребитель";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.nameDataGridViewTextBoxColumn.Width = 260;
            // 
            // objNameDataGridViewTextBoxColumn
            // 
            this.objNameDataGridViewTextBoxColumn.DataPropertyName = "ObjName";
            this.objNameDataGridViewTextBoxColumn.HeaderText = "Объект";
            this.objNameDataGridViewTextBoxColumn.Name = "objNameDataGridViewTextBoxColumn";
            this.objNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.objNameDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.objNameDataGridViewTextBoxColumn.Width = 320;
            // 
            // dataDataGridViewTextBoxColumn
            // 
            this.dataDataGridViewTextBoxColumn.DataPropertyName = "Data";
            this.dataDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataDataGridViewTextBoxColumn.Name = "dataDataGridViewTextBoxColumn";
            this.dataDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataDataGridViewTextBoxColumn.Visible = false;
            // 
            // idListdgv
            // 
            this.idListdgv.DataPropertyName = "idList";
            this.idListdgv.HeaderText = "idList";
            this.idListdgv.Name = "idListdgv";
            this.idListdgv.ReadOnly = true;
            this.idListdgv.Visible = false;
            // 
            // idAbn
            // 
            this.idAbn.DataPropertyName = "idAbn";
            this.idAbn.HeaderText = "idAbn";
            this.idAbn.Name = "idAbn";
            this.idAbn.ReadOnly = true;
            this.idAbn.Visible = false;
            // 
            // idAbnObj
            // 
            this.idAbnObj.DataPropertyName = "idAbnObj";
            this.idAbnObj.HeaderText = "idAbnObj";
            this.idAbnObj.Name = "idAbnObj";
            this.idAbnObj.ReadOnly = true;
            this.idAbnObj.Visible = false;
            // 
            // actNumberDataGridViewTextBoxColumn
            // 
            this.actNumberDataGridViewTextBoxColumn.DataPropertyName = "ActNumber";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.actNumberDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.actNumberDataGridViewTextBoxColumn.HeaderText = "Номер";
            this.actNumberDataGridViewTextBoxColumn.Name = "actNumberDataGridViewTextBoxColumn";
            this.actNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.actNumberDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.actNumberDataGridViewTextBoxColumn.Width = 75;
            // 
            // actDateDataGridViewTextBoxColumn
            // 
            this.actDateDataGridViewTextBoxColumn.DataPropertyName = "ActDate";
            this.actDateDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.actDateDataGridViewTextBoxColumn.Name = "actDateDataGridViewTextBoxColumn";
            this.actDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.actDateDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // actRegionDataGridViewTextBoxColumn
            // 
            this.actRegionDataGridViewTextBoxColumn.DataPropertyName = "ActRegion";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.actRegionDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.actRegionDataGridViewTextBoxColumn.HeaderText = "Район";
            this.actRegionDataGridViewTextBoxColumn.Name = "actRegionDataGridViewTextBoxColumn";
            this.actRegionDataGridViewTextBoxColumn.ReadOnly = true;
            this.actRegionDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.actRegionDataGridViewTextBoxColumn.Width = 75;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "vActBalance";
            this.bindingSource1.DataSource = this.dsAbnObjAkt1;
            // 
            // dsAbnObjAkt1
            // 
            this.dsAbnObjAkt1.DataSetName = "dsAbnObjAkt";
            this.dsAbnObjAkt1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbView
            // 
            this.tsbView.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbView.Image = global::Legal.Properties.Resources._1304672652_Information;
            this.tsbView.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbView.Name = "tsbView";
            this.tsbView.Size = new System.Drawing.Size(23, 22);
            this.tsbView.Text = "Просмотр акта";
            this.tsbView.Click += new System.EventHandler(this.tsbView_Click);
            // 
            // tsbToWord
            // 
            this.tsbToWord.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tsbToWord.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbToWord.Image = ((System.Drawing.Image)(resources.GetObject("tsbToWord.Image")));
            this.tsbToWord.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbToWord.Margin = new System.Windows.Forms.Padding(10, 1, 0, 2);
            this.tsbToWord.Name = "tsbToWord";
            this.tsbToWord.Size = new System.Drawing.Size(91, 22);
            this.tsbToWord.Text = "Экспорт в Word";
            this.tsbToWord.Click += new System.EventHandler(this.tsbToWord_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbView,
            this.toolStripSeparator1,
            this.tsbToWord,
            this.cmbPath,
            this.toolStripSeparator2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(953, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // cmbPath
            // 
            this.cmbPath.Items.AddRange(new object[] {
            "c сервера на комп",
            "на сервере",
            "на компе"});
            this.cmbPath.Name = "cmbPath";
            this.cmbPath.Size = new System.Drawing.Size(121, 25);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Margin = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // dsAbnDocum1
            // 
            this.dsAbnDocum1.DataSetName = "dsAbnDocum";
            this.dsAbnDocum1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FormActBalance
            // 
            this.ClientSize = new System.Drawing.Size(953, 543);
            this.Controls.Add(this.dgvListAct);
            this.Controls.Add(this.toolStrip1);
            this.Name = "FormActBalance";
            this.Text = "Реестр актов разграничения балансовой принадлежности";
            this.Load += new System.EventHandler(this.FormActBalance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListAct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAbnObjAkt1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsAbnDocum1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvListAct;
        private Legal.DataSet.dsAbnObjAct dsAbnObjAkt1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbView;
        private System.Windows.Forms.ToolStripButton tsbToWord;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private DataSet.dsAbnDocum dsAbnDocum1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn codeAbonentDataGridViewTextBoxColumn;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn nameDataGridViewTextBoxColumn;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn objNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idListdgv;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAbn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAbnObj;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn actNumberDataGridViewTextBoxColumn;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn actDateDataGridViewTextBoxColumn;
        private ControlsLbr.DataGridViewExcelFilter.DataGridViewFilterTextBoxColumn actRegionDataGridViewTextBoxColumn;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripComboBox cmbPath;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}
