﻿using ControlsLbr;
using ControlsLbr.DataGridViewExcelFilter;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SchemeReports
{
    partial class FormLinkAbnNewAndOld
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>resources
        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager resources = new ComponentResourceManager(typeof(FormLinkAbnNewAndOld));
            DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            this.treeDataGridView2 = new TreeDataGridView();
            this.treeGridColumn1 = new TreeGridColumn();
            this.dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            this.treeDataGridView1 = new TreeDataGridView();
            this.Column1 = new TreeGridColumn();
            this.Column2 = new TreeGridColumn();
            this.Column3 = new TreeGridColumn();
            this.Column4 = new DataGridViewTextBoxColumn();
            this.backgroundWorker_0 = new BackgroundWorker();
            this.panelProgress = new Panel();
            this.label3 = new Label();
            this.progressBarEndLess = new ProgressBarEndLess();
            this.dgvListLegal = new DataGridViewExcelFilter();
            this.TPConnectDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.tPrazrDgvColumn = new DataGridViewFilterTextBoxColumn();
            this.toolStrip = new ToolStrip();
            this.toolBtnRefresh = new ToolStripButton();
            this.toolBtnExportExcel = new ToolStripButton();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.toolLabelTypeSchema = new ToolStripLabel();
            this.toolCmbTypeSchema = new ToolStripComboBox();
            this.toolLabelPeriodKWT = new ToolStripLabel();
            this.toolBtnLoad = new ToolStripButton();
            this.splitContainer1 = new SplitContainer();
            this.dgvListLegalContact = new DataGridViewExcelFilter();
            this.tabControl1 = new TabControl();
            this.tabPageAbnWithCP = new TabPage();
            this.dgvReportCP = new DataGridViewExcelFilter();
            this.bsReportCP = new BindingSource(this.components);
            this.ds = new DataSet();
            this.dtReportCP = new DataTable();
            this.idAbn = new DataColumn();
            this.codeAbonent = new DataColumn();
            this.nameAbn = new DataColumn();
            this.typeAbn = new DataColumn();
            this.typeAbnName = new DataColumn();
            this.idAbnObj = new DataColumn();
            this.nameObj = new DataColumn();
            this.address = new DataColumn();
            this.kladrObjId = new DataColumn();
            this.KladrObjName = new DataColumn();
            this.category = new DataColumn();
            this.categoryName = new DataColumn();
            this.idTariff = new DataColumn();
            this.tariffName = new DataColumn();
            this.powerSet = new DataColumn();
            this.powerFact = new DataColumn();
            this.Consumer = new DataColumn();
            this.consumerName = new DataColumn();
            this.contact = new DataColumn();
            this.abnNet = new DataColumn();
            this.abnServicing = new DataColumn();
            this.idSchmObj = new DataColumn();
            this.idDoc = new DataColumn();
            this.TypeDoc = new DataColumn();
            this.TypeDocName = new DataColumn();
            this.cellId = new DataColumn();
            this.cellName = new DataColumn();
            this.busId = new DataColumn();
            this.busName = new DataColumn();
            this.subId = new DataColumn();
            this.subName = new DataColumn();
            this.schmObjName = new DataColumn();
            this.cellCPId = new DataColumn();
            this.cellCPName = new DataColumn();
            this.busCPId = new DataColumn();
            this.busCPName = new DataColumn();
            this.subCPId = new DataColumn();
            this.subCPName = new DataColumn();
            this.SumKWT = new DataColumn();
            this.tabPageLegal = new TabPage();
            this.backgroundWorker_1 = new BackgroundWorker();
            this.docAbn1 = new DataColumn();
            this.legalAddress1 = new DataColumn();
            this.postAddress1 = new DataColumn();
            this.codeAbonentDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.idAbnDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.nameAbnDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.typeAbnDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.nameObjDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.idAbnObjDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.streetnameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.houseDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.subnameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.busnameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.cellNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.idSchmObjDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.cellIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.busidDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.subidDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.schmObjNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.bsSchmAbnFull = new BindingSource(this.components);
            this.dataSetScheme = new DataSetScheme();
            this.dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new DataGridViewTextBoxColumn();
            this.bsAbnContact = new BindingSource(this.components);
            this.subCPNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.cellCPNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.subNameDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.busNameDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.cellNameDataGridViewTextBoxColumn1 = new DataGridViewFilterTextBoxColumn();
            this.codeAbonentDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.docAbn = new DataGridViewFilterTextBoxColumn();
            this.nameAbnDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.idAbnDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.typeAbnDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.typeAbnNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.idAbnObjDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.legalAddress = new DataGridViewFilterTextBoxColumn();
            this.postAddress = new DataGridViewFilterTextBoxColumn();
            this.nameObjDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.kladrObjIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.kladrObjNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.categoryNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.idTariffDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.tariffNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.powerSetDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.powerFactDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.consumerDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.sumKWTDgvColumn = new DataGridViewTextBoxColumn();
            this.consumerNameDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.abnNetDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.abnServicingDataGridViewTextBoxColumn = new DataGridViewFilterTextBoxColumn();
            this.idSchmObjDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.idDocDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.typeDocDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.typeDocNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.cellIdDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.busIdDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.subIdDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.schmObjNameDataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            this.cellCPIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.busCPIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.busCPNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            this.subCPIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ((ISupportInitialize)this.treeDataGridView2).BeginInit();
            ((ISupportInitialize)this.treeDataGridView1).BeginInit();
            this.panelProgress.SuspendLayout();
            ((ISupportInitialize)this.dgvListLegal).BeginInit();
            this.toolStrip.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((ISupportInitialize)this.dgvListLegalContact).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPageAbnWithCP.SuspendLayout();
            ((ISupportInitialize)this.dgvReportCP).BeginInit();
            ((ISupportInitialize)this.bsReportCP).BeginInit();
            ((ISupportInitialize)this.ds).BeginInit();
            ((ISupportInitialize)this.dtReportCP).BeginInit();
            this.tabPageLegal.SuspendLayout();
            ((ISupportInitialize)this.bsSchmAbnFull).BeginInit();
            ((ISupportInitialize)this.dataSetScheme).BeginInit();
            ((ISupportInitialize)this.bsAbnContact).BeginInit();
            base.SuspendLayout();
            this.treeDataGridView2.AllowUserToAddRows = false;
            this.treeDataGridView2.AllowUserToDeleteRows = false;
            this.treeDataGridView2.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.treeDataGridView2.ImageList = null;
            this.treeDataGridView2.Location = new Point(0, 0);
            this.treeDataGridView2.Name = "treeDataGridView2";
            this.treeDataGridView2.Size = new Size(240, 150);
            this.treeDataGridView2.TabIndex = 0;
            this.treeGridColumn1.DefaultNodeImage = null;
            this.treeGridColumn1.Name = "treeGridColumn1";
            this.dataGridViewTextBoxColumn1.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.treeDataGridView1.AllowUserToAddRows = false;
            this.treeDataGridView1.AllowUserToDeleteRows = false;
            this.treeDataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.treeDataGridView1.ImageList = null;
            this.treeDataGridView1.Location = new Point(0, 0);
            this.treeDataGridView1.Name = "treeDataGridView1";
            this.treeDataGridView1.Size = new Size(240, 150);
            this.treeDataGridView1.TabIndex = 0;
            this.Column1.DefaultNodeImage = null;
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = DataGridViewTriState.True;
            this.Column1.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.Column2.DefaultNodeImage = null;
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            this.Column2.Resizable = DataGridViewTriState.True;
            this.Column2.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.Column3.DefaultNodeImage = null;
            this.Column3.HeaderText = "Column3";
            this.Column3.Name = "Column3";
            this.Column3.Resizable = DataGridViewTriState.True;
            this.Column3.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.Column4.HeaderText = "Column4";
            this.Column4.Name = "Column4";
            this.Column4.Resizable = DataGridViewTriState.True;
            this.Column4.SortMode = DataGridViewColumnSortMode.NotSortable;
            this.backgroundWorker_0.DoWork += this.backgroundWorker_0_DoWork;
            this.backgroundWorker_0.RunWorkerCompleted += this.backgroundWorker_0_RunWorkerCompleted;
            this.panelProgress.BackColor = SystemColors.Control;
            this.panelProgress.Controls.Add(this.label3);
            this.panelProgress.Controls.Add(this.progressBarEndLess);
            this.panelProgress.Location = new Point(272, 209);
            this.panelProgress.Name = "panelProgress";
            this.panelProgress.Size = new Size(431, 74);
            this.panelProgress.TabIndex = 7;
            this.panelProgress.Visible = false;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(111, 12);
            this.label3.Name = "label3";
            this.label3.Size = new Size(194, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Подождите... Идет загрузка из базы";
            this.progressBarEndLess.AutoProgressSpeed = 130;
            this.progressBarEndLess.Dock = DockStyle.Bottom;
            this.progressBarEndLess.Location = new Point(0, 39);
            this.progressBarEndLess.Name = "progressBarEndLess";
            this.progressBarEndLess.NormalImage = (Image)Properties.Resources.NormalImage;
            this.progressBarEndLess.PointImage = (Image)Properties.Resources.PointImage;
            this.progressBarEndLess.Position = 0;
            this.progressBarEndLess.ProgressStyle = ProgressBarEndLess.ProgressBarEndLessStyleConstants.LeftAndRight;
            this.progressBarEndLess.ProgressType = ProgressBarEndLess.ProgressBarEndLessTypeConstants.GraphicType;
            this.progressBarEndLess.Size = new Size(431, 35);
            this.progressBarEndLess.TabIndex = 5;
            this.dgvListLegal.AllowUserToAddRows = false;
            this.dgvListLegal.AllowUserToDeleteRows = false;
            this.dgvListLegal.AutoGenerateColumns = false;
            this.dgvListLegal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListLegal.Columns.AddRange(new DataGridViewColumn[]
            {
                this.codeAbonentDataGridViewTextBoxColumn1,
                this.idAbnDataGridViewTextBoxColumn,
                this.nameAbnDataGridViewTextBoxColumn1,
                this.typeAbnDataGridViewTextBoxColumn,
                this.nameObjDataGridViewTextBoxColumn1,
                this.idAbnObjDataGridViewTextBoxColumn,
                this.streetnameDataGridViewTextBoxColumn,
                this.houseDataGridViewTextBoxColumn1,
                this.subnameDataGridViewTextBoxColumn,
                this.busnameDataGridViewTextBoxColumn,
                this.cellNameDataGridViewTextBoxColumn,
                this.TPConnectDgvColumn,
                this.tPrazrDgvColumn,
                this.idSchmObjDataGridViewTextBoxColumn,
                this.cellIdDataGridViewTextBoxColumn,
                this.busidDataGridViewTextBoxColumn,
                this.subidDataGridViewTextBoxColumn,
                this.schmObjNameDataGridViewTextBoxColumn
            });
            this.dgvListLegal.DataSource = this.bsSchmAbnFull;
            this.dgvListLegal.Dock = DockStyle.Fill;
            this.dgvListLegal.Location = new Point(0, 0);
            this.dgvListLegal.Name = "dgvListLegal";
            this.dgvListLegal.ReadOnly = true;
            this.dgvListLegal.Size = new Size(961, 216);
            this.dgvListLegal.TabIndex = 8;
            this.TPConnectDgvColumn.DataPropertyName = "GosTP";
            this.TPConnectDgvColumn.HeaderText = "ПС (Госсектор)";
            this.TPConnectDgvColumn.Name = "TPConnectDgvColumn";
            this.TPConnectDgvColumn.ReadOnly = true;
            this.tPrazrDgvColumn.DataPropertyName = "razrTP";
            this.tPrazrDgvColumn.HeaderText = "ТП (Разреш)";
            this.tPrazrDgvColumn.Name = "tPrazrDgvColumn";
            this.tPrazrDgvColumn.ReadOnly = true;
            this.toolStrip.Items.AddRange(new ToolStripItem[]
            {
                this.toolBtnRefresh,
                this.toolBtnExportExcel,
                this.toolStripSeparator1,
                this.toolLabelTypeSchema,
                this.toolCmbTypeSchema,
                this.toolLabelPeriodKWT,
                this.toolBtnLoad
            });
            this.toolStrip.Location = new Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new Size(975, 25);
            this.toolStrip.TabIndex = 9;
            this.toolStrip.Text = "toolStrip1";
            this.toolBtnRefresh.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnRefresh.Image = Properties.Resources.Refresh;
            this.toolBtnRefresh.ImageTransparentColor = Color.Magenta;
            this.toolBtnRefresh.Name = "toolBtnRefresh";
            this.toolBtnRefresh.Size = new Size(23, 22);
            this.toolBtnRefresh.Text = "Обновить";
            this.toolBtnRefresh.Click += this.toolBtnRefresh_Click;
            this.toolBtnExportExcel.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.toolBtnExportExcel.Image = Properties.Resources.Excel;
            this.toolBtnExportExcel.ImageTransparentColor = Color.Magenta;
            this.toolBtnExportExcel.Name = "toolBtnExportExcel";
            this.toolBtnExportExcel.Size = new Size(23, 22);
            this.toolBtnExportExcel.Text = "toolStripButton1";
            this.toolBtnExportExcel.Click += this.toolBtnExportExcel_Click;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(6, 25);
            this.toolLabelTypeSchema.Name = "toolLabelTypeSchema";
            this.toolLabelTypeSchema.Size = new Size(41, 22);
            this.toolLabelTypeSchema.Text = "Схема";
            this.toolCmbTypeSchema.Items.AddRange(new object[]
            {
                "Оперативная схема",
                "По точкам токоразделов"
            });
            this.toolCmbTypeSchema.Name = "toolCmbTypeSchema";
            this.toolCmbTypeSchema.Size = new Size(121, 25);
            this.toolLabelPeriodKWT.Name = "toolLabelPeriodKWT";
            this.toolLabelPeriodKWT.Size = new Size(119, 22);
            this.toolLabelPeriodKWT.Text = "Период начислений";
            this.toolBtnLoad.Image = Properties.Resources.Play;
            this.toolBtnLoad.ImageTransparentColor = Color.Magenta;
            this.toolBtnLoad.Name = "toolBtnLoad";
            this.toolBtnLoad.Size = new Size(111, 22);
            this.toolBtnLoad.Text = "Сформировать";
            this.toolBtnLoad.Click += this.toolBtnLoadClick;
            this.splitContainer1.Dock = DockStyle.Fill;
            this.splitContainer1.Location = new Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = Orientation.Horizontal;
            this.splitContainer1.Panel1.Controls.Add(this.dgvListLegal);
            this.splitContainer1.Panel2.Controls.Add(this.dgvListLegalContact);
            this.splitContainer1.Size = new Size(961, 436);
            this.splitContainer1.SplitterDistance = 216;
            this.splitContainer1.TabIndex = 10;
            this.dgvListLegalContact.AllowUserToAddRows = false;
            this.dgvListLegalContact.AllowUserToDeleteRows = false;
            this.dgvListLegalContact.AllowUserToResizeRows = false;
            this.dgvListLegalContact.AutoGenerateColumns = false;
            this.dgvListLegalContact.BackgroundColor = Color.White;
            this.dgvListLegalContact.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListLegalContact.Columns.AddRange(new DataGridViewColumn[]
            {
                this.dataGridViewTextBoxColumn4,
                this.dataGridViewTextBoxColumn5,
                this.dataGridViewTextBoxColumn6,
                this.dataGridViewTextBoxColumn7,
                this.dataGridViewTextBoxColumn8,
                this.dataGridViewTextBoxColumn9,
                this.dataGridViewTextBoxColumn10,
                this.dataGridViewTextBoxColumn11,
                this.dataGridViewTextBoxColumn12,
                this.dataGridViewTextBoxColumn13
            });
            this.dgvListLegalContact.DataSource = this.bsAbnContact;
            this.dgvListLegalContact.Dock = DockStyle.Fill;
            this.dgvListLegalContact.Location = new Point(0, 0);
            this.dgvListLegalContact.MultiSelect = false;
            this.dgvListLegalContact.Name = "dgvListLegalContact";
            this.dgvListLegalContact.ReadOnly = true;
            this.dgvListLegalContact.RowHeadersWidth = 21;
            this.dgvListLegalContact.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvListLegalContact.Size = new Size(961, 216);
            this.dgvListLegalContact.TabIndex = 5;
            this.tabControl1.Controls.Add(this.tabPageAbnWithCP);
            this.tabControl1.Controls.Add(this.tabPageLegal);
            this.tabControl1.Dock = DockStyle.Fill;
            this.tabControl1.Location = new Point(0, 25);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(975, 468);
            this.tabControl1.TabIndex = 11;
            this.tabPageAbnWithCP.Controls.Add(this.dgvReportCP);
            this.tabPageAbnWithCP.Location = new Point(4, 22);
            this.tabPageAbnWithCP.Name = "tabPageAbnWithCP";
            this.tabPageAbnWithCP.Size = new Size(967, 442);
            this.tabPageAbnWithCP.TabIndex = 1;
            this.tabPageAbnWithCP.Text = "Привязка к питающим центрам";
            this.tabPageAbnWithCP.UseVisualStyleBackColor = true;
            this.dgvReportCP.AllowUserToAddRows = false;
            this.dgvReportCP.AllowUserToDeleteRows = false;
            this.dgvReportCP.AutoGenerateColumns = false;
            this.dgvReportCP.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReportCP.Columns.AddRange(new DataGridViewColumn[]
            {
                this.subCPNameDataGridViewTextBoxColumn,
                this.cellCPNameDataGridViewTextBoxColumn,
                this.subNameDataGridViewTextBoxColumn1,
                this.busNameDataGridViewTextBoxColumn1,
                this.cellNameDataGridViewTextBoxColumn1,
                this.codeAbonentDataGridViewTextBoxColumn,
                this.docAbn,
                this.nameAbnDataGridViewTextBoxColumn,
                this.idAbnDataGridViewTextBoxColumn1,
                this.typeAbnDataGridViewTextBoxColumn1,
                this.typeAbnNameDataGridViewTextBoxColumn,
                this.idAbnObjDataGridViewTextBoxColumn1,
                this.legalAddress,
                this.postAddress,
                this.nameObjDataGridViewTextBoxColumn,
                this.addressDataGridViewTextBoxColumn,
                this.kladrObjIdDataGridViewTextBoxColumn,
                this.kladrObjNameDataGridViewTextBoxColumn,
                this.categoryDataGridViewTextBoxColumn,
                this.categoryNameDataGridViewTextBoxColumn,
                this.idTariffDataGridViewTextBoxColumn,
                this.tariffNameDataGridViewTextBoxColumn,
                this.powerSetDataGridViewTextBoxColumn,
                this.powerFactDataGridViewTextBoxColumn,
                this.consumerDataGridViewTextBoxColumn,
                this.sumKWTDgvColumn,
                this.consumerNameDataGridViewTextBoxColumn,
                this.contactDataGridViewTextBoxColumn,
                this.abnNetDataGridViewTextBoxColumn,
                this.abnServicingDataGridViewTextBoxColumn,
                this.idSchmObjDataGridViewTextBoxColumn1,
                this.idDocDataGridViewTextBoxColumn,
                this.typeDocDataGridViewTextBoxColumn,
                this.typeDocNameDataGridViewTextBoxColumn,
                this.cellIdDataGridViewTextBoxColumn1,
                this.busIdDataGridViewTextBoxColumn1,
                this.subIdDataGridViewTextBoxColumn1,
                this.schmObjNameDataGridViewTextBoxColumn1,
                this.cellCPIdDataGridViewTextBoxColumn,
                this.busCPIdDataGridViewTextBoxColumn,
                this.busCPNameDataGridViewTextBoxColumn,
                this.subCPIdDataGridViewTextBoxColumn
            });
            this.dgvReportCP.DataSource = this.bsReportCP;
            this.dgvReportCP.Dock = DockStyle.Fill;
            this.dgvReportCP.Location = new Point(0, 0);
            this.dgvReportCP.Name = "dgvReportCP";
            this.dgvReportCP.ReadOnly = true;
            this.dgvReportCP.Size = new Size(967, 442);
            this.dgvReportCP.TabIndex = 0;
            this.dgvReportCP.RowPostPaint += this.dgvReportCP_RowPostPaint;
            this.bsReportCP.DataMember = "dtReportCP";
            this.bsReportCP.DataSource = this.ds;
            this.ds.DataSetName = "NewDataSet";
            this.ds.Tables.AddRange(new DataTable[]
            {
                this.dtReportCP
            });
            this.dtReportCP.Columns.AddRange(new DataColumn[]
            {
                this.idAbn,
                this.codeAbonent,
                this.nameAbn,
                this.typeAbn,
                this.typeAbnName,
                this.idAbnObj,
                this.nameObj,
                this.address,
                this.kladrObjId,
                this.KladrObjName,
                this.category,
                this.categoryName,
                this.idTariff,
                this.tariffName,
                this.powerSet,
                this.powerFact,
                this.Consumer,
                this.consumerName,
                this.contact,
                this.abnNet,
                this.abnServicing,
                this.idSchmObj,
                this.idDoc,
                this.TypeDoc,
                this.TypeDocName,
                this.cellId,
                this.cellName,
                this.busId,
                this.busName,
                this.subId,
                this.subName,
                this.schmObjName,
                this.cellCPId,
                this.cellCPName,
                this.busCPId,
                this.busCPName,
                this.subCPId,
                this.subCPName,
                this.SumKWT,
                this.docAbn1,
                this.legalAddress1,
                this.postAddress1
            });
            this.dtReportCP.TableName = "dtReportCP";
            this.idAbn.ColumnName = "idAbn";
            this.idAbn.DataType = typeof(int);
            this.codeAbonent.ColumnName = "codeAbonent";
            this.codeAbonent.DataType = typeof(int);
            this.nameAbn.ColumnName = "nameAbn";
            this.typeAbn.ColumnName = "typeAbn";
            this.typeAbn.DataType = typeof(int);
            this.typeAbnName.ColumnName = "typeAbnName";
            this.idAbnObj.ColumnName = "idAbnObj";
            this.idAbnObj.DataType = typeof(int);
            this.nameObj.ColumnName = "nameObj";
            this.address.ColumnName = "address";
            this.kladrObjId.ColumnName = "kladrObjId";
            this.kladrObjId.DataType = typeof(int);
            this.KladrObjName.ColumnName = "KladrObjName";
            this.category.ColumnName = "category";
            this.category.DataType = typeof(int);
            this.categoryName.ColumnName = "categoryName";
            this.idTariff.ColumnName = "idTariff";
            this.idTariff.DataType = typeof(int);
            this.tariffName.ColumnName = "tariffName";
            this.powerSet.ColumnName = "powerSet";
            this.powerSet.DataType = typeof(decimal);
            this.powerFact.ColumnName = "powerFact";
            this.powerFact.DataType = typeof(decimal);
            this.Consumer.ColumnName = "Consumer";
            this.Consumer.DataType = typeof(int);
            this.consumerName.ColumnName = "consumerName";
            this.contact.ColumnName = "contact";
            this.abnNet.ColumnName = "abnNet";
            this.abnServicing.ColumnName = "abnServicing";
            this.idSchmObj.ColumnName = "idSchmObj";
            this.idSchmObj.DataType = typeof(int);
            this.idDoc.ColumnName = "idDoc";
            this.idDoc.DataType = typeof(int);
            this.TypeDoc.ColumnName = "TypeDoc";
            this.TypeDoc.DataType = typeof(int);
            this.TypeDocName.ColumnName = "TypeDocName";
            this.cellId.ColumnName = "cellId";
            this.cellId.DataType = typeof(int);
            this.cellName.ColumnName = "cellName";
            this.busId.ColumnName = "busId";
            this.busId.DataType = typeof(int);
            this.busName.ColumnName = "busName";
            this.subId.ColumnName = "subId";
            this.subId.DataType = typeof(int);
            this.subName.ColumnName = "subName";
            this.schmObjName.ColumnName = "schmObjName";
            this.cellCPId.ColumnName = "cellCPId";
            this.cellCPName.ColumnName = "cellCPName";
            this.busCPId.ColumnName = "busCPId";
            this.busCPName.ColumnName = "busCPName";
            this.subCPId.ColumnName = "subCPId";
            this.subCPName.ColumnName = "subCPName";
            this.SumKWT.ColumnName = "SumKWT";
            this.SumKWT.DataType = typeof(int);
            this.tabPageLegal.Controls.Add(this.splitContainer1);
            this.tabPageLegal.Location = new Point(4, 22);
            this.tabPageLegal.Name = "tabPageLegal";
            this.tabPageLegal.Padding = new Padding(3);
            this.tabPageLegal.Size = new Size(967, 442);
            this.tabPageLegal.TabIndex = 0;
            this.tabPageLegal.Text = "Юридические лица";
            this.tabPageLegal.UseVisualStyleBackColor = true;
            this.backgroundWorker_1.DoWork += this.backgroundWorker_1_DoWork;
            this.backgroundWorker_1.RunWorkerCompleted += this.backgroundWorker_1_RunWorkerCompleted;
            this.docAbn1.ColumnName = "docAbn";
            this.legalAddress1.ColumnName = "legalAddress";
            this.postAddress1.ColumnName = "postAddress";
            this.codeAbonentDataGridViewTextBoxColumn1.DataPropertyName = "codeAbonent";
            this.codeAbonentDataGridViewTextBoxColumn1.HeaderText = "№ договора";
            this.codeAbonentDataGridViewTextBoxColumn1.Name = "codeAbonentDataGridViewTextBoxColumn1";
            this.codeAbonentDataGridViewTextBoxColumn1.ReadOnly = true;
            this.codeAbonentDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.codeAbonentDataGridViewTextBoxColumn1.Width = 70;
            this.idAbnDataGridViewTextBoxColumn.DataPropertyName = "idAbn";
            this.idAbnDataGridViewTextBoxColumn.HeaderText = "idAbn";
            this.idAbnDataGridViewTextBoxColumn.Name = "idAbnDataGridViewTextBoxColumn";
            this.idAbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.idAbnDataGridViewTextBoxColumn.Visible = false;
            this.nameAbnDataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.nameAbnDataGridViewTextBoxColumn1.DataPropertyName = "nameAbn";
            this.nameAbnDataGridViewTextBoxColumn1.HeaderText = "Абонент";
            this.nameAbnDataGridViewTextBoxColumn1.Name = "nameAbnDataGridViewTextBoxColumn1";
            this.nameAbnDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nameAbnDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.typeAbnDataGridViewTextBoxColumn.DataPropertyName = "typeAbn";
            this.typeAbnDataGridViewTextBoxColumn.HeaderText = "typeAbn";
            this.typeAbnDataGridViewTextBoxColumn.Name = "typeAbnDataGridViewTextBoxColumn";
            this.typeAbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeAbnDataGridViewTextBoxColumn.Visible = false;
            this.nameObjDataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.nameObjDataGridViewTextBoxColumn1.DataPropertyName = "nameObj";
            this.nameObjDataGridViewTextBoxColumn1.HeaderText = "Объект";
            this.nameObjDataGridViewTextBoxColumn1.Name = "nameObjDataGridViewTextBoxColumn1";
            this.nameObjDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nameObjDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.idAbnObjDataGridViewTextBoxColumn.DataPropertyName = "idAbnObj";
            this.idAbnObjDataGridViewTextBoxColumn.HeaderText = "idAbnObj";
            this.idAbnObjDataGridViewTextBoxColumn.Name = "idAbnObjDataGridViewTextBoxColumn";
            this.idAbnObjDataGridViewTextBoxColumn.ReadOnly = true;
            this.idAbnObjDataGridViewTextBoxColumn.Visible = false;
            this.streetnameDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.streetnameDataGridViewTextBoxColumn.DataPropertyName = "streetname";
            this.streetnameDataGridViewTextBoxColumn.FillWeight = 70f;
            this.streetnameDataGridViewTextBoxColumn.HeaderText = "Улица";
            this.streetnameDataGridViewTextBoxColumn.Name = "streetnameDataGridViewTextBoxColumn";
            this.streetnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.streetnameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.houseDataGridViewTextBoxColumn1.DataPropertyName = "house";
            this.houseDataGridViewTextBoxColumn1.HeaderText = "Дом";
            this.houseDataGridViewTextBoxColumn1.Name = "houseDataGridViewTextBoxColumn1";
            this.houseDataGridViewTextBoxColumn1.ReadOnly = true;
            this.houseDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.subnameDataGridViewTextBoxColumn.DataPropertyName = "subname";
            this.subnameDataGridViewTextBoxColumn.HeaderText = "ПС";
            this.subnameDataGridViewTextBoxColumn.Name = "subnameDataGridViewTextBoxColumn";
            this.subnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.subnameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.subnameDataGridViewTextBoxColumn.Width = 65;
            this.busnameDataGridViewTextBoxColumn.DataPropertyName = "busname";
            this.busnameDataGridViewTextBoxColumn.HeaderText = "Шина";
            this.busnameDataGridViewTextBoxColumn.Name = "busnameDataGridViewTextBoxColumn";
            this.busnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.busnameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.busnameDataGridViewTextBoxColumn.Visible = false;
            this.busnameDataGridViewTextBoxColumn.Width = 55;
            this.cellNameDataGridViewTextBoxColumn.DataPropertyName = "CellName";
            this.cellNameDataGridViewTextBoxColumn.HeaderText = "Ячейка";
            this.cellNameDataGridViewTextBoxColumn.Name = "cellNameDataGridViewTextBoxColumn";
            this.cellNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.cellNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.cellNameDataGridViewTextBoxColumn.Visible = false;
            this.cellNameDataGridViewTextBoxColumn.Width = 55;
            this.idSchmObjDataGridViewTextBoxColumn.DataPropertyName = "idSchmObj";
            this.idSchmObjDataGridViewTextBoxColumn.HeaderText = "idSchmObj";
            this.idSchmObjDataGridViewTextBoxColumn.Name = "idSchmObjDataGridViewTextBoxColumn";
            this.idSchmObjDataGridViewTextBoxColumn.ReadOnly = true;
            this.idSchmObjDataGridViewTextBoxColumn.Visible = false;
            this.cellIdDataGridViewTextBoxColumn.DataPropertyName = "cellId";
            this.cellIdDataGridViewTextBoxColumn.HeaderText = "cellId";
            this.cellIdDataGridViewTextBoxColumn.Name = "cellIdDataGridViewTextBoxColumn";
            this.cellIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.cellIdDataGridViewTextBoxColumn.Visible = false;
            this.busidDataGridViewTextBoxColumn.DataPropertyName = "busid";
            this.busidDataGridViewTextBoxColumn.HeaderText = "busid";
            this.busidDataGridViewTextBoxColumn.Name = "busidDataGridViewTextBoxColumn";
            this.busidDataGridViewTextBoxColumn.ReadOnly = true;
            this.busidDataGridViewTextBoxColumn.Visible = false;
            this.subidDataGridViewTextBoxColumn.DataPropertyName = "subid";
            this.subidDataGridViewTextBoxColumn.HeaderText = "subid";
            this.subidDataGridViewTextBoxColumn.Name = "subidDataGridViewTextBoxColumn";
            this.subidDataGridViewTextBoxColumn.ReadOnly = true;
            this.subidDataGridViewTextBoxColumn.Visible = false;
            this.schmObjNameDataGridViewTextBoxColumn.DataPropertyName = "schmObjName";
            this.schmObjNameDataGridViewTextBoxColumn.HeaderText = "schmObjName";
            this.schmObjNameDataGridViewTextBoxColumn.Name = "schmObjNameDataGridViewTextBoxColumn";
            this.schmObjNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.schmObjNameDataGridViewTextBoxColumn.Visible = false;

            this.bsSchmAbnFull.DataMember = "vL_SchmAbnFull";
            this.bsSchmAbnFull.DataSource = this.dataSetScheme;
            this.bsSchmAbnFull.CurrentChanged += this.bsSchmAbnFullCurrentChanged;

            this.dataSetScheme.DataSetName = "DataSetScheme";
            this.dataSetScheme.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;

            this.dataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn4.HeaderText = "id";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "idAbn";
            this.dataGridViewTextBoxColumn5.HeaderText = "idAbn";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Post";
            this.dataGridViewTextBoxColumn6.HeaderText = "Должность";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "F";
            this.dataGridViewTextBoxColumn7.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 50;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "I";
            this.dataGridViewTextBoxColumn8.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 50;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "O";
            this.dataGridViewTextBoxColumn9.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 50;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn10.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "DateChange";
            this.dataGridViewTextBoxColumn11.HeaderText = "DateChange";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Visible = false;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Comment";
            this.dataGridViewTextBoxColumn12.HeaderText = "Коментарий";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 120;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "email";
            this.dataGridViewTextBoxColumn13.HeaderText = "e`mail";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.bsAbnContact.DataMember = "tAbnContact";
            this.bsAbnContact.DataSource = this.dataSetScheme;
            this.subCPNameDataGridViewTextBoxColumn.DataPropertyName = "subCPName";
            dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
            this.subCPNameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle;
            this.subCPNameDataGridViewTextBoxColumn.HeaderText = "ЦП";
            this.subCPNameDataGridViewTextBoxColumn.Name = "subCPNameDataGridViewTextBoxColumn";
            this.subCPNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.subCPNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.cellCPNameDataGridViewTextBoxColumn.DataPropertyName = "cellCPName";
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            this.cellCPNameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.cellCPNameDataGridViewTextBoxColumn.HeaderText = "Ячейка ЦП";
            this.cellCPNameDataGridViewTextBoxColumn.Name = "cellCPNameDataGridViewTextBoxColumn";
            this.cellCPNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.cellCPNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.cellCPNameDataGridViewTextBoxColumn.Width = 70;
            this.subNameDataGridViewTextBoxColumn1.DataPropertyName = "subName";
            this.subNameDataGridViewTextBoxColumn1.HeaderText = "ПС";
            this.subNameDataGridViewTextBoxColumn1.Name = "subNameDataGridViewTextBoxColumn1";
            this.subNameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.subNameDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.subNameDataGridViewTextBoxColumn1.Width = 90;
            this.busNameDataGridViewTextBoxColumn1.DataPropertyName = "busName";
            this.busNameDataGridViewTextBoxColumn1.HeaderText = "Шина";
            this.busNameDataGridViewTextBoxColumn1.Name = "busNameDataGridViewTextBoxColumn1";
            this.busNameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.busNameDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.busNameDataGridViewTextBoxColumn1.Width = 80;
            this.cellNameDataGridViewTextBoxColumn1.DataPropertyName = "cellName";
            this.cellNameDataGridViewTextBoxColumn1.HeaderText = "Ячейка";
            this.cellNameDataGridViewTextBoxColumn1.Name = "cellNameDataGridViewTextBoxColumn1";
            this.cellNameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.cellNameDataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            this.cellNameDataGridViewTextBoxColumn1.Width = 80;
            this.codeAbonentDataGridViewTextBoxColumn.DataPropertyName = "codeAbonent";
            this.codeAbonentDataGridViewTextBoxColumn.HeaderText = "№ договора";
            this.codeAbonentDataGridViewTextBoxColumn.Name = "codeAbonentDataGridViewTextBoxColumn";
            this.codeAbonentDataGridViewTextBoxColumn.ReadOnly = true;
            this.codeAbonentDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.codeAbonentDataGridViewTextBoxColumn.Visible = false;
            this.codeAbonentDataGridViewTextBoxColumn.Width = 90;
            this.docAbn.DataPropertyName = "docAbn";
            this.docAbn.HeaderText = "№ договора";
            this.docAbn.Name = "docAbn";
            this.docAbn.ReadOnly = true;
            this.docAbn.Resizable = DataGridViewTriState.True;
            this.nameAbnDataGridViewTextBoxColumn.DataPropertyName = "nameAbn";
            this.nameAbnDataGridViewTextBoxColumn.HeaderText = "Абонент";
            this.nameAbnDataGridViewTextBoxColumn.Name = "nameAbnDataGridViewTextBoxColumn";
            this.nameAbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameAbnDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.idAbnDataGridViewTextBoxColumn1.DataPropertyName = "idAbn";
            this.idAbnDataGridViewTextBoxColumn1.HeaderText = "idAbn";
            this.idAbnDataGridViewTextBoxColumn1.Name = "idAbnDataGridViewTextBoxColumn1";
            this.idAbnDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idAbnDataGridViewTextBoxColumn1.Visible = false;
            this.typeAbnDataGridViewTextBoxColumn1.DataPropertyName = "typeAbn";
            this.typeAbnDataGridViewTextBoxColumn1.HeaderText = "typeAbn";
            this.typeAbnDataGridViewTextBoxColumn1.Name = "typeAbnDataGridViewTextBoxColumn1";
            this.typeAbnDataGridViewTextBoxColumn1.ReadOnly = true;
            this.typeAbnDataGridViewTextBoxColumn1.Visible = false;
            this.typeAbnNameDataGridViewTextBoxColumn.DataPropertyName = "typeAbnName";
            this.typeAbnNameDataGridViewTextBoxColumn.HeaderText = "Тип";
            this.typeAbnNameDataGridViewTextBoxColumn.Name = "typeAbnNameDataGridViewTextBoxColumn";
            this.typeAbnNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeAbnNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.idAbnObjDataGridViewTextBoxColumn1.DataPropertyName = "idAbnObj";
            this.idAbnObjDataGridViewTextBoxColumn1.HeaderText = "idAbnObj";
            this.idAbnObjDataGridViewTextBoxColumn1.Name = "idAbnObjDataGridViewTextBoxColumn1";
            this.idAbnObjDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idAbnObjDataGridViewTextBoxColumn1.Visible = false;
            this.legalAddress.DataPropertyName = "legalAddress";
            this.legalAddress.HeaderText = "Юридический адрес";
            this.legalAddress.Name = "legalAddress";
            this.legalAddress.ReadOnly = true;
            this.legalAddress.Resizable = DataGridViewTriState.True;
            this.postAddress.DataPropertyName = "postAddress";
            this.postAddress.HeaderText = "Почтовый адрес";
            this.postAddress.Name = "postAddress";
            this.postAddress.ReadOnly = true;
            this.postAddress.Resizable = DataGridViewTriState.True;
            this.nameObjDataGridViewTextBoxColumn.DataPropertyName = "nameObj";
            this.nameObjDataGridViewTextBoxColumn.HeaderText = "Объект";
            this.nameObjDataGridViewTextBoxColumn.Name = "nameObjDataGridViewTextBoxColumn";
            this.nameObjDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameObjDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Адрес объекта";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            this.kladrObjIdDataGridViewTextBoxColumn.DataPropertyName = "kladrObjId";
            this.kladrObjIdDataGridViewTextBoxColumn.HeaderText = "kladrObjId";
            this.kladrObjIdDataGridViewTextBoxColumn.Name = "kladrObjIdDataGridViewTextBoxColumn";
            this.kladrObjIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.kladrObjIdDataGridViewTextBoxColumn.Visible = false;
            this.kladrObjNameDataGridViewTextBoxColumn.DataPropertyName = "KladrObjName";
            this.kladrObjNameDataGridViewTextBoxColumn.HeaderText = "Город";
            this.kladrObjNameDataGridViewTextBoxColumn.Name = "kladrObjNameDataGridViewTextBoxColumn";
            this.kladrObjNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.kladrObjNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.kladrObjNameDataGridViewTextBoxColumn.Visible = false;
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.ReadOnly = true;
            this.categoryDataGridViewTextBoxColumn.Visible = false;
            this.categoryNameDataGridViewTextBoxColumn.DataPropertyName = "categoryName";
            this.categoryNameDataGridViewTextBoxColumn.HeaderText = "Кат";
            this.categoryNameDataGridViewTextBoxColumn.Name = "categoryNameDataGridViewTextBoxColumn";
            this.categoryNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.categoryNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.categoryNameDataGridViewTextBoxColumn.Width = 50;
            this.idTariffDataGridViewTextBoxColumn.DataPropertyName = "idTariff";
            this.idTariffDataGridViewTextBoxColumn.HeaderText = "idTariff";
            this.idTariffDataGridViewTextBoxColumn.Name = "idTariffDataGridViewTextBoxColumn";
            this.idTariffDataGridViewTextBoxColumn.ReadOnly = true;
            this.idTariffDataGridViewTextBoxColumn.Visible = false;
            this.tariffNameDataGridViewTextBoxColumn.DataPropertyName = "tariffName";
            this.tariffNameDataGridViewTextBoxColumn.HeaderText = "Тариф";
            this.tariffNameDataGridViewTextBoxColumn.Name = "tariffNameDataGridViewTextBoxColumn";
            this.tariffNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.tariffNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.tariffNameDataGridViewTextBoxColumn.Width = 70;
            this.powerSetDataGridViewTextBoxColumn.DataPropertyName = "powerSet";
            this.powerSetDataGridViewTextBoxColumn.HeaderText = "Уст мощность";
            this.powerSetDataGridViewTextBoxColumn.Name = "powerSetDataGridViewTextBoxColumn";
            this.powerSetDataGridViewTextBoxColumn.ReadOnly = true;
            this.powerFactDataGridViewTextBoxColumn.DataPropertyName = "powerFact";
            this.powerFactDataGridViewTextBoxColumn.HeaderText = "Факт мощность";
            this.powerFactDataGridViewTextBoxColumn.Name = "powerFactDataGridViewTextBoxColumn";
            this.powerFactDataGridViewTextBoxColumn.ReadOnly = true;
            this.consumerDataGridViewTextBoxColumn.DataPropertyName = "Consumer";
            this.consumerDataGridViewTextBoxColumn.HeaderText = "Consumer";
            this.consumerDataGridViewTextBoxColumn.Name = "consumerDataGridViewTextBoxColumn";
            this.consumerDataGridViewTextBoxColumn.ReadOnly = true;
            this.consumerDataGridViewTextBoxColumn.Visible = false;
            this.sumKWTDgvColumn.DataPropertyName = "SumKWT";
            this.sumKWTDgvColumn.HeaderText = "Потребление";
            this.sumKWTDgvColumn.Name = "sumKWTDgvColumn";
            this.sumKWTDgvColumn.ReadOnly = true;
            this.consumerNameDataGridViewTextBoxColumn.DataPropertyName = "consumerName";
            this.consumerNameDataGridViewTextBoxColumn.HeaderText = "Состав группы";
            this.consumerNameDataGridViewTextBoxColumn.Name = "consumerNameDataGridViewTextBoxColumn";
            this.consumerNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.consumerNameDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "contact";
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            this.contactDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.contactDataGridViewTextBoxColumn.HeaderText = "Телефоны";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            this.contactDataGridViewTextBoxColumn.ReadOnly = true;
            this.abnNetDataGridViewTextBoxColumn.DataPropertyName = "abnNet";
            this.abnNetDataGridViewTextBoxColumn.HeaderText = "Сетевая орг-ция";
            this.abnNetDataGridViewTextBoxColumn.Name = "abnNetDataGridViewTextBoxColumn";
            this.abnNetDataGridViewTextBoxColumn.ReadOnly = true;
            this.abnNetDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.abnServicingDataGridViewTextBoxColumn.DataPropertyName = "abnServicing";
            this.abnServicingDataGridViewTextBoxColumn.HeaderText = "Обсл-ая орг-ция";
            this.abnServicingDataGridViewTextBoxColumn.Name = "abnServicingDataGridViewTextBoxColumn";
            this.abnServicingDataGridViewTextBoxColumn.ReadOnly = true;
            this.abnServicingDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            this.idSchmObjDataGridViewTextBoxColumn1.DataPropertyName = "idSchmObj";
            this.idSchmObjDataGridViewTextBoxColumn1.HeaderText = "idSchmObj";
            this.idSchmObjDataGridViewTextBoxColumn1.Name = "idSchmObjDataGridViewTextBoxColumn1";
            this.idSchmObjDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idSchmObjDataGridViewTextBoxColumn1.Visible = false;
            this.idDocDataGridViewTextBoxColumn.DataPropertyName = "idDoc";
            this.idDocDataGridViewTextBoxColumn.HeaderText = "idDoc";
            this.idDocDataGridViewTextBoxColumn.Name = "idDocDataGridViewTextBoxColumn";
            this.idDocDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDocDataGridViewTextBoxColumn.Visible = false;
            this.typeDocDataGridViewTextBoxColumn.DataPropertyName = "TypeDoc";
            this.typeDocDataGridViewTextBoxColumn.HeaderText = "TypeDoc";
            this.typeDocDataGridViewTextBoxColumn.Name = "typeDocDataGridViewTextBoxColumn";
            this.typeDocDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeDocDataGridViewTextBoxColumn.Visible = false;
            this.typeDocNameDataGridViewTextBoxColumn.DataPropertyName = "TypeDocName";
            this.typeDocNameDataGridViewTextBoxColumn.HeaderText = "TypeDocName";
            this.typeDocNameDataGridViewTextBoxColumn.Name = "typeDocNameDataGridViewTextBoxColumn";
            this.typeDocNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeDocNameDataGridViewTextBoxColumn.Visible = false;
            this.cellIdDataGridViewTextBoxColumn1.DataPropertyName = "cellId";
            this.cellIdDataGridViewTextBoxColumn1.HeaderText = "cellId";
            this.cellIdDataGridViewTextBoxColumn1.Name = "cellIdDataGridViewTextBoxColumn1";
            this.cellIdDataGridViewTextBoxColumn1.ReadOnly = true;
            this.cellIdDataGridViewTextBoxColumn1.Visible = false;
            this.busIdDataGridViewTextBoxColumn1.DataPropertyName = "busId";
            this.busIdDataGridViewTextBoxColumn1.HeaderText = "busId";
            this.busIdDataGridViewTextBoxColumn1.Name = "busIdDataGridViewTextBoxColumn1";
            this.busIdDataGridViewTextBoxColumn1.ReadOnly = true;
            this.busIdDataGridViewTextBoxColumn1.Visible = false;
            this.subIdDataGridViewTextBoxColumn1.DataPropertyName = "subId";
            this.subIdDataGridViewTextBoxColumn1.HeaderText = "subId";
            this.subIdDataGridViewTextBoxColumn1.Name = "subIdDataGridViewTextBoxColumn1";
            this.subIdDataGridViewTextBoxColumn1.ReadOnly = true;
            this.subIdDataGridViewTextBoxColumn1.Visible = false;
            this.schmObjNameDataGridViewTextBoxColumn1.DataPropertyName = "schmObjName";
            this.schmObjNameDataGridViewTextBoxColumn1.HeaderText = "schmObjName";
            this.schmObjNameDataGridViewTextBoxColumn1.Name = "schmObjNameDataGridViewTextBoxColumn1";
            this.schmObjNameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.schmObjNameDataGridViewTextBoxColumn1.Visible = false;
            this.cellCPIdDataGridViewTextBoxColumn.DataPropertyName = "cellCPId";
            this.cellCPIdDataGridViewTextBoxColumn.HeaderText = "cellCPId";
            this.cellCPIdDataGridViewTextBoxColumn.Name = "cellCPIdDataGridViewTextBoxColumn";
            this.cellCPIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.cellCPIdDataGridViewTextBoxColumn.Visible = false;
            this.busCPIdDataGridViewTextBoxColumn.DataPropertyName = "busCPId";
            this.busCPIdDataGridViewTextBoxColumn.HeaderText = "busCPId";
            this.busCPIdDataGridViewTextBoxColumn.Name = "busCPIdDataGridViewTextBoxColumn";
            this.busCPIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.busCPIdDataGridViewTextBoxColumn.Visible = false;
            this.busCPNameDataGridViewTextBoxColumn.DataPropertyName = "busCPName";
            this.busCPNameDataGridViewTextBoxColumn.HeaderText = "busCPName";
            this.busCPNameDataGridViewTextBoxColumn.Name = "busCPNameDataGridViewTextBoxColumn";
            this.busCPNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.busCPNameDataGridViewTextBoxColumn.Visible = false;
            this.subCPIdDataGridViewTextBoxColumn.DataPropertyName = "subCPId";
            this.subCPIdDataGridViewTextBoxColumn.HeaderText = "subCPId";
            this.subCPIdDataGridViewTextBoxColumn.Name = "subCPIdDataGridViewTextBoxColumn";
            this.subCPIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.subCPIdDataGridViewTextBoxColumn.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(975, 493);
            base.Controls.Add(this.panelProgress);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.toolStrip);
            this.MinimumSize = new Size(821, 319);
            base.Name = "FormLinkAbnNewAndOld";
            this.Text = "\"Привязанные\" абоненты";
            base.Load += this.FormLinkAbnNewAndOld_Load;
            base.Resize += this.FormLinkAbnNewAndOld_Resize;
            ((ISupportInitialize)this.treeDataGridView2).EndInit();
            ((ISupportInitialize)this.treeDataGridView1).EndInit();
            this.panelProgress.ResumeLayout(false);
            this.panelProgress.PerformLayout();
            ((ISupportInitialize)this.dgvListLegal).EndInit();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((ISupportInitialize)this.dgvListLegalContact).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPageAbnWithCP.ResumeLayout(false);
            ((ISupportInitialize)this.dgvReportCP).EndInit();
            ((ISupportInitialize)this.bsReportCP).EndInit();
            ((ISupportInitialize)this.ds).EndInit();
            ((ISupportInitialize)this.dtReportCP).EndInit();
            this.tabPageLegal.ResumeLayout(false);
            ((ISupportInitialize)this.bsSchmAbnFull).EndInit();
            ((ISupportInitialize)this.dataSetScheme).EndInit();
            ((ISupportInitialize)this.bsAbnContact).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
            //this.button1 = new System.Windows.Forms.Button();
            //this.SuspendLayout();
            //// 
            //// button1
            //// 
            //this.button1.Location = new System.Drawing.Point(197, 78);
            //this.button1.Name = "button1";
            //this.button1.Size = new System.Drawing.Size(75, 23);
            //this.button1.TabIndex = 0;
            //this.button1.Text = "button1";
            //this.button1.UseVisualStyleBackColor = true;
            // 
            // FormLinkAbnNewAndOld
            // 
            ////////this.ClientSize = new System.Drawing.Size(284, 262);
            ////////this.Controls.Add(this.button1);
            ////////this.Name = "FormLinkAbnNewAndOld";
            //this.ResumeLayout(false);

        }

        #endregion
        // Token: 0x0400046D RID: 1133
        private DataTable dtSchmAbnFull;

 

        // Token: 0x04000470 RID: 1136
        private DateTimePicker dateTimePeriodKWT;

        // Token: 0x04000471 RID: 1137
        //private IContainer components;

        // Token: 0x04000472 RID: 1138
        private TreeDataGridView treeDataGridView1;

        // Token: 0x04000473 RID: 1139
        private TreeGridColumn Column1;

        // Token: 0x04000474 RID: 1140
        private TreeGridColumn Column2;

        // Token: 0x04000475 RID: 1141
        private TreeGridColumn Column3;

        // Token: 0x04000476 RID: 1142
        private DataGridViewTextBoxColumn Column4;

        // Token: 0x04000477 RID: 1143
        private TreeDataGridView treeDataGridView2;

        // Token: 0x04000478 RID: 1144
        private TreeGridColumn treeGridColumn1;

        // Token: 0x04000479 RID: 1145
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

        // Token: 0x0400047A RID: 1146
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;

        // Token: 0x0400047B RID: 1147
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;

        // Token: 0x0400047C RID: 1148
        private BackgroundWorker backgroundWorker_0;

        // Token: 0x0400047D RID: 1149
        private Panel panelProgress;

        // Token: 0x0400047E RID: 1150
        private Label label3;

        // Token: 0x0400047F RID: 1151
        private ProgressBarEndLess progressBarEndLess;

        // Token: 0x04000480 RID: 1152
        private BindingSource bsSchmAbnFull;

        // Token: 0x04000481 RID: 1153
        private DataSetScheme dataSetScheme;

        // Token: 0x04000482 RID: 1154
        private DataGridViewExcelFilter dgvListLegal;

        // Token: 0x04000483 RID: 1155
        private ToolStrip toolStrip;

        // Token: 0x04000484 RID: 1156
        private SplitContainer splitContainer1;

        // Token: 0x04000485 RID: 1157
        private BindingSource bsAbnContact;

        // Token: 0x04000486 RID: 1158
        private DataGridViewExcelFilter dgvListLegalContact;

        // Token: 0x04000487 RID: 1159
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

        // Token: 0x04000488 RID: 1160
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;

        // Token: 0x04000489 RID: 1161
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

        // Token: 0x0400048A RID: 1162
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;

        // Token: 0x0400048B RID: 1163
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;

        // Token: 0x0400048C RID: 1164
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;

        // Token: 0x0400048D RID: 1165
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;

        // Token: 0x0400048E RID: 1166
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;

        // Token: 0x0400048F RID: 1167
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;

        // Token: 0x04000490 RID: 1168
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;

        // Token: 0x04000491 RID: 1169
        private ToolStripButton toolBtnRefresh;

        // Token: 0x04000492 RID: 1170
        private TabControl tabControl1;

        // Token: 0x04000493 RID: 1171
        private TabPage tabPageLegal;

        // Token: 0x04000494 RID: 1172
        private DataGridViewFilterTextBoxColumn codeAbonentDataGridViewTextBoxColumn1;

        // Token: 0x04000495 RID: 1173
        private DataGridViewTextBoxColumn idAbnDataGridViewTextBoxColumn;

        // Token: 0x04000496 RID: 1174
        private DataGridViewFilterTextBoxColumn nameAbnDataGridViewTextBoxColumn1;

        // Token: 0x04000497 RID: 1175
        private DataGridViewTextBoxColumn typeAbnDataGridViewTextBoxColumn;

        // Token: 0x04000498 RID: 1176
        private DataGridViewFilterTextBoxColumn nameObjDataGridViewTextBoxColumn1;

        // Token: 0x04000499 RID: 1177
        private DataGridViewTextBoxColumn idAbnObjDataGridViewTextBoxColumn;

        // Token: 0x0400049A RID: 1178
        private DataGridViewFilterTextBoxColumn streetnameDataGridViewTextBoxColumn;

        // Token: 0x0400049B RID: 1179
        private DataGridViewFilterTextBoxColumn houseDataGridViewTextBoxColumn1;

        // Token: 0x0400049C RID: 1180
        private DataGridViewFilterTextBoxColumn subnameDataGridViewTextBoxColumn;

        // Token: 0x0400049D RID: 1181
        private DataGridViewFilterTextBoxColumn busnameDataGridViewTextBoxColumn;

        // Token: 0x0400049E RID: 1182
        private DataGridViewFilterTextBoxColumn cellNameDataGridViewTextBoxColumn;

        // Token: 0x0400049F RID: 1183
        private DataGridViewFilterTextBoxColumn TPConnectDgvColumn;

        // Token: 0x040004A0 RID: 1184
        private DataGridViewFilterTextBoxColumn tPrazrDgvColumn;

        // Token: 0x040004A1 RID: 1185
        private DataGridViewTextBoxColumn idSchmObjDataGridViewTextBoxColumn;

        // Token: 0x040004A2 RID: 1186
        private DataGridViewTextBoxColumn cellIdDataGridViewTextBoxColumn;

        // Token: 0x040004A3 RID: 1187
        private DataGridViewTextBoxColumn busidDataGridViewTextBoxColumn;

        // Token: 0x040004A4 RID: 1188
        private DataGridViewTextBoxColumn subidDataGridViewTextBoxColumn;

        // Token: 0x040004A5 RID: 1189
        private DataGridViewTextBoxColumn schmObjNameDataGridViewTextBoxColumn;

        // Token: 0x040004A6 RID: 1190
        private TabPage tabPageAbnWithCP;

        // Token: 0x040004A7 RID: 1191
        private BackgroundWorker backgroundWorker_1;

        // Token: 0x040004A8 RID: 1192
        private DataSet ds;

        // Token: 0x040004A9 RID: 1193
        private DataTable dtReportCP;

        // Token: 0x040004AA RID: 1194
        private DataColumn idAbn;

        // Token: 0x040004AB RID: 1195
        private DataColumn codeAbonent;

        // Token: 0x040004AC RID: 1196
        private DataColumn nameAbn;

        // Token: 0x040004AD RID: 1197
        private DataColumn typeAbn;

        // Token: 0x040004AE RID: 1198
        private DataColumn typeAbnName;

        // Token: 0x040004AF RID: 1199
        private DataColumn idAbnObj;

        // Token: 0x040004B0 RID: 1200
        private DataColumn nameObj;

        // Token: 0x040004B1 RID: 1201
        private DataColumn address;

        // Token: 0x040004B2 RID: 1202
        private DataColumn kladrObjId;

        // Token: 0x040004B3 RID: 1203
        private DataColumn KladrObjName;

        // Token: 0x040004B4 RID: 1204
        private DataColumn category;

        // Token: 0x040004B5 RID: 1205
        private DataColumn categoryName;

        // Token: 0x040004B6 RID: 1206
        private DataColumn idTariff;

        // Token: 0x040004B7 RID: 1207
        private DataColumn tariffName;

        // Token: 0x040004B8 RID: 1208
        private DataColumn powerSet;

        // Token: 0x040004B9 RID: 1209
        private DataColumn powerFact;

        // Token: 0x040004BA RID: 1210
        private DataColumn Consumer;

        // Token: 0x040004BB RID: 1211
        private DataColumn consumerName;

        // Token: 0x040004BC RID: 1212
        private DataColumn contact;

        // Token: 0x040004BD RID: 1213
        private DataColumn abnNet;

        // Token: 0x040004BE RID: 1214
        private DataColumn abnServicing;

        // Token: 0x040004BF RID: 1215
        private DataColumn idSchmObj;

        // Token: 0x040004C0 RID: 1216
        private DataColumn idDoc;

        // Token: 0x040004C1 RID: 1217
        private DataColumn TypeDoc;

        // Token: 0x040004C2 RID: 1218
        private DataColumn TypeDocName;

        // Token: 0x040004C3 RID: 1219
        private DataColumn cellId;

        // Token: 0x040004C4 RID: 1220
        private DataColumn cellName;

        // Token: 0x040004C5 RID: 1221
        private DataColumn busId;

        // Token: 0x040004C6 RID: 1222
        private DataColumn busName;

        // Token: 0x040004C7 RID: 1223
        private DataColumn subId;

        // Token: 0x040004C8 RID: 1224
        private DataColumn subName;

        // Token: 0x040004C9 RID: 1225
        private DataColumn schmObjName;

        // Token: 0x040004CA RID: 1226
        private DataGridViewExcelFilter dgvReportCP;

        // Token: 0x040004CB RID: 1227
        private BindingSource bsReportCP;

        // Token: 0x040004CC RID: 1228
        private DataColumn cellCPId;

        // Token: 0x040004CD RID: 1229
        private DataColumn cellCPName;

        // Token: 0x040004CE RID: 1230
        private DataColumn busCPId;

        // Token: 0x040004CF RID: 1231
        private DataColumn busCPName;

        // Token: 0x040004D0 RID: 1232
        private DataColumn subCPId;

        // Token: 0x040004D1 RID: 1233
        private DataColumn subCPName;

        // Token: 0x040004D2 RID: 1234
        private ToolStripButton toolBtnExportExcel;

        // Token: 0x040004D3 RID: 1235
        private ToolStripSeparator toolStripSeparator1;

        // Token: 0x040004D4 RID: 1236
        private ToolStripLabel toolLabelTypeSchema;

        // Token: 0x040004D5 RID: 1237
        private ToolStripComboBox toolCmbTypeSchema;

        // Token: 0x040004D6 RID: 1238
        private ToolStripLabel toolLabelPeriodKWT;

        // Token: 0x040004D7 RID: 1239
        private DataColumn SumKWT;

        // Token: 0x040004D8 RID: 1240
        private ToolStripButton toolBtnLoad;

        // Token: 0x040004D9 RID: 1241
        private DataColumn docAbn1;

        // Token: 0x040004DA RID: 1242
        private DataColumn legalAddress1;

        // Token: 0x040004DB RID: 1243
        private DataColumn postAddress1;

        // Token: 0x040004DC RID: 1244
        private DataGridViewFilterTextBoxColumn subCPNameDataGridViewTextBoxColumn;

        // Token: 0x040004DD RID: 1245
        private DataGridViewFilterTextBoxColumn cellCPNameDataGridViewTextBoxColumn;

        // Token: 0x040004DE RID: 1246
        private DataGridViewFilterTextBoxColumn subNameDataGridViewTextBoxColumn1;

        // Token: 0x040004DF RID: 1247
        private DataGridViewFilterTextBoxColumn busNameDataGridViewTextBoxColumn1;

        // Token: 0x040004E0 RID: 1248
        private DataGridViewFilterTextBoxColumn cellNameDataGridViewTextBoxColumn1;

        // Token: 0x040004E1 RID: 1249
        private DataGridViewFilterTextBoxColumn codeAbonentDataGridViewTextBoxColumn;

        // Token: 0x040004E2 RID: 1250
        private DataGridViewFilterTextBoxColumn docAbn;

        // Token: 0x040004E3 RID: 1251
        private DataGridViewFilterTextBoxColumn nameAbnDataGridViewTextBoxColumn;

        // Token: 0x040004E4 RID: 1252
        private DataGridViewTextBoxColumn idAbnDataGridViewTextBoxColumn1;

        // Token: 0x040004E5 RID: 1253
        private DataGridViewTextBoxColumn typeAbnDataGridViewTextBoxColumn1;

        // Token: 0x040004E6 RID: 1254
        private DataGridViewFilterTextBoxColumn typeAbnNameDataGridViewTextBoxColumn;

        // Token: 0x040004E7 RID: 1255
        private DataGridViewTextBoxColumn idAbnObjDataGridViewTextBoxColumn1;

        // Token: 0x040004E8 RID: 1256
        private DataGridViewFilterTextBoxColumn legalAddress;

        // Token: 0x040004E9 RID: 1257
        private DataGridViewFilterTextBoxColumn postAddress;

        // Token: 0x040004EA RID: 1258
        private DataGridViewFilterTextBoxColumn nameObjDataGridViewTextBoxColumn;

        // Token: 0x040004EB RID: 1259
        private DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;

        // Token: 0x040004EC RID: 1260
        private DataGridViewTextBoxColumn kladrObjIdDataGridViewTextBoxColumn;

        // Token: 0x040004ED RID: 1261
        private DataGridViewFilterTextBoxColumn kladrObjNameDataGridViewTextBoxColumn;

        // Token: 0x040004EE RID: 1262
        private DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;

        // Token: 0x040004EF RID: 1263
        private DataGridViewFilterTextBoxColumn categoryNameDataGridViewTextBoxColumn;

        // Token: 0x040004F0 RID: 1264
        private DataGridViewTextBoxColumn idTariffDataGridViewTextBoxColumn;

        // Token: 0x040004F1 RID: 1265
        private DataGridViewFilterTextBoxColumn tariffNameDataGridViewTextBoxColumn;

        // Token: 0x040004F2 RID: 1266
        private DataGridViewTextBoxColumn powerSetDataGridViewTextBoxColumn;

        // Token: 0x040004F3 RID: 1267
        private DataGridViewTextBoxColumn powerFactDataGridViewTextBoxColumn;

        // Token: 0x040004F4 RID: 1268
        private DataGridViewTextBoxColumn consumerDataGridViewTextBoxColumn;

        // Token: 0x040004F5 RID: 1269
        private DataGridViewTextBoxColumn sumKWTDgvColumn;

        // Token: 0x040004F6 RID: 1270
        private DataGridViewFilterTextBoxColumn consumerNameDataGridViewTextBoxColumn;

        // Token: 0x040004F7 RID: 1271
        private DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;

        // Token: 0x040004F8 RID: 1272
        private DataGridViewFilterTextBoxColumn abnNetDataGridViewTextBoxColumn;

        // Token: 0x040004F9 RID: 1273
        private DataGridViewFilterTextBoxColumn abnServicingDataGridViewTextBoxColumn;

        // Token: 0x040004FA RID: 1274
        private DataGridViewTextBoxColumn idSchmObjDataGridViewTextBoxColumn1;

        // Token: 0x040004FB RID: 1275
        private DataGridViewTextBoxColumn idDocDataGridViewTextBoxColumn;

        // Token: 0x040004FC RID: 1276
        private DataGridViewTextBoxColumn typeDocDataGridViewTextBoxColumn;

        // Token: 0x040004FD RID: 1277
        private DataGridViewTextBoxColumn typeDocNameDataGridViewTextBoxColumn;

        // Token: 0x040004FE RID: 1278
        private DataGridViewTextBoxColumn cellIdDataGridViewTextBoxColumn1;

        // Token: 0x040004FF RID: 1279
        private DataGridViewTextBoxColumn busIdDataGridViewTextBoxColumn1;

        // Token: 0x04000500 RID: 1280
        private DataGridViewTextBoxColumn subIdDataGridViewTextBoxColumn1;

        // Token: 0x04000501 RID: 1281
        private DataGridViewTextBoxColumn schmObjNameDataGridViewTextBoxColumn1;

        // Token: 0x04000502 RID: 1282
        private DataGridViewTextBoxColumn cellCPIdDataGridViewTextBoxColumn;

        // Token: 0x04000503 RID: 1283
        private DataGridViewTextBoxColumn busCPIdDataGridViewTextBoxColumn;

        // Token: 0x04000504 RID: 1284
        private DataGridViewTextBoxColumn busCPNameDataGridViewTextBoxColumn;

        // Token: 0x04000505 RID: 1285
        private DataGridViewTextBoxColumn subCPIdDataGridViewTextBoxColumn;
    }
}