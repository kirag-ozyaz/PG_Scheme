﻿using System.IO;
using System.Reflection;
using System.Text;

namespace SchemeReports
{
    internal class Class2
    {
        // Token: 0x0600006A RID: 106 RVA: 0x00002050 File Offset: 0x00000250
        private Class2()
        {
        }

        // Token: 0x0600006B RID: 107 RVA: 0x0000B2C4 File Offset: 0x000094C4
        public static StreamReader smethod_0(Assembly assembly_0, string string_0)
        {
            foreach (string text in assembly_0.GetManifestResourceNames())
            {
                if (text.EndsWith(string_0))
                {
                    return new StreamReader(assembly_0.GetManifestResourceStream(text), Encoding.GetEncoding(1251));
                }
            }
            return null;
        }

        // Token: 0x0600006C RID: 108 RVA: 0x0000B30C File Offset: 0x0000950C
        public static string smethod_1(Assembly assembly_0, string string_0)
        {
            StreamReader streamReader = Class2.smethod_0(assembly_0, string_0);
            string result = streamReader.ReadToEnd();
            streamReader.Close();
            return result;
        }

        // Token: 0x0600006D RID: 109 RVA: 0x000029AB File Offset: 0x00000BAB
        public static string smethod_2(string name)
        {
            return Class2.smethod_1(typeof(Class2).Assembly, name);
        }
    }

}
