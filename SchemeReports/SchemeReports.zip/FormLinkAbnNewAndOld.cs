﻿using FormLbr;
using SchemeModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchemeReports
{
    public partial class FormLinkAbnNewAndOld : FormBase
    {
        private bool flag0 = true;
        private bool flag = true;

        //public FormLinkAbnNewAndOld()
        //{
        //    InitializeComponent();
        //}
        public FormLinkAbnNewAndOld()
        {
            this.dtSchmAbnFull = new DataTable("vL_SchmAbnFull");
            this.InitializeComponent();

            //this.columncontact.MaxLength = int.MaxValue;

            this.dateTimePeriodKWT = new DateTimePicker();
            this.dateTimePeriodKWT.Width = 120;
            this.dateTimePeriodKWT.Format = DateTimePickerFormat.Custom;
            this.dateTimePeriodKWT.CustomFormat = "MMMM yyyy";
            this.dateTimePeriodKWT.Value = DateTime.Now.AddMonths(-1);
            this.dateTimePeriodKWT.ValueChanged += this.dateTimePicker_0_ValueChanged;
            int num = 0;
            //using (IEnumerator enumerator = this.toolStrip_0.Items.GetEnumerator())
            //{
            //    while (enumerator.MoveNext())
            //    {
            //        if ((ToolStripItem)enumerator.Current == this.toolStripLabel_1)
            //        {
            //            break;
            //        }
            //        num++;
            //    }
            //}
            
            foreach(var enumerator in this.toolStrip.Items)
            {
                  {
                    if ((ToolStripItem)enumerator == this.toolLabelPeriodKWT)
                    {
                        break;
                    }
                    num++;
                }
            }
            this.toolStrip.Items.Insert(num + 1, new ToolStripControlHost(this.dateTimePeriodKWT));
            this.bsSchmAbnFull.DataSource = this.dtSchmAbnFull;
        }

        // Token: 0x0600037A RID: 890 RVA: 0x00004667 File Offset: 0x00002867
        private void FormLinkAbnNewAndOld_Load(object sender, EventArgs e)
        {
            this.toolCmbTypeSchema.SelectedIndex = 1;
            this.method_0();
            this.StartBackGround();
            this.toolCmbTypeSchema.SelectedIndexChanged += this.toolStripComboBox_0_SelectedIndexChanged;
        }

        // Token: 0x0600037B RID: 891 RVA: 0x00046D40 File Offset: 0x00044F40
        private void method_0()
        {
            this.panelProgress.Visible = true;
            this.progressBarEndLess.AutoProgress = true;
            this.panelProgress.Left = base.Width / 2 - this.panelProgress.Width / 2;
            this.panelProgress.Top = base.Height / 2 - this.panelProgress.Height / 2;
            this.splitContainer1.Enabled = false;
            this.toolStrip.Enabled = false;
            this.dgvListLegal.DataSource = null;
            this.dgvListLegalContact.DataSource = null;
            this.flag0 = false;
            this.backgroundWorker_0.RunWorkerAsync();
        }

        // Token: 0x0600037C RID: 892 RVA: 0x00046DEC File Offset: 0x00044FEC
        private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(this.SqlSettings.GetConnectionString() + ";Connection Timeout=1000"))
            {
                try
                {
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(Class2.smethod_2("ReportLinkAbnNewAndOld.sql"), sqlConnection);
                    sqlDataAdapter.SelectCommand.CommandTimeout = 0;
                    this.dtSchmAbnFull.Clear();
                    sqlDataAdapter.Fill(this.dtSchmAbnFull);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.Source);
                }
            }
        }

        // Token: 0x0600037D RID: 893 RVA: 0x00046E84 File Offset: 0x00045084
        private void FormLinkAbnNewAndOld_Resize(object sender, EventArgs e)
        {
            this.panelProgress.Left = base.Width / 2 - this.progressBarEndLess.Width / 2;
            this.panelProgress.Top = base.Height / 2 - this.progressBarEndLess.Height / 2;
        }

        // Token: 0x0600037E RID: 894 RVA: 0x00004698 File Offset: 0x00002898
        private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.flag0 = true;
            if (this.flag && this.flag0)
            {
                this.method_3();
            }
        }

        // Token: 0x0600037F RID: 895 RVA: 0x00046ED4 File Offset: 0x000450D4
        private void bsSchmAbnFullCurrentChanged(object sender, EventArgs e)
        {
            if (this.bsSchmAbnFull.Current != null)
            {
                int num = Convert.ToInt32(((DataRowView)this.bsSchmAbnFull.Current).Row["idAbn"]);
                base.SelectSqlData(this.dataSetScheme, this.dataSetScheme.tAbnContact, true, "where [idAbn] = " + num);
                return;
            }
            this.dataSetScheme.tAbnContact.Clear();
        }

        // Token: 0x06000380 RID: 896 RVA: 0x000046B7 File Offset: 0x000028B7
        private void toolBtnRefresh_Click(object sender, EventArgs e)
        {
            this.method_0();
            this.StartBackGround();
        }

        // Token: 0x06000381 RID: 897 RVA: 0x000046C5 File Offset: 0x000028C5
        private void toolBtnExportExcel_Click(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab == this.tabPageAbnWithCP)
            {
                this.dgvReportCP.ExportToExcel();
            }
            if (this.tabControl1.SelectedTab == this.tabPageLegal)
            {
                this.dgvListLegal.CopyToExcel(true);
            }
        }

        // Token: 0x06000382 RID: 898 RVA: 0x00002B81 File Offset: 0x00000D81
        private void toolStripComboBox_0_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        // Token: 0x06000383 RID: 899 RVA: 0x00002B81 File Offset: 0x00000D81
        private void dateTimePicker_0_ValueChanged(object sender, EventArgs e)
        {
        }




        private void backgroundWorker_1_DoWork(object sender, DoWorkEventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(this.SqlSettings.GetConnectionString() + ";Connection Timeout=1000"))
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand(Class2.smethod_2("Forms.Reports.ReportLinkAbnWithCP.sql"), sqlConnection);
                    sqlCommand.Parameters.Add("dt", SqlDbType.DateTime).Value = ((FormLinkAbnNewAndOld.Class37)e.Argument).dateTime_0;
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    sqlDataAdapter.SelectCommand.CommandTimeout = 0;
                    this.dtReportCP.Clear();
                    sqlDataAdapter.Fill(this.dtReportCP);
                    ElectricModel electricModel = new ElectricModel();
                    electricModel.SqlSettings = this.SqlSettings;
                    electricModel.LoadSchema(((FormLinkAbnNewAndOld.Class37)e.Argument).flag0);
                    Thread thread = new Thread(new ParameterizedThreadStart(this.method_2));
                    thread.Start(new FormLinkAbnNewAndOld.Class38(0, this.dtReportCP.Rows.Count / 2, electricModel));
                    Thread thread2 = new Thread(new ParameterizedThreadStart(this.method_2));
                    thread2.Start(new FormLinkAbnNewAndOld.Class38(this.dtReportCP.Rows.Count / 2 + 1, this.dtReportCP.Rows.Count, electricModel));
                    thread.Join();
                    thread2.Join();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.Source);
                }
            }
        }

  
        private void backgroundWorker_1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.flag = true;
            if (this.flag && this.flag0)
            {
                this.method_3();
            }
        }


        private void method_2(object object_0)
        {
            FormLinkAbnNewAndOld.Class38 @class = (FormLinkAbnNewAndOld.Class38)object_0;
            for (int i = @class.int_0; i < @class.int_1; i++)
            {
                DataRow dataRow = this.dtReportCP.Rows[i];
                if (dataRow["idSchmObj"] != DBNull.Value)
                {
                    ElectricObject electricObjectById = @class.eModel.GetElectricObjectById(Convert.ToInt32(dataRow["idSchmObj"]));
                    if (electricObjectById != null && (!(electricObjectById is ElectricBus) || ((ElectricBus)electricObjectById).Amperage != null) && (!(electricObjectById is ElectricLine) || ((ElectricLine)electricObjectById).AmperageCount != 0))
                    {
                        SchemeModel.Calculations.TreeNodeObj treeNodeObj = @class.eModel.PoweringReportForDrawObject(Convert.ToInt32(dataRow["idSchmObj"]), false);
                        if (treeNodeObj != null)
                        {
                            string value = "";
                            string value2 = "";
                            string value3 = "";
                            string value4 = "";
                            string value5 = "";
                            string value6 = "";
                            int num = 1;
                            foreach (SchemeModel.Calculations.TreeNodeObj treeNodeObj2 in treeNodeObj.LeafsList)
                            {
                                if (treeNodeObj2.Tag != null && treeNodeObj2.Tag is ElectricObject)
                                {
                                    if (treeNodeObj2.Parent != null && treeNodeObj2.Parent.Tag != null && treeNodeObj2.Parent.Tag is ElectricObject)
                                    {
                                        value5 = ((ElectricObject)treeNodeObj2.Parent.Tag).ToString();
                                        value6 = ((ElectricObject)treeNodeObj2.Parent.Tag).Id.ToString();
                                    }
                                    value = ((ElectricObject)treeNodeObj2.Tag).ToString();
                                    value2 = ((ElectricObject)treeNodeObj2.Tag).Id.ToString();
                                    if (((ElectricObject)treeNodeObj2.Tag).Parent != null)
                                    {
                                        value3 = ((ElectricObject)treeNodeObj2.Tag).Parent.ToString();
                                        value4 = ((ElectricObject)treeNodeObj2.Tag).Parent.Id.ToString();
                                    }
                                }
                                DataTable obj = this.dtReportCP;
                                lock (obj)
                                {
                                    if (num == 1)
                                    {
                                        dataRow["busCPName"] = value;
                                        dataRow["busCPId"] = value2;
                                        dataRow["subCPName"] = value3;
                                        dataRow["subCpId"] = value4;
                                        dataRow["cellCPName"] = value5;
                                        dataRow["cellCpId"] = value6;
                                    }
                                    else
                                    {
                                        DataRow dataRow2 = this.dtReportCP.NewRow();
                                        dataRow2.ItemArray = (dataRow.ItemArray.Clone() as object[]);
                                        dataRow2["busCPName"] = value;
                                        dataRow2["busCPId"] = value2;
                                        dataRow2["subCPName"] = value3;
                                        dataRow2["subCpId"] = value4;
                                        dataRow2["cellCPName"] = value5;
                                        dataRow2["cellCpId"] = value6;
                                        this.dtReportCP.Rows.Add(dataRow2);
                                    }
                                }
                                num++;
                            }
                        }
                    }
                }
            }
        }

 
        private void method_3()
        {
            this.dgvListLegal.DataSource = this.bsSchmAbnFull;
            this.dgvListLegalContact.DataSource = this.bsAbnContact;
            this.dgvReportCP.DataSource = this.bsReportCP;
            this.splitContainer1.Enabled = true;
            this.toolStrip.Enabled = true;
            this.panelProgress.Visible = false;
            this.progressBarEndLess.AutoProgress = false;
        }
        // Token: 0x06000384 RID: 900 RVA: 0x00046F50 File Offset: 0x00045150
        private void StartBackGround()
        {
            this.panelProgress.Visible = true;
            this.progressBarEndLess.AutoProgress = true;
            this.panelProgress.Left = base.Width / 2 - this.panelProgress.Width / 2;
            this.panelProgress.Top = base.Height / 2 - this.panelProgress.Height / 2;
            this.splitContainer1.Enabled = false;
            this.toolStrip.Enabled = false;
            this.dgvReportCP.DataSource = null;
            this.flag = false;
            bool flag = true;
            if (this.toolCmbTypeSchema.SelectedIndex == 0)
            {
                flag = false;
            }
            this.backgroundWorker_1.RunWorkerAsync(new FormLinkAbnNewAndOld.Class37(flag, this.dateTimePeriodKWT.Value));
        }

        private void dgvReportCP_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            this.dgvReportCP.AutoResizeRow(e.RowIndex);
        }

        // Token: 0x0600038A RID: 906 RVA: 0x00004736 File Offset: 0x00002936
        private void toolBtnLoadClick(object sender, EventArgs e)
        {
            this.StartBackGround();
        }




        private class Class37
    {
        internal Class37(bool flag1, DateTime dateTime)
        {
            this.flag0 = flag1;
            this.dateTime_0 = dateTime;
        }

        internal bool flag0;
        internal DateTime dateTime_0;
    }

    private class Class38
    {
        internal Class38(int int_2, int int_3, ElectricModel eModel1)
        {
            this.int_0 = int_2;
            this.int_1 = int_3;
            this.eModel = eModel1;
        }
        internal int int_0;
        internal int int_1;
        internal ElectricModel eModel;
    }
}





}
