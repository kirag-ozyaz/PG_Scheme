﻿namespace SchemeReports
{
}

namespace SchemeReports
{


    public partial class DataSetScheme
    {
    }
}
namespace SchemeReports {
    
    
    public partial class DataSetScheme {
    }
}
